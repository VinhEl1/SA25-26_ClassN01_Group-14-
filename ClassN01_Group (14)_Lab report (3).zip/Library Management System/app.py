from flask import Flask, request, jsonify
from business_logic.book_service import BookService

app = Flask(__name__)
# Khởi tạo Service
book_service = BookService()

@app.route('/api/books', methods=['POST'])
def add_new_book():
    data = request.json
    try:
        # Nhận dữ liệu từ client
        title = data.get('title')
        author = data.get('author')
        year = int(data.get('year')) if data.get('year') else 0
        isbn = data.get('isbn')

        # Gọi Service xử lý
        new_book = book_service.add_book(title, author, year, isbn)

        # Trả về thành công (201 Created)
        return jsonify(new_book.to_dict()), 201

    except ValueError as e:
        # Trả về lỗi Business Rule (400 Bad Request)
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": "Lỗi hệ thống"}), 500

@app.route('/api/books', methods=['GET'])
def view_library():
    books = book_service.get_library_catalog()
    return jsonify([b.to_dict() for b in books]), 200

@app.route('/api/books/<book_id>', methods=['GET'])
def view_book_detail(book_id):
    try:
        book = book_service.get_book_details(book_id)
        return jsonify(book.to_dict()), 200
    except ValueError as e:
        return jsonify({"error": str(e)}), 404

if __name__ == '__main__':
    app.run(debug=True)