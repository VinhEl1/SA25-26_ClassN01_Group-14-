from persistence.book_repository import BookRepository
from datetime import datetime

class BookService:  # <--- Quan trọng là dòng này
    def __init__(self):
        self.repo = BookRepository()

    def add_book(self, title, author, year, isbn):
        if not title or not author:
            raise ValueError("Sách phải có Tiêu đề và Tác giả.")
        
        current_year = datetime.now().year
        if year > current_year:
            raise ValueError(f"Năm xuất bản không hợp lệ.")

        if len(str(isbn)) < 10:
            raise ValueError("Mã ISBN không hợp lệ.")

        return self.repo.save(title, author, year, isbn)

    def get_library_catalog(self):
        return self.repo.find_all()

    def get_book_details(self, book_id):
        book = self.repo.find_by_id(book_id)
        if not book:
            raise ValueError(f"Không tìm thấy sách ID: {book_id}")
        return book