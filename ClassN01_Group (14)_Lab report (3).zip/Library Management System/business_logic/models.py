class Book:
    def __init__(self, book_id, title, author, year, isbn):
        self.id = book_id
        self.title = title
        self.author = author
        self.year = year
        self.isbn = isbn
        self.is_borrowed = False  # Mặc định là chưa được mượn

    def to_dict(self):
        return {
            "id": self.id,
            "title": self.title,
            "author": self.author,
            "year": self.year,
            "isbn": self.isbn,
            "status": "Borrowed" if self.is_borrowed else "Available"
        }