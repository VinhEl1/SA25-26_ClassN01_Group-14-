from business_logic.models import Book

# Giả lập Database
book_db = {}
next_id = 1

class BookRepository:
    """Layer 3: Chỉ quan tâm đến việc Lưu và Lấy dữ liệu Sách"""

    def save(self, title, author, year, isbn):
        global next_id
        book_id = str(next_id)
        
        new_book = Book(book_id, title, author, year, isbn)
        book_db[book_id] = new_book
        
        next_id += 1
        return new_book

    def find_all(self):
        return list(book_db.values())

    def find_by_id(self, book_id):
        return book_db.get(book_id)
    
    # Có thể thêm hàm delete nếu muốn mở rộng