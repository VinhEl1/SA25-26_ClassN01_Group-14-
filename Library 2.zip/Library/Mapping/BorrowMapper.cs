﻿//using Library.DTOs;
//using Library.Models;

//namespace Library.Mapping
//{
//    public static class BorrowMapper
//    {
//        public static BorrowSlipDTO ToDTO(this BorrowSlip borrowSlip)
//        {
//            return new BorrowSlipDTO
//            {
//                BSlipID = borrowSlip.BSlipID,
//                BorrowDate = borrowSlip.BorrowDate,
//                DueDate = borrowSlip.DueDate,
//                StaffID = borrowSlip.StaffID,
//                Status = borrowSlip.Status,
//                MemberID = borrowSlip.BorrowDetails?.FirstOrDefault()?.MemberID ?? 0,

//                BookIDs = borrowSlip.BorrowDetails?
//                                   .Select(d => d.BookID)
//                                   .ToList() ?? new List<int>()
//            };
//        }

//        public static BorrowSlip ToModel(this BorrowSlipDTO dto)
//        {
//            return new BorrowSlip
//            {
//                BSlipID = dto.BSlipID,
//                BorrowDate = dto.BorrowDate,
//                DueDate = dto.DueDate,
//                StaffID = dto.StaffID,
//                Status = dto.Status,

//                BorrowDetails = dto.BookIDs.Select(id => new BorrowDetail
//                {
//                    BookID = id,
//                    MemberID = dto.MemberID,
//                    BSlipID = dto.BSlipID
//                }).ToList()
//            };
//        }
//        public static BorrowDetailDTO toBorrowDetailDTO(this BorrowDetail borrowDetail)
//        {
//            return new BorrowDetailDTO
//            {
//                BookTitle = borrowDetail.Book?.Title,
//                BookAuthor = borrowDetail.Book?.Author,
//                BorrowDate = borrowDetail.BorrowDate,
//                ReturnDate = borrowDetail.ReturnDate,
//                FineAmount = borrowDetail.Fine?.Amount
//            };
//        }
//        public static List<BorrowDetailDTO> ToBorrowDetailDTOs(this IEnumerable<BorrowDetail> borrowDetails)
//        {
//            return borrowDetails.Select(bd => bd.toBorrowDetailDTO()).ToList();
//        }
//    }
//}
