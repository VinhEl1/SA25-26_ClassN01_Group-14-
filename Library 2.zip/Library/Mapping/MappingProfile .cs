﻿using AutoMapper;
using Library.Models;
using Library.DTOs.Request;

namespace Library.Mapping
{
    public class MappingProfile : Profile
    {
        public MappingProfile() //sua map trong model
        {
            CreateMap<User, UserDTO>()
                .ForMember(dest => dest.Department, opt => opt.MapFrom(src => src is Admin ? ((Admin)src).Department : null))
                .ForMember(dest => dest.Position, opt => opt.MapFrom(src => src is Staff ? ((Staff)src).Position : null))
                .ForMember(dest => dest.Schedule, opt => opt.MapFrom(src => src is Staff ? ((Staff)src).Schedule : null))
                .ReverseMap();

            CreateMap<BorrowSlip, BorrowSlipDTO>().
                ForMember(dest => dest.BookIDs, opt => opt.MapFrom(src => src.BorrowDetails != null ? src.BorrowDetails.Select(bd => bd.BookID).ToList() : new List<int>()))
                .ReverseMap()
                .ForMember(dest => dest.BorrowDetails, opt => opt.Ignore());

            CreateMap<BorrowDetail, BorrowDetailDTO>()
                .ForMember(dest => dest.BookTitle, opt => opt.MapFrom(src => src.Book != null ? src.Book.Title : null))
                .ForMember(dest => dest.BookAuthor, opt => opt.MapFrom(src => src.Book != null ? src.Book.Author : null))
                .ForMember(dest => dest.FineAmount, opt => opt.MapFrom(src => src.Fine != null ? src.Fine.Amount : (decimal?)null))
                .ReverseMap();
        }
    }
}
