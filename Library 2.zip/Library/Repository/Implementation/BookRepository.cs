﻿using Library.Data;
using Library.DTOs.Request;
using Library.Models;
using Library.Models.Enum;
using Library.Repository.Interface;
using System.Data.Entity;

namespace Library.Repository.Implementation
{
    public class BookRepository : IBookRepository
    {

        private readonly DBContext _context;

        public BookRepository(DBContext context)
        {
            _context = context;
        }

        public async Task<Book> AddBook(Book book)
        {
            var entry = _context.Books.Add(book);
            await _context.SaveChangesAsync();

            return entry.Entity;
        }

        public IQueryable<Book> BookSearch(BookSearchRequestDTO dto)
        {
            var search = dto.Search;

            var query = _context.Books.Include(b => b.Audios).AsQueryable();

            if (!string.IsNullOrWhiteSpace(search))
            {
                query = query.Where(b =>  b.Title.Contains(search)
                            || b.Author.Contains(search)
                            || b.PublishYear.ToString().Contains(search)
                            || b.BookID.ToString().Contains(search));
            }

            return query.AsNoTracking();    
        }

        public async Task DeleteBook(int bookId) 
        {
            _context.Books.Remove(await getBookById(bookId));
            await _context.SaveChangesAsync();
        }

        public async Task<Book?> getBookById(int bookId)
        {
            return await _context.Books.FindAsync(bookId);
        }

        public async Task<Book> UpdateBook(Book book)
        {
            var existingBook = await _context.Books.FindAsync(book.BookID);
            existingBook.Title = book.Title;
            existingBook.Author = book.Author;
            existingBook.PublishYear = book.PublishYear;
            existingBook.ImageUrl = book.ImageUrl;
            await _context.SaveChangesAsync();

            return existingBook!;
        }
    }
}
