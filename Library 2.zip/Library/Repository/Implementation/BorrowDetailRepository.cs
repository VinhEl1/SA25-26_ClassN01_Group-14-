﻿using Library.Data;
using Library.Models;
using Library.Repository.Interface;
using System.Data.Entity;
using System.Linq;

namespace Library.Repository.Implementation
{
    public class BorrowDetailRepository : IBorrowDetailRepository
    {

        private readonly DBContext _context;

        public BorrowDetailRepository(DBContext context)
        {
            _context = context;
        }

        public async Task<BorrowDetail> AddBorrowDetail(BorrowDetail borrowDetail)
        {
            var entry = _context.BorrowDetails.Add(borrowDetail);
            await _context.SaveChangesAsync();

            return entry.Entity;
        }

        public async Task DeleteBorrowDetail(int borrowDetailId)
        {
            var entry = _context.BorrowDetails.Remove(_context.BorrowDetails.Find(borrowDetailId));
            await _context.SaveChangesAsync();
        }

        public async Task<BorrowDetail> GetBorrowDetailById(int id)
        {
            return await _context.BorrowDetails.SingleOrDefaultAsync(b => b.BorrowDetailID == id);
        }

        public IEnumerable<BorrowDetail> GetBorrowDetails(int MemberId ,string? search = null) 
        {
            var query = _context.BorrowDetails
                .Include(b => b.Book)
                .Include(b => b.Fine)
                .Where(b => b.MemberID == MemberId);

            if (!string.IsNullOrEmpty(search))
            {
                query = query.Where(b =>
                    b.Book.Title.Contains(search) ||
                    b.Book.Author.Contains(search) ||
                    b.BorrowDate.ToString().Contains(search) ||
                    b.ReturnDate.ToString().Contains(search));
            }

            var result = query
                .OrderByDescending(b => b.BorrowDate);

            return result;
        }

        public async Task<BorrowDetail> UpdateBorrowDetail(BorrowDetail borrowDetail, int BorrowID)
{
    // Tìm bản ghi cũ theo ID
    var exist = await _context.BorrowDetails.FirstOrDefaultAsync(b => b.BorrowDetailID == BorrowID);
    
    if (exist != null)
    {
        // Cập nhật các trường cần thiết
        // Quan trọng nhất là ReturnDate để đánh dấu đã trả
        exist.ReturnDate = borrowDetail.ReturnDate;
        
        // Cập nhật các khóa ngoại nếu có thay đổi (thường là giữ nguyên)
        if (borrowDetail.BSlipID > 0) exist.BSlipID = borrowDetail.BSlipID;
        if (borrowDetail.RSlipID > 0) exist.RSlipID = borrowDetail.RSlipID;
        if (borrowDetail.BookID > 0) exist.BookID = borrowDetail.BookID;
        if (borrowDetail.FineID > 0) exist.FineID = borrowDetail.FineID;

        // Lưu vào DB
        await _context.SaveChangesAsync();
    }
    
    return exist;
}
    }
}
