﻿using CloudinaryDotNet.Actions;
using Library.Repository.Interface;
using Microsoft.EntityFrameworkCore;
using Library.Data;
using Library.DTOs.Request;
using Library.Models;

namespace Library.Repository.Implementation
{
    public class AudioRepository : IAudioRepository
    {
        private readonly DBContext _context;

        public AudioRepository(DBContext context)
        {
            _context = context;
        }

        public async Task<Models.Audio> AddAudio(Models.Audio audio)
        {
            var entry = _context.Set<Models.Audio>().Add(audio);
            await _context.SaveChangesAsync();
            return entry.Entity;
        }

        public async Task DeleteAudio(int publicId)
        {
            var audio = getAudioById(publicId);
            _context.Set<Models.Audio>().Remove(await audio);
            await _context.SaveChangesAsync();
        }

        public async Task<Models.Audio> UpdateAudio(Models.Audio audio, int id)
        {
            var OldAudio = await getAudioById(id);
            OldAudio =  new Models.Audio
            {
                FileName = audio.FileName,
                AudioUrl = audio.AudioUrl,
                FileSize = audio.FileSize,
                TotalChunks = audio.TotalChunks,
                UploadedChunks = audio.UploadedChunks,
                IsComplete = audio.IsComplete,
            };

            return OldAudio;
        }
        
        public async Task<Models.Audio?> getAudioById(int audioId)
        {
            return await _context.Set<Models.Audio>().FirstOrDefaultAsync(a => a.AudioID == audioId);
        }
    }
}
