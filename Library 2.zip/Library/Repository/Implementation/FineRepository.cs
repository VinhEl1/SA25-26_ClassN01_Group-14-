﻿using Library.Models;
using Library.Data;
using Library.Repository.Interface;
using System.Data.Entity;

namespace Library.Repository.Implementation
{
    public class FineRepository : IFineRepository
    {

        private readonly DBContext _context;

        public FineRepository(DBContext context)
        {
            _context = context;
        }
        
        public async Task<Fine> AddFine(Fine fine)
        {
            var entry = _context.Fines.Add(fine);
            await _context.SaveChangesAsync();

            return entry.Entity;
        }

        public async Task DeleteFine(int fineId)
        {
            _context.Fines.Remove(_context.Fines.Find(fineId)!);
            await _context.SaveChangesAsync();
        }

        public async Task<Fine> GetFineById(int fineId)
        {
            return await _context.Fines.FindAsync(fineId)!;
        }

        public IEnumerable<Fine> GetFines(string? search = null)
        {
            return _context.Fines.Where(f => search == null
                                            || f.FineID.ToString().Contains(search)
                                            || f.IssuedDate.ToString().Contains(search)
                                            || f.Reason.Contains(search)
                                            || f.PaidDate.ToString().Contains(search)
                                            || f.BorrowDetail.BSlipID.ToString().Contains(search))
                .ToList();
        }

        public async Task<Fine> UpdateFine(Fine fine)
        {
            if (_context.Fines.Find(fine.FineID) is null)
                throw new Exception("Fine with the same ID not exists.");

            var existingFine = await _context.Fines.FindAsync(fine.FineID);
            existingFine.FineID = fine.FineID;
            existingFine.IssuedDate = fine.IssuedDate;
            existingFine.PaidDate = fine.PaidDate;
            existingFine.Reason = fine.Reason;
            existingFine.Status = fine.Status;
            existingFine.Amount = fine.Amount;
            _context.SaveChanges();

            return existingFine!;
        }
    }
}
