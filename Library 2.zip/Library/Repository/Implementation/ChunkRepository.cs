﻿using Library.Data;
using Library.Models;
using Library.Repository.Interface;
using Microsoft.EntityFrameworkCore;

namespace Library.Repository.Implementation
{
    public class ChunkRepository : IChunkRepository
    {
        private readonly DBContext _context;

        public ChunkRepository(DBContext context)
        {
            _context = context;
        }

        public async Task<AudioChunk> AddChunk(AudioChunk chunk)
        {
            await _context.AudioChunks.AddAsync(chunk); 
            await _context.SaveChangesAsync();
            return chunk;
        }

        public async Task<List<AudioChunk>> GetChunksByAudioId(int audioId)
        {
            return await _context.AudioChunks
                .Where<AudioChunk>(AudioChunk => AudioChunk.AudioID == audioId)
                .OrderBy(AudioChunk => AudioChunk.ChunkIndex)
                .ToListAsync();
        }
    }
}
