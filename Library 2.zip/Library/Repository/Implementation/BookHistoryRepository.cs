﻿using Library.Data;
using Library.Models;
using Library.Repository.Interface;
using Library.Service.Interface;
using System.Data.Entity;

namespace Library.Repository.Implementation
{
    public class BookHistoryRepository : IBookHistoryRepository
    {
        private readonly IBookRepository _bookRepository;
        private readonly DBContext _context;

        public BookHistoryRepository(DBContext context, IBookRepository bookRepository)
        {
            _context = context;
            _bookRepository = bookRepository;
        }

        public async Task<IEnumerable<BookHistory>> GetBookHistories(string? search = null)
        {
           return _context.BookHistories
                .Where(bh => string.IsNullOrEmpty(search)
                             || bh.ActionType.Contains(search)
                             || bh.BookID.ToString().Contains(search)
                             || bh.StaffID.ToString().Contains(search))
                .AsEnumerable();
        }

        public async Task<BookHistory> StatusForActionAdd(int id, int staffID)
        {
            var book = await _bookRepository.getBookById(id);

            var history = new BookHistory
            {
                BookID = id,
                StaffID = staffID,
                ActionType = "Add",
                ActionDate = DateTime.Now,
            };  

            await _context.BookHistories.AddAsync(history);
            await _context.SaveChangesAsync();
            return history;
        }

        public async Task<BookHistory> StatusForActionEdit(int id, int staffID)
        {
            var book = await _bookRepository.getBookById(id);

            var history = new BookHistory
            {
                BookID = id,
                StaffID = staffID,
                ActionType = "Edit",
                ActionDate = DateTime.Now,
            };

            await _context.BookHistories.AddAsync(history);
            await _context.SaveChangesAsync();
            return history;
        }

        public async Task<BookHistory> StatusForActionSoftRemove(int id, int staffID)
        {
            var book = await _bookRepository.getBookById(id);

            var history = new BookHistory
            {
                BookID = id,
                StaffID = staffID,
                ActionType = "Delete",
                ActionDate = DateTime.Now,
            };

            await _context.BookHistories.AddAsync(history);
            await _context.SaveChangesAsync();
            return history;
        }
    }
}
