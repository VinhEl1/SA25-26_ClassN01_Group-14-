﻿using Library.Data;
using Library.DTOs.Request;
using Library.Models;
using Library.Repository.Interface;
using Microsoft.EntityFrameworkCore;

namespace Library.Repository.Implementation
{
    public class UserRepository : IUserRepository
    {

        private readonly DBContext _context;

        public UserRepository(DBContext context)
        {
            _context = context;
        }

        public async Task<UserDTO> AddUser<T>(T user) where T : User
        {
            _context.Set<T>().Add(user);

            var entries = _context.ChangeTracker.Entries();
            foreach (var e in entries)
                Console.WriteLine($"{e.Entity.GetType().Name} - {e.State}");

            await _context.SaveChangesAsync();

            return new UserDTO
            {
                UserID = user.UserID,
                UserName = user.UserName,
                FullName = user.FullName,
                Email = user.Email,
                Phone = user.Phone,
                Role = user.Role,
                Department = user is Admin ? ((Admin)(object)user).Department : null,
                Position = user is Staff ? ((Staff)(object)user).Position : null,
                Schedule = user is Staff ? ((Staff)(object)user).Schedule : null
            };
        }

        public IQueryable<User> GetUsers()
        {
            return _context.Users.AsQueryable();
        }

        public IQueryable<Admin> GetAdmins()
        {
            return _context.Admins.AsQueryable();
        }

        public IQueryable<Staff> GetStaffs()
        {
            return _context.Staffs.AsQueryable();
        }

        public async Task DeleteUser(int userId, string role)
        {
            _context.Users.Remove(_context.Users.Find(userId)!);
            await _context.SaveChangesAsync();
        }

        public async Task<User> GetUserByUserName(string username, string role)
        {
            if (role == "Admin")
            {
                return await GetAdmins()
                    .FirstOrDefaultAsync(u => u.UserName == username);
            }
            else if (role == "Staff")
            {
                return await GetStaffs()
                    .FirstOrDefaultAsync(u => u.UserName == username);
            }
            else if (role == "User" || role == "Member")
            {
                return await GetUsers()
                    .FirstOrDefaultAsync(u => u.UserName == username && u.Role == role);
            }
            else
            {
                throw new Exception("Role not found");
            }
        }

        public IEnumerable<UserDTO> GetUsers(string? search = null)
        {
            var users = _context.Users
         .Where(u => string.IsNullOrWhiteSpace(search) ||
                     u.UserID.ToString().Contains(search) ||
                     u.UserName.Contains(search) ||
                     u.FullName.Contains(search) ||
                     u.Email.Contains(search) ||
                     u.Phone.Contains(search) ||
                     u.Role.Contains(search))
         .Select(u => new UserDTO
         {
             UserID = u.UserID,
             UserName = u.UserName,
             FullName = u.FullName,
             Email = u.Email,
             Phone = u.Phone,
             Role = u.Role
         });
            return users.ToList();
        }

        public async Task<UserDTO> UpdateUser(UserDTO userDto)
        {
            var user = new User { UserID = userDto.UserID };
            _context.Attach(user);

            user.UserName = userDto.UserName;
            user.Password = userDto.Password;
            user.Phone = userDto.Phone;
            user.Email = userDto.Email;
            user.Role = userDto.Role;

            if (user is Admin && userDto.Department != null)
                ((Admin)user).Department = userDto.Department;
            if (user is Staff)
            {
                ((Staff)user).Position = userDto.Position;
                ((Staff)user).Schedule = userDto.Schedule;
            }

            await _context.SaveChangesAsync();

            return new UserDTO
            {
                UserID = user.UserID,
                UserName = user.UserName,
                FullName = user.FullName,
                Email = user.Email,
                Phone = user.Phone,
                Role = user.Role,
                Department = user is Admin ? ((Admin)(object)user).Department : null,
                Position = user is Staff ? ((Staff)(object)user).Position : null,
                Schedule = user is Staff ? ((Staff)(object)user).Schedule : null
            };
        }



        public async Task<User> GetUserById(int userId, string role)
        {
            if (role == "Admin")
            {
                return await GetAdmins()
                    .FirstOrDefaultAsync(u => u.UserID == userId);
            }
            else if (role == "Staff")
            {
                return await GetStaffs()
                    .FirstOrDefaultAsync(u => u.UserID == userId);
            }
            else if (role == "User" || role == "Member")
            {
                return await GetUsers()
                    .FirstOrDefaultAsync(u => u.UserID == userId && u.Role == role);
            }
            else
            {
                throw new Exception("Role not found");
            }
        }
    }
}
