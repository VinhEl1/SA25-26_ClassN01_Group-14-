﻿using Library.Data;
using Library.Models;
using Library.Repository.Interface;
using System.Data.Entity;

namespace Library.Repository.Implementation
{
    public class MemberRepository : IMemberRepository
    {

        private readonly DBContext _context;

        public MemberRepository(DBContext context)
        {
            _context = context;
        }

        public async Task<Member> AddMember(Member member)
        {
            _context.Members.Add(member);
            await _context.SaveChangesAsync();

            return member;
        }

        public async Task DeleteMember(int memberId)
        {
            _context.Members.Remove(_context.Members.Find(memberId)!);
            await _context.SaveChangesAsync();
        }

        public async Task<Member> GetMemberById(int memberId)
        {
            return await _context.Members.FindAsync(memberId)!;
        }

        public IEnumerable<Member> GetMembers(string? search = null)
        {
            return _context.Members.Where(m => search == null
                                            || m.MemberID.ToString().Contains(search)
                                            || m.MemberName.Contains(search)
                                            || m.MemberPhone.Contains(search)
                                            || m.MemberAddress.Contains(search)
                                            || m.DOB.ToString().Contains(search)).ToList();
        }

        public async Task<Member> UpdateMember(Member member, int memberId)
        {
            var existingMember = await _context.Members.FindAsync(memberId);
            existingMember.MemberName = member.MemberName;
            existingMember.MemberPhone = member.MemberPhone;
            existingMember.MemberAddress = member.MemberAddress;
            existingMember.DOB = member.DOB;
            _context.SaveChangesAsync();

            return existingMember;
        }
    }
}
