﻿using Library.Data;
using Library.Models;
using Library.Repository.Interface;
using System.Data.Entity;

namespace Library.Repository.Implementation
{
    public class BorrowSlipRepository : IBorrowSlipRepository
    {

        private readonly DBContext _context;

        public BorrowSlipRepository(DBContext context)
        {
            _context = context;
        }

        public async Task<BorrowSlip> addBorrowSlip(BorrowSlip borrowSlip)
        {
            
            _context.BorrowSlips.Add(borrowSlip);
            await _context.SaveChangesAsync();

            return borrowSlip;
        }

        public async Task deleteBorrowSlip(int borrowSlipId)
        {
            var entry = await getBorrowSlipById(borrowSlipId);
            entry.Status = $"Deleted{DateTime.Now:yyyy-MM-dd-H}";

            await _context.SaveChangesAsync();
        }

        public async Task<BorrowSlip> getBorrowSlipById(int borrowSlipId)
        {
            return await _context.BorrowSlips.FindAsync(borrowSlipId);
        }

        public IEnumerable<BorrowSlip> GetBorrowSlips(string? search = null)
        {
            return _context.BorrowSlips
                .Where(b => string.IsNullOrEmpty(search) || b.BSlipID.ToString().Contains(search) || b.BorrowDate.ToString().Contains(search) || b.DueDate.ToString().Contains(search) || b.StaffID.ToString().Contains(search) || b.MemberID.ToString().Contains(search) || b.Status.Contains(search))
                .ToList();
        }

        public async Task saveChange(BorrowSlip borrowSlip)
        {
            _context.BorrowSlips.AddAsync(borrowSlip);
            await _context.SaveChangesAsync();
        }

        public async Task saveDetail(List<BorrowDetail> detail)
        {
            _context.BorrowDetails.AddRangeAsync(detail);
            await _context.SaveChangesAsync();
        }

        public async Task<BorrowSlip> updateBorrowSlip(BorrowSlip borrowSlip)
        {
            var existingBorrowSlip = await _context.BorrowSlips.FindAsync(borrowSlip.BSlipID);
            existingBorrowSlip.BorrowDate = borrowSlip.BorrowDate;
            existingBorrowSlip.DueDate = borrowSlip.DueDate;
            existingBorrowSlip.StaffID = borrowSlip.StaffID;
            existingBorrowSlip.Status = borrowSlip.Status;
            await _context.SaveChangesAsync();

            return existingBorrowSlip!;
        }
    }
}
