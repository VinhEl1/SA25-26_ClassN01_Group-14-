﻿using Library.Data;
using Library.Models;
using Library.Repository.Interface;
using System.Data.Entity;

namespace Library.Repository.Implementation
{
    public class ReturnSlipRepository : IReturnSlipRepository
    {

        private readonly DBContext _context;

        public ReturnSlipRepository(DBContext context)
        {
            _context = context;
        }

        public async Task<ReturnSlip> AddReturnSlip(ReturnSlip returnSlip)
        {
            var entry = _context.ReturnSlips.Add(returnSlip);
            await _context.SaveChangesAsync();

            return entry.Entity;
        }

        public async Task DeleteReturnSlip(int returnSlipId)
        {
            _context.ReturnSlips.Remove(_context.ReturnSlips.Find(returnSlipId)!);
            await _context.SaveChangesAsync();
        }

        public async Task<ReturnSlip> GetReturnSlipById(int returnSlipId)
        {
            return await _context.ReturnSlips.FindAsync(returnSlipId)!;
        }

      public IEnumerable<ReturnSlip> GetReturnSlips(string? search = null)
{
    return _context.ReturnSlips
        .Where(rs => string.IsNullOrEmpty(search)
                  || rs.RSlipID.ToString().Contains(search)
                  || rs.Status.Contains(search)
                  || (rs.BorrowDetail != null && rs.BorrowDetail.BSlipID.ToString().Contains(search)))
        .ToList();
}

        public async Task<ReturnSlip> UpdateReturnSlip(ReturnSlip returnSlip)
        {
            if (await GetReturnSlipById(returnSlip.RSlipID) is null)
                throw new Exception("return slip not exist");

            var existingReturnSlip = await _context.ReturnSlips.FindAsync(returnSlip.RSlipID);
            existingReturnSlip.DueDate = returnSlip.DueDate;
            existingReturnSlip.ReturnDate = returnSlip.ReturnDate;
            existingReturnSlip.StaffID = returnSlip.StaffID;
            existingReturnSlip.Status = returnSlip.Status;
            _context.SaveChanges();

            return existingReturnSlip!;
        }
    }
}
