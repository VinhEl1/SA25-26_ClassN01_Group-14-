﻿using Library.Data;
using Library.Models;
using Library.Repository.Interface;
using Microsoft.EntityFrameworkCore;

namespace Library.Repository.Implementation
{
    public class loginRepository : IloginRepository
    {
        private readonly DBContext _context;
        public loginRepository(DBContext context) => _context = context;

        public async Task AddUserAsync(User user)
        {
            _context.Users.Add(user);
            await _context.SaveChangesAsync();
        }

        public async Task<bool> ExistAsync(string username)
        {
            return await _context.Users.AnyAsync(u => u.UserName.ToLower() == username.Trim().ToLower());
        }

        public async Task<User?> GetUserByUsernameAsync(string username)
        {
            return await _context.Users
                .Include(u => u.Member) 
                .FirstOrDefaultAsync(u => u.UserName.ToLower() == username.Trim().ToLower());
        }
    }
}