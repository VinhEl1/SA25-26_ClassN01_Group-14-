﻿using Library.Models;

namespace Library.Repository.Interface
{
    public interface IMemberRepository
    {
        IEnumerable<Member>  GetMembers(string? search = null);
        Task<Member> AddMember(Member member);
        Task<Member> UpdateMember(Member member, int memberId);
        Task DeleteMember(int memberId);
        Task<Member> GetMemberById(int memberId);
    }
}
