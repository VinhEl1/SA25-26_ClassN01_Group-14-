﻿using Library.Models;

namespace Library.Repository.Interface
{
    public interface IReturnSlipRepository
    {
        IEnumerable<ReturnSlip> GetReturnSlips(string? search = null);
        Task<ReturnSlip> AddReturnSlip(ReturnSlip returnSlip);
        Task<ReturnSlip> UpdateReturnSlip(ReturnSlip returnSlip);
        Task DeleteReturnSlip(int returnSlipId);
        Task<ReturnSlip> GetReturnSlipById(int returnSlipId);
    }
}
