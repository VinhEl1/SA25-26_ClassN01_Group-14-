﻿using Library.Models;

namespace Library.Repository.Interface
{
    public interface IChunkRepository
    {
        Task<AudioChunk> AddChunk(AudioChunk chunk);
        Task<List<AudioChunk>> GetChunksByAudioId(int audioId);
    }
}
