﻿using Library.Models;

namespace Library.Repository.Interface
{
    public interface IloginRepository
    {
        Task<User?> GetUserByUsernameAsync(string username);
        Task AddUserAsync(User user);
        Task<bool> ExistAsync(string username);
    }
}
