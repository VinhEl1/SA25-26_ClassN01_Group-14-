﻿using Library.Models;

namespace Library.Repository.Interface
{
    public interface IFineRepository
    {
        IEnumerable<Fine> GetFines(string? search = null);
        Task<Fine> AddFine(Fine fine);
        Task<Fine> UpdateFine(Fine fine);
        Task DeleteFine(int fineId);
        Task<Fine> GetFineById(int fineId);
    }
}
