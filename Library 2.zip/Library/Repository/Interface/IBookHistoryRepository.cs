﻿using Library.Models;

namespace Library.Repository.Interface
{
    public interface IBookHistoryRepository
    {
        Task<BookHistory> StatusForActionAdd(int id, int staffID);
        Task<BookHistory> StatusForActionEdit(int id, int staffID);
        Task<BookHistory> StatusForActionSoftRemove(int id, int staffID );
        Task<IEnumerable<BookHistory>> GetBookHistories(string? search = null);
    }
}
