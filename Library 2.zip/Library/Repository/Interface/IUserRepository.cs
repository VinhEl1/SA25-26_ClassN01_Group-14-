﻿using Library.DTOs.Request;
using Library.Models;

namespace Library.Repository.Interface
{
    public interface IUserRepository
    {
        IEnumerable<UserDTO> GetUsers(string? search = null);
        Task<UserDTO> AddUser<T>(T user) where T : User;
        Task<UserDTO> UpdateUser(UserDTO userDto);
        Task DeleteUser(int userId, string role);
        Task<User> GetUserByUserName(string name, string role);
        IQueryable<User> GetUsers();
        IQueryable<Admin> GetAdmins();
        IQueryable<Staff> GetStaffs();
        Task<User> GetUserById(int id, string role);
    }
}
