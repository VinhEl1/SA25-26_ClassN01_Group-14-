﻿using CloudinaryDotNet.Actions;
using Library.Models;

namespace Library.Repository.Interface
{
    public interface IAudioRepository
    {
        Task<Models.Audio> AddAudio(Models.Audio audio);
        Task<Models.Audio> UpdateAudio(Models.Audio audio, int id);
        Task DeleteAudio(int publicId);

    }
}
