﻿using Library.DTOs.Request;
using Library.Models;
using Microsoft.AspNetCore.Mvc;
using System.Numerics;

namespace Library.Repository.Interface
{
    public interface IBookRepository
    {
        IQueryable<Book> BookSearch(BookSearchRequestDTO dto);
        Task<Book> AddBook(Book book);
        Task<Book> UpdateBook(Book book);
        Task DeleteBook(int bookId);
        Task<Book> getBookById(int bookId);
    }
}   
