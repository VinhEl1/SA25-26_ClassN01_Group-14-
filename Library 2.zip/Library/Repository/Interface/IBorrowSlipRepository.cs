﻿using Library.Models;

namespace Library.Repository.Interface
{
    public interface IBorrowSlipRepository
    {
        IEnumerable<BorrowSlip> GetBorrowSlips(string? search = null);
        Task<BorrowSlip> addBorrowSlip(BorrowSlip borrowSlip);
        Task<BorrowSlip> updateBorrowSlip(BorrowSlip borrowSlip);
        Task deleteBorrowSlip(int borrowSlipId);
        Task<BorrowSlip> getBorrowSlipById(int borrowSlipId);
        Task saveChange(BorrowSlip borrowSlip);
        Task saveDetail(List<BorrowDetail> detail);
    }
}
