﻿using Library.Models;

namespace Library.Repository.Interface
{
    public interface IBorrowDetailRepository
    {
        IEnumerable<BorrowDetail> GetBorrowDetails(int MemberId, string? search=null);
        Task<BorrowDetail> AddBorrowDetail(BorrowDetail borrowDetail);
        Task<BorrowDetail> UpdateBorrowDetail(BorrowDetail borrowDetail, int BorrowID);
        Task DeleteBorrowDetail(int borrowDetailId);
        Task<BorrowDetail> GetBorrowDetailById(int id);
    }
}
