﻿using Library.Helpers;

namespace Library.Middleware
{
    public class JwtMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly JwtHelper _jwtHelper;

        public JwtMiddleware(RequestDelegate next, JwtHelper jwtHelper)
        {
            _next = next;
            _jwtHelper = jwtHelper;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            // 1. Thử lấy Token từ Header (nếu có) để nhận diện User
            if (context.Request.Headers.TryGetValue("Authorization", out var authHeaderValues))
            {
                var authHeader = authHeaderValues.FirstOrDefault();
                if (!string.IsNullOrEmpty(authHeader) && authHeader.StartsWith("Bearer "))
                {
                    var token = authHeader.Substring("Bearer ".Length).Trim();
                    var principal = _jwtHelper.ValidateToken(token);
                    
                    if (principal != null)
                    {
                        // Gán thông tin user vào hệ thống nếu token đúng
                        context.User = principal;
                    }
                }
            }

            // 2. QUAN TRỌNG: Cho phép đi qua luôn, không bao giờ chặn lại (Không trả về 401)
            // Điều này giúp bạn thực hiện Add, Edit, Delete sách/độc giả bình thường.
            await _next(context);
        }
    }
}