﻿//using System.Net;
//using System.Text.Json;

//namespace Library.Middleware
//{
//    public class ExceptionMiddleware
//    {
//        private readonly RequestDelegate _next;

//        public ExceptionMiddleware(RequestDelegate next)
//        {
//            _next = next;
//        }

//        public async Task InvokeAsync(HttpContext context)
//        {
//            try
//            {
//                await _next(context);
//            }
//            catch (KeyNotFoundException ex)
//            {
//                await HandleExceptionAsync(context, HttpStatusCode.NotFound, ex.Message);
//            }
//            catch (ArgumentException ex)
//            {
//                await HandleExceptionAsync(context, HttpStatusCode.BadRequest, ex.Message);
//            }
//            catch (Exception ex)
//            {
//                await HandleExceptionAsync(context, HttpStatusCode.InternalServerError,
//                    "An unexpected error occurred.");
//            }
//        }

//        private static async Task HandleExceptionAsync(HttpContext context, HttpStatusCode statusCode, string message)
//        {
//            context.Response.ContentType = "application/json";
//            context.Response.StatusCode = (int)statusCode;

//            var result = JsonSerializer.Serialize(new
//            {
//                error = message,
//                status = (int)statusCode
//            });

//            await context.Response.WriteAsync(result);
//        }
//    }
//}
