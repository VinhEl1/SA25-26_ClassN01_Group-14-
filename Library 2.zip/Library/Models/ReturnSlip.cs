﻿using System.Text.Json.Serialization;

namespace Library.Models
{
    public class ReturnSlip
    {
        public int RSlipID { get; set; }
        public DateTime DueDate { get; set; }
        public DateTime ReturnDate { get; set; }
        public int StaffID { get; set; }
        public string Status { get; set; }

        [JsonIgnore]
        public BorrowDetail? BorrowDetail { get; set; }
        [JsonIgnore]
        public Staff? Staff { get; set; }
    }
}
