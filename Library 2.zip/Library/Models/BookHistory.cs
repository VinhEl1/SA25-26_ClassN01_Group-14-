﻿using System.Text.Json.Serialization;

namespace Library.Models
{
    public class BookHistory
    {
        public int HistoryID { get; set; }
        public int StaffID { get; set; }
        public int BookID { get; set; }
        public DateTime ActionDate { get; set; }
        public string ActionType { get; set; }

        [JsonIgnore]
        public Book? Book { get; set; }
        [JsonIgnore]
        public Staff? Staff { get; set; }
    }
}
