﻿using System.Text.Json.Serialization;

namespace Library.Models
{
    public class BorrowDetail
    {
        public int BorrowDetailID { get; set; }
        public DateTime BorrowDate { get; set; }
        public DateTime? ReturnDate { get; set; }

        
        public int MemberID { get; set; }
        public int BookID { get; set; }
        public int? BSlipID { get; set; }
        public int? RSlipID { get; set; }
        public int? FineID { get; set; }

        [JsonIgnore]
        public BorrowSlip? BorrowSlip { get; set; }
        [JsonIgnore]
        public ReturnSlip? ReturnSlip { get; set; }
        [JsonIgnore]
        public Member? Member { get; set; }
        [JsonIgnore]
        public Book? Book { get; set; }
        [JsonIgnore]
        public Fine? Fine { get; set; }
    }
}
