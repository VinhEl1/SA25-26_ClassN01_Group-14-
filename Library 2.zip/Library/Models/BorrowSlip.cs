﻿//Định nghĩa phiếu mượn
using System.Text.Json.Serialization;

namespace Library.Models
{
    public class BorrowSlip
    {
        public int BSlipID { get; set; }
        public DateTime BorrowDate { get; set; }
        public DateTime DueDate { get; set; }
        public int StaffID { get; set; }
        public int MemberID { get; set; }
        public string Status { get; set; }

        [JsonIgnore]
        public ICollection<BorrowDetail> BorrowDetails { get; set; } = new List<BorrowDetail>();
        [JsonIgnore]
        public Staff? Staff { get; set; }
        [JsonIgnore]
        public Member? Member { get; set; }
    }
}
