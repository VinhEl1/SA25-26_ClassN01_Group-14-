﻿using System.Text.Json.Serialization;

namespace Library.Models
{
    public class AudioChunk
    {
        public int ChunkID { get; set; }
        public int AudioID { get; set; }

        public int ChunkIndex { get; set; }
        public string? TempPath { get; set; }
        public string? ChunkUrl { get; set; }
        public long ChunkSize { get; set; }

        [JsonIgnore]
        public Audio Audio { get; set; }

    }
}
