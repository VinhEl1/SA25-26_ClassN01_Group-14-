﻿//Định nghĩa cấu trúc cuốn sách
using Library.Models.Enum;
using System.Text.Json.Serialization;

namespace Library.Models
{
    public class Book
    {
        public int BookID { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string PublishYear { get; set; }
        public BookStatusEnum? Status { get; set; }
        public string? ImageUrl { get; set; }
        public double Price { get; set; }
        public int Stock { get; set; }
        [JsonIgnore]
        public ICollection<BookHistory>? BookHistories { get; set; }

        [JsonIgnore]
        public ICollection<Audio>? Audios { get; set; }
    }
}
