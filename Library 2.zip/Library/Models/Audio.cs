﻿using System.Text.Json.Serialization;

namespace Library.Models
{
    public class Audio
    {
        public int AudioID { get; set; }
        public int BookID { get; set; }

        public string FileName { get; set; }
        public string? AudioUrl { get; set; }
        public long FileSize { get; set; }

        public int TotalChunks { get; set; }
        public int UploadedChunks { get; set; }
        public bool IsComplete { get; set; }

        public DateTime UploadedAt { get; set; } = DateTime.Now;

        [JsonIgnore]
        public Book Book { get; set; }

        [JsonIgnore]
        public ICollection<AudioChunk>? AudioChunks { get; set; }
    }
}
