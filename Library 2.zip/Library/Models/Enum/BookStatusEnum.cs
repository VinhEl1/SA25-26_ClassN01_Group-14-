﻿namespace Library.Models.Enum
{
    public enum BookStatusEnum
    {
        Old = 1,
        New = 2,
        Deleted = 3,
        
        // THÊM DÒNG NÀY VÀO:
        Available = 4
    }
}