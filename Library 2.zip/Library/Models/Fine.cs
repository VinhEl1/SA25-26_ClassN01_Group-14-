﻿//Định nghĩa phiếu phạt
using System.Text.Json.Serialization;

namespace Library.Models
{
    public class Fine
    {
        public int FineID { get; set; }
        public DateTime IssuedDate { get; set; }
        public DateTime PaidDate { get; set; }
        public string Reason { get; set; }
        public string Status { get; set; }
        public decimal Amount { get; set; }

        [JsonIgnore]
        public BorrowDetail BorrowDetail { get; set; }
    }
}
  