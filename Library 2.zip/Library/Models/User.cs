﻿using System.Text.Json.Serialization;

namespace Library.Models
{
    public class User
    {
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string Phone { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }

        [JsonIgnore]
        public Member? Member { get; set; }
    }
    public class Admin : User
    {
        public string Department { get; set; }
    }
    public class Staff : User
    {
        public string Position { get; set; }
        public string Schedule { get; set; }

        [JsonIgnore]
        public List<BorrowSlip>? BorrowSlips { get; set; }
        [JsonIgnore]
        public List<ReturnSlip>? ReturnSlips { get; set; }
    }
}
