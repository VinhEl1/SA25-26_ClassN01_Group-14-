﻿// File: Library/Models/Member.cs
using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Library.Models
{
    public class Member
    {
        public int MemberID { get; set; }

        // Trường này dùng cho logic MemberName
        public string MemberName { get; set; } 

        // Thêm FullName để sửa lỗi ở MemberController (Dòng 44)
        public string FullName { get => MemberName; set => MemberName = value; }

        public string MemberPhone { get; set; }
        
        // Thêm Phone làm alias để code Service không bị lỗi nếu bạn chưa đổi tên
        public string Phone { get => MemberPhone; set => MemberPhone = value; }

        public string MemberAddress { get; set; }
        public DateTime DOB { get; set; }

        // --- BỔ SUNG CÁC TRƯỜNG DƯỚI ĐÂY ĐỂ HẾT LỖI TRONG SERVICE ---
        public string? Email { get; set; }
        public string? CardNumber { get; set; }
        public DateTime JoinDate { get; set; }
        // ----------------------------------------------------------

        public string? Status { get; set; } 

        [JsonIgnore]
        public virtual ICollection<BorrowDetail>? BorrowDetails { get; set; }
        
        [JsonIgnore]
        public int? UserID { get; set; }
        
        [JsonIgnore]
        public User? User { get; set; }
        
        [JsonIgnore]
        public virtual ICollection<BorrowSlip>? BorrowSlips { get; set; }
    }
}