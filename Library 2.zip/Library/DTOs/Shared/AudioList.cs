﻿using Microsoft.AspNetCore.Mvc;

namespace Library.DTOs.Shared
{
    public class AudioList
    {
        public string? FileName { get; set; }
        public int? AudioID { get; set; }
        public string? AudioUrl { get; set; }
    }
}
