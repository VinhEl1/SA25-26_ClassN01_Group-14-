﻿namespace Library.DTOs.Shared
{
    public class PageResult<T>
    {
        public int Page { get; set; }
        public int PageSize { get; set; }
        public int TotalItem { get; set; }
        public int TotalPage { get; set; }
        public IEnumerable<T> Items { get; set; }
    }
}
