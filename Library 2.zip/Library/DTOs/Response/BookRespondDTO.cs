﻿using AutoMapper;
using Library.DTOs.Shared;
using Library.Models;

namespace Library.DTOs.Response
{
    public class BookRespondDTO
    {
        public int BookID { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string? PublishYear { get; set; }
        public string? ImageUrl { get; set; }
        public List<AudioList>? Audios { get; set; }
        public double Price { get; set; }
        public int Stock { get; set; }
    }

   public class BookRespondProfile : Profile
{
    public BookRespondProfile()
    {
        // 1. Phải có dòng này để Map các mục con trong danh sách Audio
        CreateMap<Library.Models.Audio, Library.DTOs.Shared.AudioList>();

        // 2. Map từ Book sang BookRespondDTO
        CreateMap<Library.Models.Book, BookRespondDTO>();
    }
}
}