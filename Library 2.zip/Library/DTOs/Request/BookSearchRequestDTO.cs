﻿namespace Library.DTOs.Request
{
    public class BookSearchRequestDTO
    {
        public string? Search { get; set; }
    }
}
