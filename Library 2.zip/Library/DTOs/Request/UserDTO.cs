﻿namespace Library.DTOs.Request
{
    public class UserDTO 
    {
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string Phone { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }

        public string Department { get; set; } // For Admin
        public string Position { get; set; } // For Staff
        public string Schedule { get; set; } // For Staff
    }
}
