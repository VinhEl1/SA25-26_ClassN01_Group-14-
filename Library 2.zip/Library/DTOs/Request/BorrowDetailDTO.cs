﻿namespace Library.DTOs.Request
{
    public class BorrowDetailDTO
    {
        public string BookTitle { get; set; }
        public string BookAuthor { get; set; }

        // Borrow info
        public DateTime BorrowDate { get; set; }
        public DateTime? ReturnDate { get; set; }

        // Fine info
        public decimal? FineAmount { get; set; }
    }
}
