﻿namespace Library.DTOs.Request;
public class BorrowSlipDTO
{
    public int BSlipID { get; set; } // Sẽ nhận từ DB sau khi lưu
    public int MemberID { get; set; } // Quan trọng: ID độc giả
    public int StaffID { get; set; }  // ID người thực hiện (admin)
    public DateTime DueDate { get; set; } // Ngày hẹn trả
    public List<int> BookIDs { get; set; } // Danh sách ID các cuốn sách mượn
    public string Status { get; set; } = "Borrowing";
}