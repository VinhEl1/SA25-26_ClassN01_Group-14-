﻿using AutoMapper;
using Library.Models;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http; 

namespace Library.DTOs.Request
{
    public class BookRequestDTO
    {
        [Required(ErrorMessage = "Tên sách là bắt buộc")]
        public string Title { get; set; }

        [Required(ErrorMessage = "Tác giả là bắt buộc")]
        public string Author { get; set; }

        [Range(0, double.MaxValue, ErrorMessage = "Giá tiền không hợp lệ")]
        public double Price { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "Số lượng tồn kho không hợp lệ")]
        public int Stock { get; set; } 

        public string? PublishYear { get; set; } 

        public string? ImageUrl { get; set; } 

        public IFormFile? AudioFile { get; set; }
        
        public string? Category { get; set; }
    }

    public class BookProfile : Profile
    {
        public BookProfile()
        {
            // AutoMapper tự động map các trường trùng tên (Title, Price, Stock...)
            // Nó sẽ tự bỏ qua AudioFile vì Entity Book không có trường này.
            CreateMap<BookRequestDTO, Models.Book>();
        }
    }   
}