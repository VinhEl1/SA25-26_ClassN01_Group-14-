﻿using AutoMapper;

namespace Library.DTOs.Request
{
    public class EditBookDTO
    {
        public IFormFile ImageFile { get; set; } = null!;
    }

    public class EditBookProfile : Profile
    {
        public EditBookProfile()
        {
            CreateMap<EditBookDTO, Models.Book>()
                .ForMember(dest => dest.ImageUrl, opt => opt.Ignore());
        }
    }
}
