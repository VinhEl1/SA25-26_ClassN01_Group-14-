﻿using Library.Data.Helper;
using Library.Models;
using Library.Models.Enum;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel;

namespace Library.Data
{
    public class DBContext : DbContext
    {
        public DbSet<Book> Books { get; set; }
        public DbSet<Audio> Audios { get; set; }
        public DbSet<AudioChunk> AudioChunks { get; set; }
        public DbSet<BookHistory> BookHistories { get; set; }
        public DbSet<BorrowDetail> BorrowDetails { get; set; }
        public DbSet<BorrowSlip> BorrowSlips { get; set; }
        public DbSet<Fine> Fines { get; set; }
        public DbSet<Member> Members { get; set; }
        public DbSet<ReturnSlip> ReturnSlips { get; set; }
        public DbSet<Staff> Staffs { get; set; }
        public DbSet<Admin> Admins { get; set; }
        public DbSet<User> Users { get; set; }

        public DBContext(DbContextOptions<DBContext> options) : base(options)
        {
        }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Book>(entity =>
            {
                entity.HasKey(e => e.BookID);
                entity.Property(e => e.BookID).ValueGeneratedOnAdd();
                entity.Property(e => e.Title).IsRequired().HasMaxLength(200);
                entity.Property(e => e.Author).IsRequired().HasMaxLength(100);
                entity.Property(e => e.PublishYear).IsRequired().HasMaxLength(4);
                entity.Property(e => e.Status)
                .HasConversion(
                    v => EnumConverters.ToStringValue(v),   // enum -> string
                    v => EnumConverters.FromStringValue(v)
                    );

                entity.Property(e => e.ImageUrl).HasMaxLength(500);

                entity.HasMany(e => e.BookHistories)
                      .WithOne(bh => bh.Book)
                      .HasForeignKey(bh => bh.BookID)
                      .OnDelete(DeleteBehavior.Cascade);
            });

            modelBuilder.Entity<Book>().HasQueryFilter(b => b.Status != BookStatusEnum.Deleted);

            modelBuilder.Entity<Audio>(entity =>
            {
                entity.HasKey(e => e.AudioID);
                entity.Property(e => e.AudioID).ValueGeneratedOnAdd();
                entity.Property(e => e.FileName).IsRequired().HasMaxLength(200);
                entity.Property(e => e.AudioUrl);
                entity.Property(e => e.FileSize).IsRequired();
                entity.Property(e => e.TotalChunks).IsRequired();
                entity.Property(e => e.UploadedChunks).IsRequired();
                entity.Property(e => e.IsComplete).IsRequired();
                entity.Property(e => e.UploadedAt).IsRequired();

                entity.HasOne(a => a.Book)
                      .WithMany(b => b.Audios)
                      .HasForeignKey(a => a.BookID)
                      .OnDelete(DeleteBehavior.Cascade);

                entity.HasMany(a => a.AudioChunks)
                      .WithOne(ac => ac.Audio)
                      .HasForeignKey(ac => ac.AudioID)
                      .OnDelete(DeleteBehavior.Cascade);
            });

            modelBuilder.Entity<AudioChunk>(entity =>
            {
                entity.HasKey(e => e.ChunkID);
                entity.Property(e => e.ChunkID).ValueGeneratedOnAdd();
                entity.Property(e => e.ChunkIndex).IsRequired();
                entity.Property(e => e.ChunkSize).IsRequired();
                entity.Property(e => e.TempPath);
                entity.Property(e => e.ChunkUrl).IsRequired();

                entity.HasOne(ac => ac.Audio)
                      .WithMany(a => a.AudioChunks)
                      .HasForeignKey(ac => ac.AudioID)
                      .OnDelete(DeleteBehavior.Cascade);
            });

            modelBuilder.Entity<BookHistory>(entity =>
            {
                entity.HasKey(e => e.HistoryID);
                entity.Property(e => e.HistoryID).ValueGeneratedOnAdd();
                entity.Property(e => e.StaffID);
                entity.Property(e => e.ActionDate).IsRequired().HasMaxLength(50);
                entity.Property(e => e.ActionType).IsRequired();

                entity.HasOne(s => s.Staff)
                      .WithMany()
                      .HasForeignKey(s => s.StaffID)
                      .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<BorrowDetail>(entity =>
            {
                entity.HasKey(e => e.BorrowDetailID);
                entity.Property(e => e.BorrowDetailID).ValueGeneratedOnAdd();
                entity.Property(e => e.BorrowDate).IsRequired();
                entity.Property(e => e.ReturnDate);

                entity.HasOne(d => d.Member)
                      .WithMany(p => p.BorrowDetails)
                      .HasForeignKey(d => d.MemberID)
                      .OnDelete(DeleteBehavior.NoAction);

                entity.HasOne(d => d.Book)
                      .WithMany()
                      .HasForeignKey(d => d.BookID)
                      .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(d => d.BorrowSlip)
                      .WithMany(s => s.BorrowDetails)
                      .HasForeignKey(d => d.BSlipID)
                      .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(d => d.ReturnSlip)
                      .WithOne(s => s.BorrowDetail)
                      .HasForeignKey<BorrowDetail>(d => d.RSlipID)
                      .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(d => d.Fine)
                      .WithOne(s => s.BorrowDetail)
                      .HasForeignKey<BorrowDetail>(d => d.FineID)
                      .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<BorrowSlip>(entity =>
            {
                entity.HasKey(e => e.BSlipID);
                entity.Property(e => e.BSlipID).ValueGeneratedOnAdd();
                entity.Property(e => e.BorrowDate).IsRequired();
                entity.Property(e => e.DueDate).IsRequired();
                entity.Property(e => e.Status).IsRequired().HasMaxLength(20);

                entity.HasOne(d => d.Staff)
                      .WithMany(p => p.BorrowSlips)
                      .HasForeignKey(d => d.StaffID)
                      .OnDelete(DeleteBehavior.NoAction);

                entity.HasOne(d => d.Member)
                      .WithMany(p => p.BorrowSlips)
                      .HasForeignKey(d => d.MemberID)
                      .OnDelete(DeleteBehavior.NoAction);
            });

            modelBuilder.Entity<ReturnSlip>(entity =>
            {
                entity.HasKey(e => e.RSlipID);
                entity.Property(e => e.RSlipID).ValueGeneratedOnAdd();
                entity.Property(e => e.ReturnDate).IsRequired();
                entity.Property(e => e.DueDate).IsRequired();
                entity.Property(e => e.Status).IsRequired().HasMaxLength(20);

                entity.HasOne(d => d.Staff)
                      .WithMany(p => p.ReturnSlips)
                      .HasForeignKey(d => d.StaffID)
                      .OnDelete(DeleteBehavior.Cascade);
            });

            modelBuilder.Entity<Fine>(entity =>
            {
                entity.HasKey(e => e.FineID);
                entity.Property(e => e.FineID).ValueGeneratedOnAdd();
                entity.Property(e => e.IssuedDate).IsRequired();
                entity.Property(e => e.PaidDate);
                entity.Property(e => e.Reason).IsRequired().HasMaxLength(200);
                entity.Property(e => e.Amount).IsRequired().HasColumnType("decimal(18,0)");
            });

            modelBuilder.Entity<Member>(entity =>
            {
                entity.HasKey(e => e.MemberID);
                entity.Property(e => e.MemberID).ValueGeneratedOnAdd();
                entity.Property(e => e.MemberName).IsRequired().HasMaxLength(100);
                entity.Property(e => e.MemberPhone).IsRequired().HasMaxLength(15);
                entity.Property(e => e.MemberAddress).IsRequired().HasMaxLength(200);
                entity.Property(e => e.DOB).IsRequired();

                entity.HasOne(d => d.User)
                      .WithOne(p => p.Member)
                      .HasForeignKey<Member>(d => d.UserID)
                      .OnDelete(DeleteBehavior.SetNull);
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.ToTable("Users");
                entity.HasKey(e => e.UserID);
                entity.Property(e => e.UserID).ValueGeneratedOnAdd();
                entity.HasIndex(e => e.UserName).IsUnique();
                entity.Property(e => e.FullName).IsRequired().HasMaxLength(50);
                entity.Property(e => e.Email).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Password).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Role).IsRequired().HasMaxLength(20);
            });

            modelBuilder.Entity<Admin>(entity =>
            {
                entity.ToTable("Admins").HasBaseType<User>();
                entity.Property(e => e.Department).IsRequired().HasMaxLength(100);
            });

            modelBuilder.Entity<Staff>(entity =>
            {
                entity.ToTable("Staffs").HasBaseType<User>();
                entity.Property(e => e.Position).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Schedule).IsRequired().HasMaxLength(100);
            });
        }

    }
}
