﻿using Library.Models.Enum;

namespace Library.Data.Helper
{
    public static class EnumConverters
    {
        public static string? ToStringValue(BookStatusEnum? status)
        {
            return status?.ToString();
        }

        public static BookStatusEnum? FromStringValue(string? value)
        {
            if (string.IsNullOrEmpty(value))
                return null;

            // Nếu là số
            if (int.TryParse(value, out int intVal) && Enum.IsDefined(typeof(BookStatusEnum), intVal))
                return (BookStatusEnum)intVal;

            // Nếu là chữ (Available, Borrowed, ...)
            if (Enum.TryParse<BookStatusEnum>(value, true, out var enumVal))
                return enumVal;

            return null; // nếu không khớp gì
        }
    }
}
