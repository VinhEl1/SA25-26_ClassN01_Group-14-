﻿using MediatR;
using FluentValidation;
using Library.DTOs.Request;

namespace Library.Helpers
{
    public class BookRequestDTOValidator : AbstractValidator<BookRequestDTO>
    {
        public BookRequestDTOValidator()
        {
            RuleFor(x => x.Title)
                .NotEmpty().WithMessage("Title is required.")
                .MaximumLength(200).WithMessage("Title cannot exceed 200 characters.");

            RuleFor(x => x.Author)
                .NotEmpty().WithMessage("Author is required.")
                .MaximumLength(100).WithMessage("Author cannot exceed 100 characters.");

            RuleFor(x => x.PublishYear)
                .NotEmpty().WithMessage("Publish Year is required.");
        }
    }
}
