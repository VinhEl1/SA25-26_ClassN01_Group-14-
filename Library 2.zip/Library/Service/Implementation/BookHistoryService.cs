﻿using Library.Models;
using Library.Repository.Interface;
using Library.Service.Interface;
using System.Net.NetworkInformation;

namespace Library.Service.Implementation
{
    public class BookHistoryService : IBookHistoryService
    {
        private readonly IBookHistoryRepository _bookHistoryRepository;
        public BookHistoryService(IBookHistoryRepository bookHistoryRepository)
        {
            _bookHistoryRepository = bookHistoryRepository;
        }
        public async Task<IEnumerable<BookHistory>> GetBookHistories(string? search = null)
        {
            return await _bookHistoryRepository.GetBookHistories(search);
        }
    }
}
