﻿using CloudinaryDotNet;
using CloudinaryDotNet.Actions;
using Library.Service.Interface;

namespace Library.Service.Implementation
{
    public class PhotoService : IPhotoService
    {
        private readonly Cloudinary _cloudinary;
        private readonly ILogger<PhotoService> _logger;

        public PhotoService(Cloudinary cloudinary, ILogger<PhotoService> logger)
        {
            _cloudinary = cloudinary;
            _logger = logger;
        }

        public async Task<ImageUploadResult> UploadPhoto(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                _logger.LogWarning("No file provided for upload.");
                return null!;
            }

            using var stream = file.OpenReadStream();
            var uploadParams = new ImageUploadParams
            {//cho vao áppsetting 
                File = new FileDescription(file.FileName, stream),
                AllowedFormats = ["jpg", "png", "jpeg"],
                Folder = "library_photos"
            };

            _logger.LogInformation("Uploading image {FileName} to Cloudinary...", file.FileName);
            var uploadResult = await _cloudinary.UploadAsync(uploadParams);

            if (uploadResult.Error != null)
            {
                _logger.LogError("Cloudinary upload error: {Error}", uploadResult.Error.Message);
            }
            
            _logger.LogInformation("Upload success: {Url}", uploadResult.SecureUrl);
            return uploadResult;
        }
    }
}
