﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using FluentValidation;
using Library.Data;
using Library.Domain;
using Library.Domain.Entity;
using Library.DTOs.Request;
using Library.DTOs.Response;
using Library.DTOs.Shared;
using Library.Models;
using Library.Models.Enum;
using Library.Repository.Interface;
using Library.Service.Interface;
using Microsoft.EntityFrameworkCore;

namespace Library.Service.Implementation
{
    public class BookService : IBookService
    {
        private readonly IBookRepository _bookRepository;
        private readonly IBookHistoryRepository _bookHistoryRepository;
        private readonly DBContext _context;
        private readonly ILogger<BookService> _logger;
        private readonly IPhotoService _photoService;
        private readonly IAudioService _audioService;
        private readonly IMapper _mapper;
        private readonly DomainDispatcher _dispatcher;

        public BookService(IBookRepository bookRepository, IBookHistoryRepository bookHistoryRepository, DBContext dBContext, ILogger<BookService> logger, IPhotoService photoService, IMapper mapper, DomainDispatcher dispatcher, IAudioService audioService)
        {
            _bookRepository = bookRepository;
            _bookHistoryRepository = bookHistoryRepository;
            _context = dBContext;
            _logger = logger;
            _photoService = photoService;
            _mapper = mapper;
            _dispatcher = dispatcher;
            _audioService = audioService;
        }

        // 1. CHỨC NĂNG THÊM SÁCH
        public async Task<BookRespondDTO> AddBook(BookRequestDTO book, int staffId)
        {
            // Fallback: Nếu chưa có StaffId hợp lệ, tạm gán là 1 để không lỗi khóa ngoại
            if (staffId <= 0) staffId = 1; 

            _logger.LogInformation("Đang thêm sách: {Title} - Giá: {Price} - Kho: {Stock}", book.Title, book.Price, book.Stock);

            await using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                // Mapping dữ liệu từ DTO sang Entity
                var bookAdd = new Book
                {
                    Title = book.Title,
                    Author = book.Author,
                    PublishYear = book.PublishYear,
                    // QUAN TRỌNG: Phải gán Giá và Tồn kho
                    Price = book.Price,
                    Stock = book.Stock,
                    // Lấy URL ảnh từ Frontend gửi lên (nếu không có thì dùng ảnh placeholder)
                    ImageUrl = !string.IsNullOrEmpty(book.ImageUrl) ? book.ImageUrl : "https://via.placeholder.com/150", 
                    
                    // Lưu ý: Đảm bảo bạn đã thêm 'Available' vào Enum, nếu chưa thì đổi thành 'New'
                    Status = BookStatusEnum.Available 
                };

                await _bookRepository.AddBook(bookAdd);

                // Tạm thời comment phần lịch sử nếu chưa cần thiết
                // await _bookHistoryRepository.StatusForActionAdd(bookAdd.BookID, staffId);
                
                await transaction.CommitAsync();

                return _mapper.Map<BookRespondDTO>(bookAdd);
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                _logger.LogError(ex, "Lỗi khi thêm sách vào Database");
                throw;
            }
        }

        // 2. CHỨC NĂNG TÌM KIẾM & PHÂN TRANG
        public PageResult<BookRespondDTO> BookSearch(BookSearchRequestDTO search, int page, int pagesize)
        {
            var booksQuery = _bookRepository.BookSearch(search);

            if (booksQuery == null)
            {
                return new PageResult<BookRespondDTO> { Items = new List<BookRespondDTO>() };
            }

            int totalItem = booksQuery.Count();

            // Nếu DB trống, trả về mảng rỗng
            if (totalItem == 0)
            {
                return new PageResult<BookRespondDTO>
                {
                    Page = page,
                    PageSize = pagesize,
                    TotalItem = 0,
                    TotalPage = 0,
                    Items = new List<BookRespondDTO>()
                };
            }

            // Logic phân trang: (Trang hiện tại - 1) * Số lượng mỗi trang
            var skip = (page - 1) * pagesize;
            if (skip < 0) skip = 0;

            var items = booksQuery
                .Skip(skip)
                .Take(pagesize)
                .ProjectTo<BookRespondDTO>(_mapper.ConfigurationProvider)
                .ToList();

            return new PageResult<BookRespondDTO>
            {
                Page = page,
                PageSize = pagesize,
                TotalItem = totalItem,
                TotalPage = (int)Math.Ceiling((double)totalItem / pagesize),
                Items = items
            };
        }

        // 3. CHỨC NĂNG XÓA (SOFT DELETE)
        public async Task DeleteBook(int bookId, int staffId)
        {
            var existingBook = await _bookRepository.getBookById(bookId);
            if (existingBook == null) throw new InvalidOperationException("Không tìm thấy sách");

            await using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                // Soft Delete: Đổi trạng thái thay vì xóa vĩnh viễn
                existingBook.Status = BookStatusEnum.Deleted;
                await _bookRepository.UpdateBook(existingBook);
                await transaction.CommitAsync();
            }
            catch { await transaction.RollbackAsync(); throw; }
        }

        // 4. CHỨC NĂNG CẬP NHẬT (UPDATE)
        public async Task<BookRespondDTO> UpdateBook(BookRequestDTO book, int staffId, int bookId)
        {
            var existingBook = await _bookRepository.getBookById(bookId);
            if (existingBook == null) throw new InvalidOperationException("Không tìm thấy sách với ID này");

            await using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                // LOGIC THÔNG MINH: Chỉ cập nhật nếu dữ liệu mới có giá trị
                if (!string.IsNullOrEmpty(book.Title)) existingBook.Title = book.Title;
                if (!string.IsNullOrEmpty(book.Author)) existingBook.Author = book.Author;
                
                // Riêng PublishYear: Nếu frontend không gửi thì giữ nguyên cái cũ
                if (!string.IsNullOrEmpty(book.PublishYear)) 
                {
                    existingBook.PublishYear = book.PublishYear;
                }
                else if (string.IsNullOrEmpty(existingBook.PublishYear))
                {
                    // Nếu cũ chưa có, gán tạm năm nay để tránh lỗi
                    existingBook.PublishYear = DateTime.Now.Year.ToString();
                }

                // Cập nhật Giá và Tồn kho (Luôn cập nhật)
                existingBook.Price = book.Price;
                existingBook.Stock = book.Stock;
                
                // Cập nhật Ảnh (Chỉ cập nhật nếu có link ảnh mới)
                if (!string.IsNullOrEmpty(book.ImageUrl))
                {
                    existingBook.ImageUrl = book.ImageUrl; 
                }

                await _bookRepository.UpdateBook(existingBook);
                
                // Tạm thời bỏ qua lịch sử
                // await _bookHistoryRepository.StatusForActionUpdate(bookId, staffId); 

                await transaction.CommitAsync();
                return _mapper.Map<BookRespondDTO>(existingBook);
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                _logger.LogError(ex, "Lỗi khi cập nhật sách ID {Id}", bookId);
                throw new Exception("Lỗi Database: " + (ex.InnerException?.Message ?? ex.Message));
            }
        }

        // 5. LẤY CHI TIẾT SÁCH (Bổ sung để không bị lỗi Interface)
        public async Task<Book?> getBookById(int bookId)
        {
            return await _bookRepository.getBookById(bookId);
        }
    }
}