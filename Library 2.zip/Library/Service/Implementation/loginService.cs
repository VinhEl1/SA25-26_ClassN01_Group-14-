﻿using Library.Models;
using Library.Repository.Interface;
using Library.Service.Interface;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Library.Service.Implementation
{
    public class loginService : IloginService
    {
        private readonly IloginRepository _loginRepository;
        private readonly IConfiguration config;

        public loginService(IloginRepository loginRepository, IConfiguration configuration)
        {
            _loginRepository = loginRepository;
            config = configuration;
        }

        public async Task<string?> LoginAsync(string username, string password)
        {
            // Tìm user (Repo đã xử lý ToLower và Trim)
            var user = await _loginRepository.GetUserByUsernameAsync(username);

            // Kiểm tra mật khẩu (Dùng Trim để loại bỏ dấu cách thừa)
            if (user == null || user.Password.Trim() != password.Trim())
            {
                return null;
            }

            var claims = new[]
            {
               new Claim(JwtRegisteredClaimNames.Sub, user.UserName),
               new Claim(ClaimTypes.Role, user.Role),
               new Claim("UserID", user.UserID.ToString()),
               new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(config["Jwt:Key"]));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: config["Jwt:Issuer"],
                audience: config["Jwt:Audience"],
                claims: claims,
                expires: DateTime.Now.AddMinutes(120),
                signingCredentials: creds);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        public async Task<bool> RegisterAsync(User user)
        {
            if (await _loginRepository.GetUserByUsernameAsync(user.UserName) != null) return false;
            await _loginRepository.AddUserAsync(user);
            return true;
        }
        public async Task<User?> GetUserByUsername(string username)
{
    return await _loginRepository.GetUserByUsernameAsync(username);
}
    }
}