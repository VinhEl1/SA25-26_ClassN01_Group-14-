﻿using Library.Models;
using Library.Repository.Interface;
using Library.Service.Interface;

namespace Library.Service.Implementation
{
    public class BorrowDetailService : IBorrowDetailService
    {

        private readonly IBorrowDetailRepository _borrowDetailRepository;
        private readonly IConfiguration _configuration;

        public BorrowDetailService(IBorrowDetailRepository borrowDetailRepository, IConfiguration configuration)
        {
            _borrowDetailRepository = borrowDetailRepository;
            _configuration = configuration;
        }

        public async Task<BorrowDetail> AddBorrowDetail(BorrowDetail borrowDetail)
        {
           if (borrowDetail is null)
                throw new ArgumentNullException(nameof(borrowDetail), "Borrow detail cannot be null");
            
           return await _borrowDetailRepository.AddBorrowDetail(borrowDetail);
        }

        public async Task DeleteBorrowDetail(int borrowDetailId)
        {
            if (borrowDetailId == null)
                throw new ArgumentException(nameof(borrowDetailId), "Borrow detail ID cannot be null");
  
            await _borrowDetailRepository.DeleteBorrowDetail(borrowDetailId);
        }

        public IEnumerable<BorrowDetail> GetBorrowDetails(int memberID, string? search = null)
        {
            if (memberID == null || memberID <= 0)
                throw new ArgumentException(nameof(memberID), "Member ID cannot be null or smaller than 1");

            return _borrowDetailRepository.GetBorrowDetails(memberID, search);
        }

        public async Task<BorrowDetail> UpdateBorrowDetail(BorrowDetail borrowDetail, int BorrowDetailID)
        {
            if (_borrowDetailRepository.GetBorrowDetailById(BorrowDetailID) == null)
                throw new ArgumentException("Borrow detail not found");
       
            return await _borrowDetailRepository.UpdateBorrowDetail(borrowDetail, borrowDetail.BorrowDetailID);
        }
    }
}
