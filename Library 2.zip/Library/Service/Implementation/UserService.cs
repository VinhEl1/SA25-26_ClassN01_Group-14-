﻿using Library.DTOs.Request;
using Library.Models;
using Library.Repository.Interface;
using Library.Service.Interface;


namespace Library.Service.Implementation
{
    public class UserService : IUserService
    {

        private readonly IUserRepository _userRepository;
        private readonly IConfiguration _config;

        public UserService(IUserRepository userRepository, IConfiguration config)
        {
            _userRepository = userRepository;
            _config = config;
        }

        public async Task AddUser(UserDTO dto)
        {
            User entity;

            if (dto.Role == "Admin")
            {
                entity = new Admin
                {
                    UserName = dto.UserName,
                    Phone = dto.Phone,
                    FullName = dto.FullName,
                    Email = dto.Email,
                    Password = dto.Password,
                    Role = "Admin",
                    Department = dto.Department
                };
            }
            else if (dto.Role == "Staff")
            {
                entity = new Staff
                {
                    UserName = dto.UserName,
                    Phone = dto.Phone,
                    FullName = dto.FullName,
                    Email = dto.Email,
                    Password = dto.Password,
                    Role = "Staff",
                    Position = dto.Position,
                    Schedule = dto.Schedule
                };
            }
            else
            {
                entity = new User
                {
                    UserName = dto.UserName,
                    Phone = dto.Phone,
                    FullName = dto.FullName,
                    Email = dto.Email,
                    Password = dto.Password,
                    Role = "User"
                };
            }

            var existUser = await _userRepository.GetUserByUserName(dto.UserName, dto.Role);
            if (existUser != null)
                throw new Exception("Username already exists");

            await _userRepository.AddUser(entity);
        }

        public async Task DeleteUser(int userId)
        {
            if (await _userRepository.GetUserById(userId, "User") is null)
                throw new Exception("User not found");

            await _userRepository.DeleteUser(userId, "User");
        }

        public IEnumerable<UserDTO> GetUsers(string? search = null)
        {
            return _userRepository.GetUsers(search);
        }

        public async Task UpdateUser(UserDTO dto)
        {
            await _userRepository.UpdateUser(dto);
        }
    }
}
