﻿using Library.Data;
using Library.Models;
using Library.Repository.Interface;
using Library.Service.Interface;
using Microsoft.EntityFrameworkCore;

namespace Library.Service.Implementation
{
    public class ReturnSlipService : IReturnSlipService
    {
        private readonly IReturnSlipRepository _returnSlipRepository;
        private readonly DBContext _context;

        public ReturnSlipService(IReturnSlipRepository returnSlipRepository, DBContext context)
        {
            _returnSlipRepository = returnSlipRepository;
            _context = context;
        }

        public async Task<ReturnSlip> AddReturnSlip(ReturnSlip returnSlip)
        {
            // Logic xử lý khi trả sách
            var detail = await _context.BorrowDetails
                .Include(d => d.BorrowSlip)
                .FirstOrDefaultAsync(d => d.RSlipID == returnSlip.RSlipID || d.BorrowDetailID > 0); // Giả định logic tìm kiếm

            if (detail != null)
            {
                var returnDate = DateTime.Now;
                
                // 1. LIÊN KẾT: Tự động tạo tiền phạt nếu trả muộn
                if (returnDate > detail.BorrowSlip.DueDate)
                {
                    var lateDays = (returnDate - detail.BorrowSlip.DueDate).Days;
                    var fine = new Fine {
                        IssuedDate = returnDate,
                        Amount = lateDays * 5000, // Phạt 5k/ngày
                        Reason = $"Trả muộn {lateDays} ngày",
                        Status = "Pending"
                    };
                    _context.Fines.Add(fine);
                    detail.Fine = fine;
                }

                detail.ReturnDate = returnDate;

                // 2. LIÊN KẾT: Cập nhật lại kho sách
                var book = await _context.Books.FindAsync(detail.BookID);
                if (book != null) book.Stock += 1;
            }

            return await _returnSlipRepository.AddReturnSlip(returnSlip);
        }

        public IEnumerable<ReturnSlip> GetReturnSlips(string? search = null) => _returnSlipRepository.GetReturnSlips(search);
        public async Task<ReturnSlip> UpdateReturnSlip(ReturnSlip returnSlip) => await _returnSlipRepository.UpdateReturnSlip(returnSlip);
        public async Task DeleteReturnSlip(int id) => await _returnSlipRepository.DeleteReturnSlip(id);
    }
}