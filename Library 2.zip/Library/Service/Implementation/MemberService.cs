﻿using Library.Models;
using Library.Repository.Interface;
using Library.Service.Interface;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace Library.Service.Implementation
{
    public class MemberService : IMemberService
    {
        private readonly IMemberRepository _memberRepository;
        private readonly IConfiguration _config;

        public MemberService(IMemberRepository memberRepository, IConfiguration config)
        {
            _memberRepository = memberRepository;
            _config = config;
        }

        public async Task<Member> AddMember(Member member)
        {
            // 1. Tự động sinh Mã thẻ (CardNumber) nếu chưa có
            if (string.IsNullOrEmpty(member.CardNumber))
            {
                member.CardNumber = "MB" + DateTime.Now.Ticks.ToString().Substring(12);
            }

            // 2. Tự động lấy ngày hiện tại làm ngày tham gia
            if (member.JoinDate == default(DateTime))
            {
                member.JoinDate = DateTime.Now;
            }

            // 3. Gán trạng thái mặc định là "Active"
            if (string.IsNullOrEmpty(member.Status))
            {
                member.Status = "Active";
            }

            return await _memberRepository.AddMember(member);
        }

        public async Task DeleteMember(int memberId)
        {
            var member = await _memberRepository.GetMemberById(memberId);
            if (member == null)
            {
                throw new KeyNotFoundException("Không tìm thấy độc giả với ID này.");
            }
        
            await _memberRepository.DeleteMember(memberId);
        }

        public async Task<Member> GetMemberById(int memberId)
        {
            var member = await _memberRepository.GetMemberById(memberId);
            if (member == null)
            {
                throw new KeyNotFoundException("Không tìm thấy độc giả.");
            }

            return member;
        }

        public IEnumerable<Member> GetMembers(string? search = null)
        {
            return _memberRepository.GetMembers(search);
        }

        public async Task<Member> UpdateMember(Member member, int memberId)
        {
            var existingMember = await _memberRepository.GetMemberById(memberId);
            
            if (existingMember == null)
                throw new KeyNotFoundException("Không tìm thấy độc giả để cập nhật.");

            // Đã sửa tên các thuộc tính cho khớp với Model (MemberName, MemberPhone)
            existingMember.MemberName = member.MemberName; 
            existingMember.Email = member.Email;
            existingMember.MemberPhone = member.MemberPhone;
            existingMember.MemberAddress = member.MemberAddress;
            existingMember.DOB = member.DOB;
            
            if (!string.IsNullOrEmpty(member.Status))
            {
                existingMember.Status = member.Status;
            }

            return await _memberRepository.UpdateMember(existingMember, memberId);
        }
    }
}