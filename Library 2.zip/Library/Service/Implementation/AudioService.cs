﻿using CloudinaryDotNet;
using CloudinaryDotNet.Actions;
using Library.Data;
using Library.Models;
using Library.Repository.Interface;
using Library.Service.Interface;

namespace Library.Service.Implementation
{
    public class AudioService : IAudioService
    {
        private readonly ILogger<AudioService> _logger;
        private readonly IAudioRepository _audioRepository;
        private readonly IChunkRepository _chunkRepository;
        private readonly Cloudinary _cloudinary;
        private const int CHUNK_SIZE = 6 * 1024 * 1024;
        private readonly DBContext _context;

        public AudioService(ILogger<AudioService> logger, IAudioRepository audioRepository, DBContext context, IChunkRepository chunkRepository, Cloudinary cloudinary)
        {
            _logger = logger;
            _audioRepository = audioRepository;
            _context = context;
            _cloudinary = cloudinary;
            _chunkRepository = chunkRepository;
        }

        public async Task<Models.Audio> AddHeavyAudio(IFormFile audio, int id)
        {
            if (audio == null || audio.Length == 0)
            {
                throw new ArgumentNullException(nameof(audio), "Audio cannot be null or empty.");
            }

            _logger.LogInformation("Starting heavy audio upload for {FileName}...", audio.FileName);

            var audioFile = new Models.Audio
            {
                BookID = id,
                FileName = audio.FileName,
                FileSize = audio.Length,
                TotalChunks = (int)Math.Ceiling((double)audio.Length / CHUNK_SIZE),
                IsComplete = false
            };

            var entry = await _audioRepository.AddAudio(audioFile);

            int index = 0;
            byte[] buffer = new byte[CHUNK_SIZE];

            using var stream = audio.OpenReadStream();

            try
            {
                int byteRead;
                while ((byteRead = await stream.ReadAsync(buffer, 0, CHUNK_SIZE)) > 0)
                {
                    using var chunkStream = new MemoryStream(buffer, 0, byteRead);

                    var uploadParam = new RawUploadParams
                    {
                        File = new FileDescription($"{audio.FileName}_CHUNK_{index}", chunkStream)
                    };

                    var uploadResult = await _cloudinary.UploadAsync(uploadParam);

                    if (uploadResult.Error != null)
                    {
                        _logger.LogError("Cloudinary upload error for chunk {Index}: {Error}", index, uploadResult.Error.Message);
                        throw new Exception($"Chunk upload failed: {uploadResult.Error.Message}");
                    }

                    var chunk = new AudioChunk
                    {
                        AudioID = entry.AudioID,
                        ChunkIndex = index,
                        ChunkUrl = uploadResult.SecureUrl.ToString(),
                        ChunkSize = byteRead
                    };

                    await _chunkRepository.AddChunk(chunk);

                    index++;
                    audioFile.UploadedChunks = index;
                }
                
                _logger.LogInformation("Uploaded {UploadedChunks} out of {TotalChunks} for audio {FileName}.", index, audioFile.TotalChunks, audio.FileName);

                if (audioFile.UploadedChunks == audioFile.TotalChunks)
                {
                    _logger.LogInformation("All chunks uploaded for audio {FileName}. Marking as complete.", audio.FileName);
                    audioFile.IsComplete = true;
                }

                await _audioRepository.UpdateAudio(audioFile, entry.AudioID);   

                return entry;
            }
            catch
            {
                _logger.LogError("Upload heavy audio failed");

                throw;
            }
        }

        public async Task<Models.Audio> AddLightAudio(IFormFile audio, int id)
        {
            if (audio == null)
                throw new ArgumentNullException(nameof(audio));

            if (audio.Length > 10 * 1024 * 1024)
                throw new ArgumentException("File too large");

            _logger.LogInformation("Uploading audio {File}", audio.FileName);

            var uploadParams = new RawUploadParams
            {
                File = new FileDescription(audio.FileName, audio.OpenReadStream()),
                Folder = "library_audios",
                PublicId = Path.GetFileNameWithoutExtension(audio.FileName)
            };

            var uploadResult = await _cloudinary.UploadAsync(uploadParams);

            _logger.LogInformation("Upload result: {Result}", uploadResult.SecureUrl);

            if (uploadResult == null)
                throw new Exception("UploadResult is NULL — Cloudinary did not respond");

            if (uploadResult.Error != null)
                throw new Exception("Cloudinary error: " + uploadResult.Error.Message);

            return await _audioRepository.AddAudio(new Models.Audio
            {
                BookID = id,
                FileName = audio.FileName,
                AudioUrl = uploadResult.SecureUrl.ToString(),
                FileSize = audio.Length,
                IsComplete = true
            });
        }


        public Task DeleteAudio(int publicId)
        {
            throw new NotImplementedException();
        }

        public Task<Models.Audio> UpdateAudio(IFormFile audio, int id)
        {
            throw new NotImplementedException();
        }
    }
}
