﻿using Library.Repository.Interface;
using Library.Service.Interface;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using System.Runtime.InteropServices;

namespace Library.Service.Implementation
{
    public class ChunkService : IChunkService
    {
        private readonly ILogger<ChunkService> _logger; 
        private readonly IChunkRepository _chunkRepository;
        public ChunkService(ILogger<ChunkService> logger, IChunkRepository chunkRepository)
        {
            _logger = logger;
            _chunkRepository = chunkRepository;
        }
        public async Task<byte[]> GetMergedAudio(int audioId)
        {
            var chunks =  _chunkRepository.GetChunksByAudioId(audioId);

            if (chunks == null || chunks.Result.Count == 0)
            {
                _logger.LogWarning($"No audio chunks found for AudioID: {audioId}");
                return Array.Empty<byte>();
            }

            using var outputStream = new MemoryStream();
            
            using var client = new HttpClient();
            foreach (var chunk in await chunks)
            {
                var bytes = await client.GetByteArrayAsync(chunk.ChunkUrl);
                await outputStream.WriteAsync(bytes, 0, bytes.Length);
            }
            
            outputStream.Position = 0;
            
            return outputStream.ToArray();
        }
    }
}
