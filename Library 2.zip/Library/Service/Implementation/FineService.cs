﻿using Library.Models;
using Library.Repository.Interface;
using Library.Service.Interface;

namespace Library.Service.Implementation
{
    public class FineService : IFineService
    {

        private readonly IFineRepository _fineRepository;
        private readonly IConfiguration config;

        public FineService(IFineRepository fineRepository, IConfiguration configuration)
        {
            _fineRepository = fineRepository;
            config = configuration;
        }

        public async Task<Fine> AddFine(Fine fine)
        {
            return await _fineRepository.AddFine(fine);
        }

        public async Task DeleteFine(int fineId)
        {
            if (_fineRepository.GetFineById(fineId) is null)
                throw new Exception("Fine with the same ID not exists.");
    
            await _fineRepository.DeleteFine(fineId);
        }

        public Task<Fine> GetFineById(int fineId)
        {
            if (_fineRepository.GetFineById(fineId) is null)
                throw new Exception("Fine with the same ID not exists.");

            return _fineRepository.GetFineById(fineId);
        }

        public IEnumerable<Fine> GetFines(string? search = null)
        {
            return _fineRepository.GetFines(search);
        }

        public async Task<Fine> UpdateFine(Fine fine)
        {
            return await _fineRepository.UpdateFine(fine);
        }
    }
}
