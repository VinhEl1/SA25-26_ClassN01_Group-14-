﻿using Library.Data;
using Library.DTOs.Request;
using Library.Models;
using Library.Repository.Interface;
using Library.Service.Interface;
using Microsoft.EntityFrameworkCore;
using MediatR;
using Library.Domain.Event;
using Microsoft.Extensions.Logging;

namespace Library.Service.Implementation
{
    public class BorrowSlipService : IBorrowSlipService
    {
        private readonly IBorrowSlipRepository _borrowSlipRepository;
        private readonly DBContext _context;
        private readonly IMediator _mediator;
        private readonly ILogger<BorrowSlipService> _logger;

        public BorrowSlipService(
            IBorrowSlipRepository borrowSlipRepository, 
            DBContext context, 
            IMediator mediator,
            ILogger<BorrowSlipService> logger)
        {
            _borrowSlipRepository = borrowSlipRepository;
            _context = context;
            _mediator = mediator;
            _logger = logger;
        }

        public async Task<IEnumerable<BorrowSlip>> GetBorrowSlipsAsync(string? search = null)
        {
            return await Task.Run(() => _borrowSlipRepository.GetBorrowSlips(search));
        }

        public async Task<BorrowSlip> GetBorrowSlipByIDAsync(int id)
        {
            return await _borrowSlipRepository.getBorrowSlipById(id);
        }

        public async Task<bool> CreateBorrowSlipAsync(BorrowSlipDTO borrowDto)
        {
            // 1. Kiểm tra đầu vào cơ bản
            if (borrowDto.BookIDs == null || !borrowDto.BookIDs.Any())
                throw new Exception("Danh sách sách mượn không được để trống.");

            // 2. KIỂM TRA THỰC TẾ TRONG DATABASE (Nguyên nhân gây lỗi 40 - Connection/ForeignKey)
            // Kiểm tra nhân viên thực hiện (StaffID) có tồn tại không
            var staffExists = await _context.Users.AnyAsync(u => u.UserID == borrowDto.StaffID);
            if (!staffExists)
                throw new Exception($"Lỗi: Nhân viên (StaffID) có ID {borrowDto.StaffID} không tồn tại trong hệ thống. Vui lòng kiểm tra lại ID trong code React.");

            // Kiểm tra độc giả (MemberID) có tồn tại không
            var memberExists = await _context.Members.AnyAsync(m => m.MemberID == borrowDto.MemberID);
            if (!memberExists)
                throw new Exception($"Lỗi: Độc giả (MemberID) có ID {borrowDto.MemberID} không tồn tại.");

            // 3. Kiểm tra tồn kho sách
            var books = await _context.Books.Where(b => borrowDto.BookIDs.Contains(b.BookID)).ToListAsync();
            foreach (var b in books)
            {
                if (b.Stock <= 0)
                    throw new Exception($"Sách '{b.Title}' đã hết trong kho, không thể cho mượn.");
            }

            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                // Bước A: Tạo phiếu mượn chính
                var slip = new BorrowSlip
                {
                    BorrowDate = DateTime.Now,
                    DueDate = borrowDto.DueDate,
                    StaffID = borrowDto.StaffID,
                    MemberID = borrowDto.MemberID,
                    Status = "Borrowing"
                };

                await _borrowSlipRepository.saveChange(slip);
                
                // Bước B: Tạo chi tiết phiếu mượn
                var borrowDetails = borrowDto.BookIDs.Select(id => new BorrowDetail
                {
                    BSlipID = slip.BSlipID,
                    BookID = id,
                    MemberID = borrowDto.MemberID,
                    BorrowDate = DateTime.Now
                }).ToList();

                await _borrowSlipRepository.saveDetail(borrowDetails);

                // Bước C: Xác nhận lưu vào DB
                await transaction.CommitAsync();

                // Bước D: Bắn Event (Xử lý trừ kho, lịch sử...) qua MediatR
                try 
                {
                    await _mediator.Publish(new BorrowEvent(slip, borrowDetails));
                }
                catch (Exception ex) 
                {
                    _logger.LogWarning("Phiếu mượn đã tạo nhưng Event (Trừ kho) gặp lỗi: " + ex.Message);
                }

                return true;
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                _logger.LogError(ex, "Lỗi khi thực thi Transaction lưu phiếu mượn");
                
                // BẮN LỖI RA NGOÀI ĐỂ CONTROLLER BẮT ĐƯỢC
                throw new Exception("Lỗi Database hệ thống: " + (ex.InnerException?.Message ?? ex.Message));
            }
        }

        public async Task<bool> UpdateBorrowSlipAsync(BorrowSlip borrowSlip)
        {
            try 
            {
                await _borrowSlipRepository.updateBorrowSlip(borrowSlip);
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("Lỗi cập nhật: " + ex.Message);
            }
        }

        public async Task<bool> DeleteBorrowSlipAsync(int borrowSlipId)
        {
            try
            {
                await _borrowSlipRepository.deleteBorrowSlip(borrowSlipId);
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("Lỗi xóa phiếu: " + ex.Message);
            }
        }
    }
}