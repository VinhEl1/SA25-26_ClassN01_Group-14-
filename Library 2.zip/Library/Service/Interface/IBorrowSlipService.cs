﻿using Library.DTOs.Request;
using Library.Models;

namespace Library.Service.Interface
{
    public interface IBorrowSlipService
    {
        // Sử dụng Task để hỗ trợ xử lý bất đồng bộ (async/await)
        Task<IEnumerable<BorrowSlip>> GetBorrowSlipsAsync(string? search = null);
        
        Task<BorrowSlip> GetBorrowSlipByIDAsync(int id);

        // Hợp nhất Add và Create thành một phương thức duy nhất cho chức năng POS
        // Trả về bool để biết thành công hay thất bại, hoặc trả về chính DTO đã tạo
        Task<bool> CreateBorrowSlipAsync(BorrowSlipDTO borrowDto);

        Task<bool> UpdateBorrowSlipAsync(BorrowSlip borrowSlip);

        Task<bool> DeleteBorrowSlipAsync(int borrowSlipId);
    }
}