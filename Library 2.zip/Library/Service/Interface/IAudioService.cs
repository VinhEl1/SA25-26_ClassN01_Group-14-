﻿namespace Library.Service.Interface
{
    public interface IAudioService
    {
        Task<Models.Audio> AddLightAudio(IFormFile audio, int id);
        Task<Models.Audio> AddHeavyAudio(IFormFile audio, int id);
        Task<Models.Audio> UpdateAudio(IFormFile audio, int id);
        Task DeleteAudio(int publicId);
    }
}
