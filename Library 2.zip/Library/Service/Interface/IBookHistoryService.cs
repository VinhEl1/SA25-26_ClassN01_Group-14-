﻿using Library.Models;

namespace Library.Service.Interface
{
    public interface IBookHistoryService
    {
        Task<IEnumerable<BookHistory>> GetBookHistories(string? search = null);
    }
}
