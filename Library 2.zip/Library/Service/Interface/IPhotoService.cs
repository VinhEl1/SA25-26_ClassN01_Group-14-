﻿using CloudinaryDotNet.Actions;

namespace Library.Service.Interface
{
    public interface IPhotoService
    {
        Task<ImageUploadResult> UploadPhoto(IFormFile file);
    }
}
