﻿using Library.Models;

namespace Library.Service.Interface
{
    public interface IBorrowDetailService
    {
        IEnumerable<BorrowDetail> GetBorrowDetails(int memberID, string? search = null);
        Task<BorrowDetail> AddBorrowDetail(BorrowDetail borrowDetail);
        Task<BorrowDetail> UpdateBorrowDetail(BorrowDetail borrowDetail, int BorrowDetailID);
        Task DeleteBorrowDetail(int borrowDetailId);
    }
}
