﻿using Library.DTOs.Request;
using Library.Models;

namespace Library.Service.Interface
{
    public interface IUserService
    {
        IEnumerable<UserDTO> GetUsers(string? search = null);
        Task AddUser(UserDTO dto);
        Task UpdateUser(UserDTO dto);
        Task DeleteUser(int userId);
    }
}
