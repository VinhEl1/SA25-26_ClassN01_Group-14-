﻿using Library.Models;

namespace Library.Service.Interface
{
    public interface IloginService
    {
        Task<string?> LoginAsync(string username, string password);
        Task<bool> RegisterAsync(User user);
        Task<User?> GetUserByUsername(string username);
    }
}
