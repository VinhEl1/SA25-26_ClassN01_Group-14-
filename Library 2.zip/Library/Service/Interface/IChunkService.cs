﻿using Microsoft.AspNetCore.Mvc;

namespace Library.Service.Interface
{
    public interface IChunkService
    {
        Task<byte[]> GetMergedAudio(int audioId);
    }
}
