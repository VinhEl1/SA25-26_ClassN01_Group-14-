﻿using Library.Models;

namespace Library.Service.Interface
{
    public interface IMemberService
    {
        IEnumerable<Member> GetMembers(string? search = null);
        Task<Member> AddMember(Member member);
        Task<Member> UpdateMember(Member member, int memberId);
        Task DeleteMember(int memberId);
        Task<Member> GetMemberById(int memberId);
    }
}
