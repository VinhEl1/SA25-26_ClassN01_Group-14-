﻿using Library.DTOs.Request;
using Library.DTOs.Response;
using Library.DTOs.Shared;
using Library.Models;
using Microsoft.AspNetCore.Mvc;

namespace Library.Service.Interface
{
    public interface IBookService
    {
        PageResult<BookRespondDTO> BookSearch(BookSearchRequestDTO search, int page, int pagesize);
        Task<BookRespondDTO> AddBook(BookRequestDTO book, int staffID);
        Task<BookRespondDTO> UpdateBook([FromBody] BookRequestDTO book, int StaffId, int bookId);
        Task DeleteBook(int bookId, int staffId);
        Task<Book?> getBookById(int bookId);
    }
}
