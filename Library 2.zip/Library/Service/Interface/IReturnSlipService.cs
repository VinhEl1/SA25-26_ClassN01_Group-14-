﻿using Library.Models;

namespace Library.Service.Interface
{
    public interface IReturnSlipService
    {
        IEnumerable<ReturnSlip> GetReturnSlips(string? search = null);
        Task<ReturnSlip> AddReturnSlip(ReturnSlip returnSlip);
        Task<ReturnSlip> UpdateReturnSlip(ReturnSlip returnSlip);
        Task DeleteReturnSlip(int returnSlipId);
    }
}
