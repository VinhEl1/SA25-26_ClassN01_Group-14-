using CloudinaryDotNet;
using FluentValidation;
using Library.Data;
using Library.Domain;
using Library.Domain.Event;
using Library.Domain.EventHandler;
using Library.Helpers;
using Library.Mapping;
using Library.Middleware;
using Library.Models;
using Library.Repository.Implementation;
using Library.Repository.Interface;
using Library.Service.Implementation;
using Library.Service.Interface;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Reflection;
using System.Text;
using System.Text.Json.Serialization;
using System.Text.Json;

var builder = WebApplication.CreateBuilder(args);

// ============================================================
// 1. CẤU HÌNH DATABASE
// ============================================================
builder.Services.AddDbContext<DBContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"))
);

// ============================================================
// 2. CẤU HÌNH CORS
// ============================================================
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowReact", policy =>
    {
        policy.WithOrigins("http://localhost:5173", "http://localhost:5174", "http://127.0.0.1:5173")
              .AllowAnyHeader()
              .AllowAnyMethod()
              .AllowCredentials();
    });
});

// ============================================================
// 3. ĐĂNG KÝ REPOSITORIES (DI)
// ============================================================
builder.Services.AddScoped<IFineRepository, FineRepository>();
builder.Services.AddScoped<IMemberRepository, MemberRepository>();
builder.Services.AddScoped<IReturnSlipRepository, ReturnSlipRepository>();
builder.Services.AddScoped<IBookRepository, BookRepository>();
builder.Services.AddScoped<IBorrowDetailRepository, BorrowDetailRepository>();
builder.Services.AddScoped<IBorrowSlipRepository, BorrowSlipRepository>();
builder.Services.AddScoped<IUserRepository, UserRepository>();
builder.Services.AddScoped<IloginRepository, loginRepository>();
builder.Services.AddScoped<IChunkRepository, ChunkRepository>();
builder.Services.AddScoped<IAudioRepository, AudioRepository>();
builder.Services.AddScoped<IBookHistoryRepository, BookHistoryRepository>();

// ============================================================
// 4. ĐĂNG KÝ SERVICES (DI)
// ============================================================
builder.Services.AddScoped<IFineService, FineService>();
builder.Services.AddScoped<IMemberService, MemberService>();
builder.Services.AddScoped<IReturnSlipService, ReturnSlipService>();
builder.Services.AddScoped<IBookService, BookService>();
builder.Services.AddScoped<IBorrowDetailService, BorrowDetailService>();
builder.Services.AddScoped<IUserService, UserService>();
builder.Services.AddScoped<IloginService, loginService>();
builder.Services.AddScoped<IBorrowSlipService, BorrowSlipService>();
builder.Services.AddScoped<IPhotoService, PhotoService>();
builder.Services.AddScoped<IChunkService, ChunkService>();
builder.Services.AddScoped<IAudioService, AudioService>();
builder.Services.AddScoped<IBookHistoryService, BookHistoryService>();

// ============================================================
// 5. CẤU HÌNH THƯ VIỆN BÊN THỨ 3
// ============================================================
builder.Services.AddAutoMapper(typeof(MappingProfile));
builder.Services.AddValidatorsFromAssemblyContaining<BookRequestDTOValidator>();
builder.Services.AddHttpContextAccessor();
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(Program).Assembly));
builder.Services.AddSingleton<JwtHelper>();

// Domain Events
builder.Services.AddScoped<DomainDispatcher>();
builder.Services.AddScoped<IDomainEventHandler<BookAddedEvent>, BookAddedEventHandler>();

// ============================================================
// 6. CẤU HÌNH CONTROLLERS & JSON
// ============================================================
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
        options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
        options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
    });

builder.Services.AddEndpointsApiExplorer();

// ============================================================
// 7. SWAGGER CONFIGURATION
// ============================================================
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "Library API", Version = "v1" });
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        In = ParameterLocation.Header,
        Description = "Please enter token as: 'Bearer {your_token}'",
        Name = "Authorization",
        Type = SecuritySchemeType.ApiKey,
        Scheme = "Bearer"
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement {
        {
            new OpenApiSecurityScheme {
                Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" }
            },
            new List<string>()
        }
    });
});

// ============================================================
// 8. CLOUDINARY CONFIGURATION
// ============================================================
builder.Services.AddSingleton(provider =>
{
    var config = provider.GetRequiredService<IConfiguration>();
    return new Cloudinary(new Account(
        config["CloudinarySettings:CloudName"],
        config["CloudinarySettings:ApiKey"],
        config["CloudinarySettings:ApiSecret"]
    ));
});

// ============================================================
// 9. AUTHENTICATION & AUTHORIZATION
// ============================================================
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidAudience = builder.Configuration["Jwt:Audience"],
            ValidIssuer = builder.Configuration["Jwt:Issuer"],
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"] ?? "SecretKeyMacDinhCanDaiHon256BitDeKhongBiLoi"))
        };
    });

builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("AdminOnly", policy => policy.RequireRole("Admin"));
    options.AddPolicy("UserOnly", policy => policy.RequireRole("User"));
    options.AddPolicy("StaffOnly", policy => policy.RequireRole("Staff"));
});

// ============================================================
// 10. BUILD APP & MIDDLEWARE PIPELINE
// ============================================================
var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("AllowReact");
app.UseMiddleware<Library.Middleware.JwtMiddleware>();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();

// ============================================================
// 11. SEED DATA (TẠO TÀI KHOẢN MẪU KHI CHẠY LẦN ĐẦU)
// ============================================================
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    var logger = services.GetRequiredService<ILogger<Program>>();

    try
    {
        var context = services.GetRequiredService<DBContext>();
        context.Database.EnsureCreated();

        // -----------------------------------------------------------
        // PHẦN 1: TẠO USER NẾU CHƯA CÓ (Giữ nguyên logic cũ)
        // -----------------------------------------------------------
        if (!context.Users.Any())
        {
            // 1. Tạo tài khoản ADMIN
            var admin = new Admin
            {
                UserName = "admin",
                Password = "123",
                FullName = "Hệ thống Quản trị",
                Email = "admin@library.com",
                Phone = "0123456789",
                Role = "Admin",
                Department = "IT & Management"
            };

            // 2. Tạo tài khoản USER mẫu
            var user = new User
            {
                UserName = "vinh09",
                Password = "123",
                FullName = "Nguyễn Thành Vinh",
                Email = "vinh09@gmail.com",
                Phone = "0988777666",
                Role = "User"
            };

            context.Users.AddRange(admin, user);
            context.SaveChanges();
            logger.LogInformation(">>> Đã tạo User Admin và User vinh09 <<<");
        }

        // -----------------------------------------------------------
        // PHẦN 2 (FIX LỖI): KIỂM TRA VÀ BỔ SUNG MEMBER CHO VINH09
        // -----------------------------------------------------------
        
        // Tìm user vinh09 trong database
        var vinhUser = context.Users.FirstOrDefault(u => u.UserName == "vinh09");

        // Nếu User tồn tại NHƯNG chưa có trong bảng Members
        if (vinhUser != null && !context.Members.Any(m => m.UserID == vinhUser.UserID))
        {
            var member = new Member
            {
                MemberName = vinhUser.FullName,
                MemberPhone = vinhUser.Phone,
                MemberAddress = "123 Đường ABC, TP.HCM",
                DOB = new DateTime(2000, 1, 1),
                Email = vinhUser.Email,
                CardNumber = "MB" + DateTime.Now.Ticks.ToString().Substring(12),
                JoinDate = DateTime.Now,
                Status = "Active",
                UserID = vinhUser.UserID // Liên kết UserID
            };

            context.Members.Add(member);
            context.SaveChanges();
            logger.LogInformation(">>> ĐÃ BỔ SUNG THẺ THƯ VIỆN (MEMBER) CHO VINH09 <<<");
        }
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "Lỗi khi khởi tạo dữ liệu mẫu.");
    }
}

app.Run();