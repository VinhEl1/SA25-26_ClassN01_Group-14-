﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Library.Migrations
{
    /// <inheritdoc />
    public partial class FineAmount : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_BorrowSlips_Members_MemberID",
                table: "BorrowSlips");

            migrationBuilder.AddColumn<decimal>(
                name: "Amount",
                table: "Fines",
                type: "decimal(18,0)",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddForeignKey(
                name: "FK_BorrowSlips_Members_MemberID",
                table: "BorrowSlips",
                column: "MemberID",
                principalTable: "Members",
                principalColumn: "MemberID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_BorrowSlips_Members_MemberID",
                table: "BorrowSlips");

            migrationBuilder.DropColumn(
                name: "Amount",
                table: "Fines");

            migrationBuilder.AddForeignKey(
                name: "FK_BorrowSlips_Members_MemberID",
                table: "BorrowSlips",
                column: "MemberID",
                principalTable: "Members",
                principalColumn: "MemberID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
