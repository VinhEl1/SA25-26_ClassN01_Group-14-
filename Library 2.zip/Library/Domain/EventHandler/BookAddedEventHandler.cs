﻿using Library.Domain.Event;

namespace Library.Domain.EventHandler
{
    
    public class BookAddedEventHandler : IDomainEventHandler<BookAddedEvent>
    {
        private readonly ILogger<BookAddedEventHandler> _logger;
        public BookAddedEventHandler(ILogger<BookAddedEventHandler> logger)
        {
            _logger = logger;
        }
        public Task Handle(BookAddedEvent domainEvent)
        {
            _logger.LogInformation("==================================Book Added==================================");

            return Task.CompletedTask;
        }
    }
}
