﻿using Library.Data; // Để sử dụng DBContext
using Library.Domain.Event;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace Library.Domain.EventHandler
{
    public class BorrowEventHandler : INotificationHandler<BorrowEvent>
    {
        private readonly DBContext _context;

        public BorrowEventHandler(DBContext context)
        {
            _context = context;
        }

        public async Task Handle(BorrowEvent notification, CancellationToken cancellationToken)
        {
            // 1. Duyệt qua từng chi tiết sách được mượn
            foreach (var detail in notification.BorrowDetails)
            {
                // Tìm cuốn sách trong Database theo BookID
                var book = await _context.Books
                    .FirstOrDefaultAsync(b => b.BookID == detail.BookID, cancellationToken);

                if (book != null)
                {
                    // 2. Kiểm tra nếu sách còn trong kho thì mới trừ
                    if (book.Stock > 0)
                    {
                        book.Stock -= 1;
                        Console.WriteLine($"[EVENT] Đã trừ kho sách: {book.Title}. Còn lại: {book.Stock}");
                    }
                }
            } // Kết thúc vòng lặp foreach

            // 3. QUAN TRỌNG: Lưu tất cả thay đổi số lượng sách vào Database
            await _context.SaveChangesAsync(cancellationToken);
            
            Console.WriteLine("---- Cập nhật kho sách thành công ----");
        } // Kết thúc hàm Handle
    } // Kết thúc class
} // Kết thúc namespace