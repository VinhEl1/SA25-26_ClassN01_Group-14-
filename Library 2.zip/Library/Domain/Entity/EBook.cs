﻿using Library.Domain.Aggregate;
using Library.Domain.Event;

namespace Library.Domain.Entity
{
    public class EBook : AggregateRoot
    {
        public string Title { get; private set; }
        public string Author { get; private set; }
        public string? Category { get; set; }

        public EBook(string title, string author)
        {
            Title = title;
            Author = author;

            AddDomainEvent(new BookAddedEvent(Title));
        }
    }
}
