﻿namespace Library.Domain
{
    public interface IDomainEvent
    {
        DateTime OccurredOn { get; }
    }
}
