﻿namespace Library.Domain
{
    public interface IDomainEventHandler<T> where T : IDomainEvent
    {
        Task Handle(T domainEvent);
    }

    public class DomainDispatcher
    {
        private readonly IServiceProvider _provider;

        public DomainDispatcher(IServiceProvider provider)
        {
            _provider = provider ?? throw new ArgumentNullException(nameof(provider));
        }

        public async Task DispatchAsync(IEnumerable<IDomainEvent> events)
        {
            foreach (var ev in events)
            {
                var handlers = _provider.GetServices(typeof(IDomainEventHandler<>).MakeGenericType(ev.GetType()));

                foreach (var handler in handlers)
                {
                    await ((dynamic) handler).Handle((dynamic)ev);
                }
            }
        }
    }
}
