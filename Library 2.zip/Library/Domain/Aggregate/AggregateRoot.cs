﻿using Library.Domain.Event;

namespace Library.Domain.Aggregate
{
    public abstract class AggregateRoot
    {
        private readonly List<IDomainEvent> _event = new();

        public IReadOnlyCollection<IDomainEvent> DomainEvents => _event.AsReadOnly();

        protected void AddDomainEvent(IDomainEvent domainEvent)
        {
            _event.Add(domainEvent);
        }

        public void ClearDomainEvents()
        {
            _event.Clear();
        }
    }
}
