﻿using Library.Models;
using MediatR;

namespace Library.Domain.Event
{
    public class BorrowEvent : INotification
    {
        // Khai báo thuộc tính để Handler có thể truy cập
        public BorrowSlip BorrowSlip { get; }
        public List<BorrowDetail> BorrowDetails { get; }

        // Constructor để nhận dữ liệu từ Service truyền sang
        public BorrowEvent(BorrowSlip borrowSlip, List<BorrowDetail> borrowDetails)
        {
            BorrowSlip = borrowSlip;
            BorrowDetails = borrowDetails;
        }
    }
}