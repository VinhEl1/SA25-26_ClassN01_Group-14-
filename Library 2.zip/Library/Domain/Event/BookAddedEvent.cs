﻿
namespace Library.Domain.Event
{
    public class BookAddedEvent : IDomainEvent
    {
        public string Title { get; }

        DateTime IDomainEvent.OccurredOn { get; } = DateTime.UtcNow;    

        public BookAddedEvent(string title) 
        {
            Title = title;
        }
    }
}
