﻿using Library.Models;
using Library.Service.Interface;
using Microsoft.AspNetCore.Mvc;

namespace Library.Controllers
{
    public class BorrowDetailController : ControllerBase
    {

        private readonly IBorrowDetailService _borrowDetailService;
        private readonly ILogger<BorrowDetailController> _logger;

        public BorrowDetailController(IBorrowDetailService borrowDetailService, ILogger<BorrowDetailController> logger)
        {
            _borrowDetailService = borrowDetailService;
            _logger = logger;
        }

        [HttpGet("api/borrowdetails")]
        public IActionResult GetBorrowDetails(int memberID, string? search = null)
        {
            _logger.LogInformation("Getting borrow details for memberID: {MemberID} with search term: {SearchTerm}", memberID, search);
            try
            {
                var borrowDetails = _borrowDetailService.GetBorrowDetails(memberID, search);

                if (borrowDetails == null || !borrowDetails.Any())
                {
                    _logger.LogWarning("No borrow details found for memberID: {MemberID} with search term: {SearchTerm}", memberID, search);
                    return NotFound("No borrow details found");
                }

                _logger.LogInformation("Found {BorrowDetailCount} borrow details for memberID: {MemberID} with search term: {SearchTerm}", borrowDetails.Count(), memberID, search);
                _logger.LogInformation("Success");
                return Ok(borrowDetails);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while getting borrow details for memberID: {MemberID} with search term: {SearchTerm}", memberID, search);
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost("api/borrowdetails")]
        public async Task<IActionResult> AddBorrowDetail([FromBody] BorrowDetail borrowDetail)
        {
            _logger.LogInformation("Adding borrow detail for MemberID: {MemberID}, BookID: {BookID}", borrowDetail.MemberID, borrowDetail.BookID);
            try
            {
                var addedDetail = await _borrowDetailService.AddBorrowDetail(borrowDetail);
                if (addedDetail != null)
                {
                    _logger.LogInformation("Added borrow detail with ID: {BorrowDetailID} for MemberID: {MemberID}, BookID: {BookID}", addedDetail.BorrowDetailID, borrowDetail.MemberID, borrowDetail.BookID);
                    _logger.LogInformation("Success");
                    return Ok(addedDetail);
                }

                _logger.LogWarning("Failed to add borrow detail for MemberID: {MemberID}, BookID: {BookID}", borrowDetail.MemberID, borrowDetail.BookID);
                return BadRequest("Failed to add borrow detail");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while adding borrow detail for MemberID: {MemberID}, BookID: {BookID}", borrowDetail.MemberID, borrowDetail.BookID);
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPut("api/borrowdetails/{id}")]
        public async Task<IActionResult> UpdateBorrowDetail(int id, [FromBody] Models.BorrowDetail borrowDetail)
        {
            _logger.LogInformation("Updating borrow detail with ID: {BorrowDetailID}", id);
            try
            {
                _logger.LogDebug("Update details: {@BorrowDetail}", borrowDetail);
                var updatedDetail = await _borrowDetailService.UpdateBorrowDetail(borrowDetail, id);

                if (updatedDetail == null)
                {
                    _logger.LogWarning("Borrow detail with ID: {BorrowDetailID} not found", id);
                    return NotFound("Borrow detail not found");
                }

                _logger.LogInformation("Updated borrow detail with ID: {BorrowDetailID} successfully", id);
                _logger.LogInformation("Success");
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while updating borrow detail with ID: {BorrowDetailID}", id);
                return StatusCode(500, "Internal server error");
            }
        }
    }
}
