﻿using Library.Models;
using Library.Service.Interface;
using Microsoft.AspNetCore.Mvc;

namespace Library.Controllers
{
    [ApiController]
    [Route("api/return-slips")]
    public class ReturnSlipController : ControllerBase
    {
        private readonly IReturnSlipService _returnSlipService;
        private readonly ILogger<ReturnSlipController> _logger;

        public ReturnSlipController(IReturnSlipService returnSlipService, ILogger<ReturnSlipController> logger)
        {
            _returnSlipService = returnSlipService;
            _logger = logger;
        }

        [HttpGet]
        public IActionResult GetReturnSlips(string? search = null)
        {
            var slips = _returnSlipService.GetReturnSlips(search);
            return Ok(slips ?? new List<ReturnSlip>());
        }

        [HttpPost]
        public async Task<IActionResult> AddReturnSlip([FromBody] ReturnSlip returnSlip)
        {
            try {
                if (returnSlip == null) return BadRequest("Data is null");
                if (returnSlip.StaffID <= 0) returnSlip.StaffID = 1;

                var added = await _returnSlipService.AddReturnSlip(returnSlip);
                return Ok(new { message = "Success", data = added });
            }
            catch (Exception ex) {
                var innerMsg = ex.InnerException?.Message ?? ex.Message;
                return StatusCode(500, new { message = "Lỗi Database", detail = innerMsg });
            }
        }
    }
}