using Library.Service.Interface;
using Microsoft.AspNetCore.Mvc;

namespace Library.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PhotoController : ControllerBase
    {
        private readonly IPhotoService _photoService;
        public PhotoController(IPhotoService photoService) => _photoService = photoService;

        [HttpPost("upload")]
        public async Task<IActionResult> Upload(IFormFile file)
        {
            var result = await _photoService.UploadPhoto(file);
            if (result.Error != null) return BadRequest(result.Error.Message);
            
            // Trả về URL của ảnh trên Cloudinary cho Frontend
            return Ok(new { url = result.SecureUrl.ToString() });
        }
    }
}