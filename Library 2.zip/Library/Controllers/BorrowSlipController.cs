﻿using Library.DTOs.Request;
using Library.Models;
using Library.Service.Interface;
using Microsoft.AspNetCore.Mvc;

namespace Library.Controllers
{
    [ApiController]
    [Route("api/borrow-slips")]
    public class BorrowSlipController : ControllerBase
    {
        private readonly IBorrowSlipService _borrowSlipService;
        private readonly ILogger<BorrowSlipController> _logger;

        public BorrowSlipController(IBorrowSlipService borrowSlipService, ILogger<BorrowSlipController> logger)
        {
            _borrowSlipService = borrowSlipService;
            _logger = logger;
        }

        [HttpGet]
        public async Task<IActionResult> GetBorrowSlips(string? search = null)
        {
            try
            {
                var borrowSlips = await _borrowSlipService.GetBorrowSlipsAsync(search);
                return Ok(borrowSlips ?? new List<BorrowSlip>());
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving borrow slips");
                return StatusCode(500, new { message = "Lỗi server khi lấy danh sách phiếu mượn" });
            }
        }

        [HttpPost]
        public async Task<IActionResult> AddBorrowSlip([FromBody] BorrowSlipDTO dto)
        {
            if (dto == null || dto.BookIDs == null || !dto.BookIDs.Any()) 
                return BadRequest(new { message = "Dữ liệu hoặc danh sách sách mượn không hợp lệ." });

            _logger.LogInformation("Processing borrow slip for MemberID: {MemberID}, StaffID: {StaffID}", dto.MemberID, dto.StaffID);
            
            try
            {
                var isSuccess = await _borrowSlipService.CreateBorrowSlipAsync(dto);
                
                if (isSuccess)
                {
                    return Ok(new { message = "Thêm phiếu mượn thành công", data = dto });
                }
                
                return BadRequest(new { message = "Không thể tạo phiếu mượn. Kiểm tra lại logic nghiệp vụ hoặc tồn kho." });
            }
            catch (Exception ex)
            {
                // LẤY LỖI THẬT TỪ SQL SERVER (Ví dụ: Lỗi khóa ngoại, lỗi kết nối)
                var innerMessage = ex.InnerException != null ? ex.InnerException.Message : ex.Message;
                _logger.LogError("LỖI TẠO PHIẾU MƯỢN: {Error}", innerMessage);

                return BadRequest(new { 
                    message = "Lỗi hệ thống hoặc Database", 
                    detail = innerMessage // Dòng này sẽ hiện lỗi 'Foreign Key' nếu bạn thiếu StaffID
                });
            }
        }

        [HttpPut]
        public async Task<IActionResult> UpdateBorrowSlip([FromBody] BorrowSlip borrowSlip)
        {
            try
            {
                var isSuccess = await _borrowSlipService.UpdateBorrowSlipAsync(borrowSlip);
                if (isSuccess) return Ok(new { message = "Cập nhật thành công" });
                return NotFound(new { message = "Không tìm thấy phiếu mượn" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating borrow slip");
                return StatusCode(500, new { message = "Lỗi cập nhật dữ liệu: " + ex.Message });
            }
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> SoftDeleteBorrowSlip(int id)
        {
            try
            {
                var bSlip = await _borrowSlipService.GetBorrowSlipByIDAsync(id);
                if (bSlip == null) return NotFound(new { message = "Phiếu mượn không tồn tại" });

                var isSuccess = await _borrowSlipService.DeleteBorrowSlipAsync(id);
                if (isSuccess) return Ok(new { message = "Xóa thành công" });

                return BadRequest(new { message = "Không thể thực hiện xóa" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting borrow slip ID: {id}", id);
                return StatusCode(500, new { message = "Lỗi khi xóa dữ liệu" });
            }
        }
    }
}