﻿using Library.Service.Interface;
using Microsoft.AspNetCore.Mvc;

namespace Library.Controllers
{
    public class AudioController : ControllerBase
    {
        private readonly IChunkService _chunkService;
        private readonly ILogger<AudioController> _logger;

        public AudioController(IChunkService chunkService, ILogger<AudioController> logger)
        {
            _chunkService = chunkService;
            _logger = logger;
        }

        [HttpGet("api/audio/{audioId}/merged")]
        public async Task<IActionResult> GetMergedAudio(int audioId)
        {
            var mergedAudio = await _chunkService.GetMergedAudio(audioId);

            _logger.LogInformation($"Merged audio retrieved for AudioID: {audioId}, Size: {mergedAudio.Length} bytes");
            return File(mergedAudio, "audio/mpeg", $"merged_audio_{audioId}.mp3");
        }
    }
}
