using Library.Data;
using Library.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Library.Controllers
{
    [ApiController]
    [Route("api/fix")]
    public class FixDataController : ControllerBase
    {
        private readonly DBContext _context;

        public FixDataController(DBContext context)
        {
            _context = context;
        }

        // API để reset tài khoản vinh09
        [HttpGet("reset-user-vinh")]
        public async Task<IActionResult> ResetUserVinh()
        {
            // 1. Tìm user vinh09
            var user = await _context.Users.FirstOrDefaultAsync(u => u.UserName == "vinh09");

            if (user == null)
            {
                // Chưa có thì tạo mới
                user = new User
                {
                    UserName = "vinh09",
                    Password = "123", // Mật khẩu mặc định
                    FullName = "Nguyễn Thành Vinh",
                    Email = "vinh09@gmail.com",
                    Phone = "0988777666",
                    Role = "User"
                };
                _context.Users.Add(user);
                await _context.SaveChangesAsync(); // Lưu để lấy UserID
            }
            else
            {
                // Có rồi thì reset mật khẩu
                user.Password = "123";
                _context.Users.Update(user);
                await _context.SaveChangesAsync();
            }

            // 2. Kiểm tra và tạo Member (Thẻ thư viện)
            var member = await _context.Members.FirstOrDefaultAsync(m => m.UserID == user.UserID);
            if (member == null)
            {
                member = new Member
                {
                    MemberName = user.FullName,
                    MemberPhone = user.Phone,
                    MemberAddress = "123 Fix Data Street",
                    DOB = new DateTime(2000, 1, 1),
                    Email = user.Email,
                    CardNumber = "MB" + DateTime.Now.Ticks.ToString().Substring(12),
                    JoinDate = DateTime.Now,
                    Status = "Active",
                    UserID = user.UserID
                };
                _context.Members.Add(member);
                await _context.SaveChangesAsync();
            }

            return Ok(new { 
                message = "Đã khôi phục tài khoản thành công!", 
                account = new { username = "vinh09", password = "123" } 
            });
        }
        // API để reset tài khoản admin
        [HttpGet("reset-admin")]
        public async Task<IActionResult> ResetAdmin()
        {
            // 1. Tìm user admin
            var admin = await _context.Users.FirstOrDefaultAsync(u => u.UserName == "admin");

            if (admin != null)
            {
                // Nếu có rồi thì reset mật khẩu về 123
                admin.Password = "123";
                admin.Role = "Admin";
                _context.Users.Update(admin);
                await _context.SaveChangesAsync();
                return Ok(new { message = "Đã reset mật khẩu tài khoản 'admin' về '123'" });
            }
            else
            {
                // Nếu chưa có thì tạo mới
                var newAdmin = new Admin
                {
                    UserName = "admin",
                    Password = "123",
                    FullName = "Administrator",
                    Email = "admin@library.com",
                    Phone = "0123456789",
                    Role = "Admin",
                    Department = "IT"
                };
                _context.Users.Add(newAdmin);
                await _context.SaveChangesAsync();
                return Ok(new { message = "Đã tạo mới tài khoản 'admin' với mật khẩu '123'" });
            }
        }
    }
}