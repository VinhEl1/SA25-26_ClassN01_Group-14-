﻿using Library.Models;
using Library.Service.Interface;
using Microsoft.AspNetCore.Mvc;
using Library.Data; // 1. Bổ sung để dùng DBContext
using Microsoft.EntityFrameworkCore; // 2. Bổ sung để dùng .Include và .FirstOrDefaultAsync

namespace Library.Controllers
{
    [ApiController]
    [Route("api/auth")]
    public class AuthControllerClass : ControllerBase
    {
        private readonly IloginService _loginService;
        private readonly DBContext _context; // 3. Khai báo biến _context

        // 4. Cập nhật Constructor để nhận DBContext từ hệ thống
        public AuthControllerClass(IloginService loginService, DBContext context)
        {
            _loginService = loginService;
            _context = context;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest request)
        {
            if (string.IsNullOrEmpty(request.UserName) || string.IsNullOrEmpty(request.Password))
            {
                return BadRequest("Vui lòng nhập đầy đủ tài khoản và mật khẩu");
            }

            // 1. Lấy Token thông qua loginService
            var token = await _loginService.LoginAsync(request.UserName, request.Password);

            if (token == null)
            {
                return BadRequest("Tài khoản hoặc mật khẩu không đúng");
            }

            // 2. Lấy thông tin chi tiết User từ Database để trả về cho Frontend
            // Dòng này bây giờ sẽ không còn lỗi đỏ ở _context nữa
            var user = await _context.Users
                .Include(u => u.Member) 
                .FirstOrDefaultAsync(u => u.UserName == request.UserName);

            // 3. Trả về kết quả hoàn chỉnh
            return Ok(new {
                token = token,
                userID = user?.UserID,
                userName = user?.FullName,
                role = user?.Role,
                memberID = user?.Member?.MemberID ?? 0 // Trả về 0 nếu user này không phải là độc giả (Member)
            });
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] User user)
        {
            var success = await _loginService.RegisterAsync(user);
            if (!success) return BadRequest("Đăng ký thất bại");
            return Ok(new { message = "Thành công" });
        }
    }

    public class LoginRequest
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}