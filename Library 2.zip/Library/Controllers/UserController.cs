﻿using Library.DTOs.Request;
using Library.Models;
using Library.Service.Interface;
using Microsoft.AspNetCore.Mvc;

namespace Library.Controllers// domain event, subcirbe nghe event xog xử lí, tối ưu hóa truy vấn (tracking trg linq, index trog db
{
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;
        private readonly ILogger<UserController> _logger;
        public UserController(IUserService userService)
        {
            _userService = userService;
        }
        [HttpGet("api/users")]
        public IActionResult GetUsers(string? search = null)
        {
            var users = _userService.GetUsers(search);
            return Ok(users);
        }
        [HttpPost("add")]
        public async Task<IActionResult> AddUser([FromBody] UserDTO dto)
        {
            _logger.LogInformation("Adding user with username: {Username}", dto.UserName);
            try
            {
                await _userService.AddUser(dto);
                return Ok(new { message = "User created successfully" });
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }
        [HttpPut("api/users")]
        public async Task<IActionResult> UpdateUser([FromBody] UserDTO dto)
        {
            _logger.LogInformation("Updating user with ID: {UserID}", dto.UserID);
            try
            {
                _userService.UpdateUser(dto);
                return Ok();
            }
            catch (Exception ex) 
            {
                _logger.LogError(ex, "An error occurred while updating user with ID: {UserID}", dto.UserID);
                return BadRequest("An error occurred while updating the user.");
            }
        }
        [HttpDelete("api/users/{id}")]
        public IActionResult DeleteUser(int id)
        {
            _logger.LogInformation("Deleting user with ID: {UserID}", id);
            try
            {
                _userService.DeleteUser(id);
                return Ok();
            }
            catch(Exception ex)
            {
                _logger.LogError(ex, "An error occurred while deleting user with ID: {UserID}", id);
                return BadRequest("An error occurred while deleting the user.");
            }
        }
    }
}
