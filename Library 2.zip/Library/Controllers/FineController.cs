﻿//Chứa công thức tính tiền phạt (quan hệ Extend của việc trả sách)
using Library.Models;
using Library.Service.Interface;
using Microsoft.AspNetCore.Mvc;

namespace Library.Controllers
{
    public class FineController : ControllerBase
    {
        private readonly IFineService _fineService;
        private readonly ILogger<FineController> _logger;

        public FineController(IFineService fineService, ILogger<FineController> logger)
        {
            _fineService = fineService;
            _logger = logger;
        }

        [HttpGet("api/fines")]
        public IActionResult GetFines(string? search = null)
        {
            _logger.LogInformation("Retrieving fines with search term: {SearchTerm}", search);
            try
            {
                _logger.LogDebug("Search term: {SearchTerm}", search);
                var fines = _fineService.GetFines(search);

                if (fines == null || !fines.Any())
                {
                    _logger.LogWarning("No fines found matching the search term: {SearchTerm}", search);
                    return NotFound("No fines found");
                }

                _logger.LogInformation("Success");
                return Ok(fines);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while retrieving fines with search term: {SearchTerm}", search);
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost("api/fines")]
        public async Task<IActionResult> AddFine([FromBody] Fine fine)
        {
            _logger.LogInformation("Adding fine for FineID: {FineID}", fine.FineID);
            try
            {
                _logger.LogDebug("Fine: {@Fine}", fine);
                var addedFine = await _fineService.AddFine(fine);

                if (addedFine == null)
                {
                    _logger.LogWarning("Failed to add fine for FineID: {FineID}", fine.FineID);
                    return BadRequest("Failed to add fine");
                }

                _logger.LogInformation("Added fine with FineID: {FineID}", addedFine.FineID);
                return Ok(addedFine);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while adding fine for FineID: {FineID}", fine.FineID);
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPut("api/fines")]
        public async Task<IActionResult> UpdateFine([FromBody] Fine fine)
        {
            _logger.LogInformation("Updating fine for FineID: {FineID}", fine.FineID);
            try
            {
                _logger.LogDebug("Fine: {@Fine}", fine);
                var updatedFine = await _fineService.UpdateFine(fine);

                if (updatedFine == null)
                {
                    _logger.LogWarning("Failed to update fine for FineID: {FineID}", fine.FineID);
                    return BadRequest("Failed to update fine");
                }

                _logger.LogInformation("Updated fine with FineID: {FineID}", updatedFine.FineID);
                _logger.LogInformation("Success");
                return Ok(updatedFine);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while updating fine for FineID: {FineID}", fine.FineID);
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpDelete("api/fines/{id}")]
        public async Task<IActionResult> DeleteFine(int id)
        {
            _logger.LogInformation("Deleting fine with FineID: {FineID}", id);
            try
            {
                _logger.LogDebug("FineID: {FineID}", id);
                await _fineService.DeleteFine(id);

                if (await _fineService.GetFineById(id) != null)
                {
                    _logger.LogWarning("Failed to delete fine with FineID: {FineID}", id);
                    return BadRequest("Failed to delete fine");
                }

                _logger.LogInformation("Deleted fine with FineID: {FineID}", id);
                _logger.LogInformation("Success");
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while deleting fine with FineID: {FineID}", id);
                return StatusCode(500, "Internal server error");
            }
        }
    }
}
