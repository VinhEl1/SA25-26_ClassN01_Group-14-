﻿using Library.Models;
using Library.Service.Interface;
using Microsoft.AspNetCore.Mvc;

namespace Library.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BookHistoryController : ControllerBase
    {
        private readonly IBookHistoryService _bookHistoryService;
        private readonly ILogger<BookHistoryController> _logger;
        public BookHistoryController(IBookHistoryService bookHistoryService, ILogger<BookHistoryController> logger)
        {
            _bookHistoryService = bookHistoryService;
            _logger = logger;
        }

        [HttpGet]
        public async Task<IEnumerable<BookHistory>> GetBookHistories(string? search = null)
        {
            _logger.LogInformation("Searching book's edit history with search term: {SearchTerm}", search);
            try
            {
                return await _bookHistoryService.GetBookHistories(search);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Found no book histories with search: {Search}", search);
                throw;
            }
        }
    }
}
