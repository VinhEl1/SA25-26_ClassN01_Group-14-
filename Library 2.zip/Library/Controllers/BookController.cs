﻿using Library.DTOs.Request;
using Library.Service.Interface;
using Microsoft.AspNetCore.Mvc;
using Library.Helpers;

namespace Library.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BookController : ControllerBase
    {
        private readonly IBookService _bookService;
        private readonly IPhotoService _photoService;
        private readonly ILogger<BookController> _logger;
        private readonly JwtHelper _jwtHelper;

        public BookController(IBookService bookService, IPhotoService photoService, ILogger<BookController> logger, JwtHelper jwtHelper)
        {
            _bookService = bookService;
            _photoService = photoService;
            _logger = logger;
            _jwtHelper = jwtHelper;
        }

        // 1. Lấy danh sách sách
        // URL: GET /api/Book
        [HttpGet]
        public IActionResult GetBooks([FromQuery] string? search, [FromQuery] int page = 1, [FromQuery] int pageSize = 10)
        {
            try 
            {
                if (page < 1) page = 1;

                _logger.LogInformation("Fetching books. Search: {Search}, Page: {Page}", search, page);
                
                var dto = new BookSearchRequestDTO { Search = search };
                
                var result = _bookService.BookSearch(dto, page, pageSize);
                
                // Trả về danh sách Items để Frontend hiển thị ngay
                return Ok(result.Items); 
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching books");
                return BadRequest("Không thể tải danh sách sách.");
            }
        }

        // 2. Thêm sách mới
        // URL: POST /api/Book
        [HttpPost] 
        public async Task<IActionResult> AddBook([FromBody] BookRequestDTO dto)
        {
            try 
            {
                // Hardcode ID = 1 (Admin) để test
                int staffId = 1; 

                // Tự động điền năm nếu thiếu
                if (string.IsNullOrEmpty(dto.PublishYear)) 
                {
                    dto.PublishYear = DateTime.Now.Year.ToString(); 
                }

                _logger.LogInformation("Adding book: {Title}, Price: {Price}", dto.Title, dto.Price);

                await _bookService.AddBook(dto, staffId);
                
                return Ok(new { message = "Thêm sách thành công", data = dto });
            }
            catch (Exception ex)
            {
                // In lỗi chi tiết ra Terminal
                var innerMessage = ex.InnerException != null ? ex.InnerException.Message : ex.Message;
                _logger.LogError("LỖI THÊM SÁCH: {Error}", innerMessage);
                
                return BadRequest(new { message = "Lỗi lưu DB: " + innerMessage });
            }
        }

        // 3. Cập nhật sách
        // URL: PUT /api/Book/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateBook(int id, [FromBody] BookRequestDTO dto)
        {
            try
            {
                int staffId = 1; // Hardcode ID để test

                _logger.LogInformation("Updating book ID: {BookID}", id);

                var editedBook = await _bookService.UpdateBook(dto, staffId, id);

                return Ok(new { message = "Cập nhật thành công", data = editedBook });
            }
            catch (Exception ex)
            {
                // Bắt lỗi chi tiết cho Update
                var innerMessage = ex.InnerException != null ? ex.InnerException.Message : ex.Message;
                _logger.LogError("LỖI SỬA SÁCH: {Error}", innerMessage);

                return BadRequest(new { message = "Lỗi cập nhật: " + innerMessage });
            }
        }

        // 4. Xóa sách
        // URL: DELETE /api/Book/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBook(int id)
        {
            try
            {
                int staffId = 1; // Hardcode ID để test

                _logger.LogInformation("Deleting book ID: {BookID}", id);

                await _bookService.DeleteBook(id, staffId);

                return Ok(new { message = "Đã xóa sách thành công" });
            }
            catch (Exception ex)
            {
                // Bắt lỗi chi tiết cho Delete
                var innerMessage = ex.InnerException != null ? ex.InnerException.Message : ex.Message;
                _logger.LogError("LỖI XÓA SÁCH: {Error}", innerMessage);

                return BadRequest(new { message = "Không thể xóa sách: " + innerMessage });
            }
        }
    } 
}