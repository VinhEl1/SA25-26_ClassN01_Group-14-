﻿using Library.Models;
using Library.Service.Interface;
using Microsoft.AspNetCore.Mvc;

namespace Library.Controllers
{
    [ApiController]
    public class MemberController : ControllerBase
    {
        private readonly IMemberService _memberService;
        private readonly ILogger<MemberController> _logger;

        public MemberController(IMemberService memberService, ILogger<MemberController> logger)
        {
            _memberService = memberService;
            _logger = logger;
        }

        // 1. Lấy danh sách độc giả
        [HttpGet("api/members")]
        public IActionResult GetMembers([FromQuery] string? search = null)
        {
            try
            {
                _logger.LogInformation("Searching members: {SearchTerm}", search);
                var members = _memberService.GetMembers(search);
                return Ok(members);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting members");
                return BadRequest(new { message = ex.Message });
            }
        }

        // 2. Thêm mới độc giả
        [HttpPost("api/members")]
        public async Task<IActionResult> AddMember([FromBody] Member member)
        {
            try
            {
                _logger.LogInformation("Adding member: {FullName}", member.FullName);
                var addedMember = await _memberService.AddMember(member);
                return Ok(new { message = "Thêm độc giả thành công", data = addedMember });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error adding member");
                return BadRequest(new { message = ex.Message });
            }
        }

        // 3. Cập nhật thông tin độc giả
        [HttpPut("api/members/{id}")]
        public async Task<IActionResult> UpdateMember(int id, [FromBody] Member member)
        {
            try
            {
                _logger.LogInformation("Updating member ID: {ID}", id);
                var updatedMember = await _memberService.UpdateMember(member, id);
                return Ok(new { message = "Cập nhật thành công", data = updatedMember });
            }
            catch (KeyNotFoundException)
            {
                return NotFound(new { message = "Không tìm thấy độc giả" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating member");
                return BadRequest(new { message = ex.Message });
            }
        }

        // 4. Xóa độc giả
        [HttpDelete("api/members/{id}")]
        public async Task<IActionResult> DeleteMember(int id)
        {
            try
            {
                _logger.LogInformation("Deleting member ID: {ID}", id);
                await _memberService.DeleteMember(id);
                return Ok(new { message = "Đã xóa độc giả thành công" });
            }
            catch (KeyNotFoundException)
            {
                return NotFound(new { message = "Không tìm thấy độc giả để xóa" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting member");
                return BadRequest(new { message = "Không thể xóa: " + ex.Message });
            }
        }

        // ============================================================
        // PHẦN BỔ SUNG CHO DASHBOARD (DUYỆT THÀNH VIÊN)
        // ============================================================

        // 5. Duyệt độc giả (Chuyển trạng thái từ Pending -> Active)
        // URL: POST /api/members/{id}/approve
        [HttpPost("api/members/{id}/approve")]
        public async Task<IActionResult> ApproveMember(int id)
        {
            try
            {
                _logger.LogInformation("Approving member ID: {ID}", id);
                
                // Lấy thông tin hiện tại
                var member = await _memberService.GetMemberById(id);
                
                // Cập nhật trạng thái
                member.Status = "Active";
                
                await _memberService.UpdateMember(member, id);

                return Ok(new { message = "Đã duyệt độc giả. Tài khoản hiện đã có thể mượn sách." });
            }
            catch (KeyNotFoundException)
            {
                return NotFound(new { message = "Không tìm thấy yêu cầu duyệt của độc giả này." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error approving member");
                return BadRequest(new { message = "Lỗi hệ thống: " + ex.Message });
            }
        }

        // 6. Từ chối duyệt (Xóa yêu cầu đăng ký)
        // URL: DELETE /api/members/{id}/reject
        [HttpDelete("api/members/{id}/reject")]
        public async Task<IActionResult> RejectMember(int id)
        {
            try
            {
                _logger.LogInformation("Rejecting member ID: {ID}", id);
                
                // Khi từ chối yêu cầu ở Dashboard, chúng ta xóa bản ghi Pending đó đi
                await _memberService.DeleteMember(id);

                return Ok(new { message = "Đã từ chối yêu cầu tham gia của độc giả." });
            }
            catch (KeyNotFoundException)
            {
                return NotFound(new { message = "Không tìm thấy yêu cầu để từ chối." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error rejecting member");
                return BadRequest(new { message = "Không thể thực hiện thao tác: " + ex.Message });
            }
        }
    }
}