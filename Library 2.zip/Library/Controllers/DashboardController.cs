using Library.Data;
using Library.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;

namespace Library.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [AllowAnonymous]
    public class DashboardController : ControllerBase
    {
        private readonly DBContext _context;
        public DashboardController(DBContext context) => _context = context;

        [HttpGet("stats")]
        public async Task<IActionResult> GetStats()
        {
            try
            {
                var now = DateTime.Now;
                var currentYear = now.Year;

                // 1. Dữ liệu biểu đồ Area (Hoạt động mượn sách 12 tháng)
                var activity = await _context.BorrowDetails
                    .Where(d => d.BorrowDate.Year == currentYear)
                    .GroupBy(d => d.BorrowDate.Month)
                    .Select(g => new { month = g.Key, count = g.Count() })
                    .ToListAsync();

                var chartData = Enumerable.Range(1, 12).Select(m => new {
                    label = new DateTime(currentYear, m, 1).ToString("MMM"),
                    value = activity.FirstOrDefault(a => a.month == m)?.count ?? 0
                }).ToList();

                // 2. Danh sách Top Borrowed (Lấy 4 sách mượn nhiều nhất)
                var topBooks = await _context.BorrowDetails
                    .Include(d => d.Book)
                    .GroupBy(d => d.BookID)
                    .Select(g => new {
                        title = g.First().Book.Title,
                        author = g.First().Book.Author,
                        borrowCount = g.Count(),
                        progress = Math.Min((g.Count() * 100) / 20, 100) 
                    })
                    .OrderByDescending(x => x.borrowCount)
                    .Take(4)
                    .ToListAsync();

                // 3. Danh sách Pending Member Approvals
                var pendingApprovals = await _context.Members
                    .Where(m => m.Status == "Pending" || string.IsNullOrEmpty(m.Status))
                    .OrderByDescending(m => m.JoinDate)
                    .Select(m => new {
                        id = m.MemberID,
                        name = m.MemberName,
                        time = m.JoinDate.ToString("dd/MM/yyyy HH:mm"),
                        plan = "Student Plan",
                        initial = !string.IsNullOrEmpty(m.MemberName) ? m.MemberName.Substring(0, 1).ToUpper() : "M"
                    })
                    .Take(5)
                    .ToListAsync();

                // ============================================================
                // BỔ SUNG: DỮ LIỆU TÀI KHOẢN NGƯỜI DÙNG (ADMIN & STAFF)
                // ============================================================
                
                // Lấy danh sách nhân sự đang vận hành hệ thống (Dùng cho widget Team)
                var activeUsers = await _context.Users
                    .Where(u => u.Role == "Admin" || u.Role == "Staff")
                    .Select(u => new {
                        fullName = u.FullName,
                        role = u.Role,
                        email = u.Email,
                        initial = !string.IsNullOrEmpty(u.FullName) ? u.FullName.Substring(0, 1).ToUpper() : "A"
                    })
                    .Take(5)
                    .ToListAsync();

                // 4. Trả về tổng hợp tất cả dữ liệu động
                return Ok(new {
                    cards = new {
                        totalInventory = await _context.Books.SumAsync(b => b.Stock),
                        totalBooksCount = await _context.Books.CountAsync(),
                        activeLoans = await _context.BorrowSlips.CountAsync(s => s.Status == "Borrowing"),
                        newMembersCount = await _context.Members.CountAsync(m => m.JoinDate.Month == now.Month),
                        pendingFines = await _context.Fines.Where(f => f.Status != "Paid").SumAsync(f => (double)f.Amount)
                    },
                    chartData,
                    topBooks,
                    pendingApprovals,
                    activeUsers, // Dữ liệu tài khoản admin/staff
                    recentTransactions = await _context.BorrowDetails
                        .Include(d => d.Book)
                        .Include(d => d.Member)
                        .OrderByDescending(d => d.BorrowDate)
                        .Take(5)
                        .Select(d => new {
                            book = d.Book != null ? d.Book.Title : "Sách đã xóa",
                            member = d.Member != null ? d.Member.MemberName : "Ẩn danh",
                            status = d.ReturnDate == null ? "BORROWING" : "RETURNED",
                            date = d.BorrowDate.ToString("dd/MM/yyyy")
                        })
                        .ToListAsync()
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Lỗi server: " + ex.Message });
            }
        }
    }
}