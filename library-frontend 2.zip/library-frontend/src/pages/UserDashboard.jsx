import React, { useState, useEffect } from 'react';
import api from '../api/axios';
import { 
  Search, Bell, Sparkles, BookMarked, LayoutGrid, 
  BookOpen, Star, Trophy, ChevronLeft, ChevronRight, 
  Plus, Info, MapPin, Phone, Mail, Globe, 
  Instagram, Github, Monitor, Printer, ShoppingBag, Loader2, Zap
} from 'lucide-react';

export default function UserDashboard() {
  const [borrowedBooks, setBorrowedBooks] = useState([]);
  const [recommendedBooks, setRecommendedBooks] = useState([]);
  const [loading, setLoading] = useState(true);
  
  const userName = localStorage.getItem('userName') || "User";
  const memberID = localStorage.getItem('userID'); 

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Chú ý: dùng api.get('...') bỏ dấu gạch chéo đầu nếu axios.js đã có /api
        const [borrowRes, booksRes] = await Promise.all([
          api.get(`borrowdetails?memberID=${memberID}`),
          api.get('Book')
        ]);
        setBorrowedBooks(borrowRes.data || []);
        setRecommendedBooks(booksRes.data?.slice(0, 4) || []);
      } catch (err) {
        console.error("Lỗi:", err);
      } finally {
        setLoading(false); // Dù lỗi hay thành công cũng tắt Loading
      }
    };

    if (memberID) {
      fetchData();
    } else {
      setLoading(false); // Nếu không có ID cũng tắt Loading để hiện giao diện trống
    }
  }, [memberID]);

  // ... (giữ nguyên phần return bên dưới)

  if (loading) return (
    <div className="h-screen flex flex-col items-center justify-center bg-white">
      <Loader2 className="animate-spin text-blue-600 mb-4" size={40} />
      <p className="text-slate-400 font-bold uppercase tracking-widest text-[10px]">Đang chuẩn bị không gian đọc...</p>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#F8FAFC] font-sans text-slate-700">
      
      {/* --- NAVBAR --- */}
      <nav className="h-20 bg-white border-b border-slate-100 px-10 flex items-center justify-between sticky top-0 z-50 shadow-sm">
        <div className="flex items-center gap-2 text-blue-600">
          <div className="bg-blue-600 p-2 rounded-xl text-white shadow-lg shadow-blue-200">
            <BookOpen size={20} fill="currentColor" />
          </div>
          <span className="text-xl font-black tracking-tighter text-slate-900 uppercase italic">BiblioLib</span>
        </div>

        <div className="flex-1 max-w-2xl mx-12">
          <div className="relative">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
            <input 
              type="text" 
              placeholder="Tìm kiếm sách, tác giả hoặc thể loại..." 
              className="w-full bg-slate-50 border-none rounded-2xl py-3.5 pl-14 pr-6 text-sm focus:ring-2 focus:ring-blue-500/20 transition-all outline-none font-bold"
            />
          </div>
        </div>

        <div className="flex items-center gap-6">
          <button className="relative p-2.5 text-slate-400 hover:bg-slate-50 rounded-2xl transition-all">
            <Bell size={22} />
            <span className="absolute top-2.5 right-2.5 w-2 h-2 bg-rose-500 border-2 border-white rounded-full"></span>
          </button>
          <div className="flex items-center gap-4 pl-6 border-l border-slate-100">
            <div className="text-right hidden md:block">
              <p className="text-sm font-black text-slate-900 leading-none">{userName}</p>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1.5 italic">Thành viên tích cực</p>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center font-black text-lg shadow-xl shadow-blue-200 uppercase transition-transform hover:scale-105 cursor-pointer">
                {userName.charAt(0)}
            </div>
          </div>
        </div>
      </nav>

      {/* --- MAIN CONTENT --- */}
      <main className="max-w-7xl mx-auto p-10 grid grid-cols-1 lg:grid-cols-12 gap-10">
        
        {/* CỘT TRÁI (8 CỘT) */}
        <div className="lg:col-span-8 space-y-16">
          
          {/* Section: Recommended */}
          <section className="space-y-8">
            <div className="flex justify-between items-center">
              <h3 className="text-2xl font-black text-slate-800 tracking-tight flex items-center gap-3">
                <Sparkles size={24} className="text-yellow-500" /> Gợi ý cho bạn
              </h3>
              <div className="flex gap-2">
                <button className="p-2 rounded-xl border border-slate-200 bg-white text-slate-400 hover:bg-blue-600 hover:text-white transition-all"><ChevronLeft size={20}/></button>
                <button className="p-2 rounded-xl border border-slate-200 bg-white text-slate-400 hover:bg-blue-600 hover:text-white transition-all"><ChevronRight size={20}/></button>
              </div>
            </div>
            <div className="flex gap-8 overflow-x-auto pb-6 scrollbar-hide">
              {recommendedBooks.map(book => (
                <BookCard key={book.bookID} title={book.title} author={book.author} imageUrl={book.imageUrl} />
              ))}
              <div className="min-w-[180px] h-[260px] border-2 border-dashed border-slate-200 rounded-[2.5rem] flex flex-col items-center justify-center text-slate-300 gap-3 cursor-pointer hover:border-blue-400 hover:text-blue-400 transition-all group bg-white">
                <Plus size={40} className="group-hover:rotate-90 transition-transform duration-500"/>
                <span className="text-[10px] font-black uppercase tracking-[0.2em]">Khám phá thêm</span>
              </div>
            </div>
          </section>

         {/* Section: My Current Reads */}
          <section className="space-y-8">
            <h3 className="text-2xl font-black text-slate-800 tracking-tight flex items-center gap-3">
              <BookMarked size={24} className="text-blue-600" /> Sách đang mượn
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {borrowedBooks.length > 0 ? borrowedBooks.map(item => {
                
                // --- LOGIC TÍNH NGÀY (MỚI) ---
                const calculateStatus = (dueDateStr) => {
                    if (!dueDateStr) return { text: "Không xác định", style: "bg-gray-100 text-gray-500 border-gray-200", icon: "⚪" };
                    
                    const due = new Date(dueDateStr);
                    const today = new Date();
                    const diffTime = due - today;
                    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

                    if (diffDays < 0) return { text: `Quá hạn ${Math.abs(diffDays)} ngày`, style: "bg-red-50 text-red-600 border-red-100 animate-pulse", icon: "⚠️" };
                    if (diffDays === 0) return { text: "Hết hạn hôm nay", style: "bg-orange-50 text-orange-600 border-orange-100", icon: "⏰" };
                    return { text: `Còn lại ${diffDays} ngày`, style: "bg-emerald-50 text-emerald-600 border-emerald-100", icon: "🕒" };
                };

                const statusInfo = calculateStatus(item.dueDate);
                const formattedDate = item.dueDate ? new Date(item.dueDate).toLocaleDateString('vi-VN') : "N/A";

                return (
                  <ReadingCard 
                    key={item.borrowDetailID}
                    title={item.bookTitle} 
                    due={`Hạn trả: ${formattedDate}`} 
                    statusInfo={statusInfo}
                  />
                );
              }) : (
                <div className="col-span-2 py-16 text-center bg-white border-2 border-dashed rounded-[3rem] text-slate-300 font-bold uppercase tracking-widest text-xs">
                    Bạn chưa mượn cuốn sách nào.
                </div>
              )}
            </div>
          </section>

          {/* Dịch vụ thư viện */}
          <section className="space-y-8">
            <h3 className="text-2xl font-black text-slate-800 tracking-tight flex items-center gap-3">
              <LayoutGrid size={24} className="text-blue-600" /> Dịch vụ thư viện
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <ServiceBtn icon={<Monitor size={24}/>} label="Đặt chỗ" sub="Khu học tập" />
              <ServiceBtn icon={<ShoppingBag size={24}/>} label="Yêu cầu sách" sub="Đề xuất mua" />
              <ServiceBtn icon={<Monitor size={24}/>} label="E-Library" sub="Tài liệu số" />
              <ServiceBtn icon={<Printer size={24}/>} label="In ấn" sub="Cloud Print" />
            </div>
          </section>
        </div>

        {/* CỘT PHẢI (4 CỘT) */}
        <div className="lg:col-span-4 space-y-10">
          
          {/* Quick Stats */}
          <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm space-y-10">
            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">
              Thống kê cá nhân
            </h3>
            <div className="space-y-8">
              <StatRow icon={<BookOpen size={20}/>} label="Tổng sách mượn" value={borrowedBooks.length} color="bg-blue-50 text-blue-600" />
              <StatRow icon={<Star size={20}/>} label="Thể loại thích" value="Khoa học" color="bg-indigo-50 text-indigo-600" />
              <StatRow icon={<Trophy size={20}/>} label="Điểm thành viên" value="1,250" badge="Hạng Bạc" color="bg-blue-600 text-white" isBlue />
            </div>
          </div>

          {/* Widget Workshop */}
          <div className="bg-slate-900 p-10 rounded-[3rem] text-white relative overflow-hidden shadow-2xl group cursor-pointer">
            <div className="relative z-10 space-y-6">
              <Zap className="text-yellow-400 animate-pulse" size={32} />
              <div>
                <h4 className="text-2xl font-black leading-tight tracking-tight">Workshop Cuối Tuần</h4>
                <p className="text-slate-400 text-sm mt-3 font-medium leading-relaxed italic">"Nghệ thuật viết lách sáng tạo cùng các tác giả nổi tiếng."</p>
              </div>
              <button className="w-full bg-white text-black py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl hover:bg-blue-600 hover:text-white transition-all">Tham gia ngay</button>
            </div>
            <div className="absolute -right-10 -bottom-10 w-48 h-48 bg-blue-600/20 rounded-full blur-3xl group-hover:bg-blue-600/40 transition-all duration-700"></div>
          </div>

          {/* Widget News */}
          <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm space-y-8">
            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Bản tin thư viện</h3>
            <div className="space-y-8 divide-y divide-slate-50">
              <div className="pt-0">
                <p className="text-sm font-black text-slate-800 leading-tight">Cập nhật giờ mở cửa</p>
                <p className="text-[11px] text-slate-400 mt-3 font-medium leading-relaxed uppercase tracking-tighter">Bắt đầu từ thứ 2, thư viện mở cửa lúc 7:30 AM.</p>
              </div>
              <div className="pt-8">
                <p className="text-sm font-black text-slate-800 leading-tight">Sách mới về: The Last Cello</p>
                <p className="text-[11px] text-slate-400 mt-3 font-medium leading-relaxed uppercase tracking-tighter">Đã có mặt tại khu vực Sách Văn học.</p>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* FOOTER */}
      <footer className="bg-white border-t border-slate-100 mt-20 pt-24 pb-12">
        <div className="max-w-7xl mx-auto px-10 grid grid-cols-1 md:grid-cols-3 gap-16 mb-20">
          <div className="space-y-8">
            <div className="flex items-center gap-2 text-blue-600">
              <div className="bg-blue-600 p-1.5 rounded-lg text-white"><BookOpen size={24} fill="currentColor" /></div>
              <span className="text-2xl font-black tracking-tighter text-slate-900 uppercase italic">BiblioLib</span>
            </div>
            <p className="text-slate-400 text-sm font-medium leading-relaxed">
              Cổng thông tin và thư viện số hiện đại dành cho cộng đồng yêu tri thức. Khám phá hàng ngàn đầu sách vật lý và kỹ thuật số.
            </p>
            <div className="flex gap-4">
              <button className="p-3 bg-slate-50 text-slate-400 rounded-full hover:bg-blue-600 hover:text-white transition-all shadow-sm"><Globe size={20}/></button>
              <button className="p-3 bg-slate-50 text-slate-400 rounded-full hover:bg-pink-600 hover:text-white transition-all shadow-sm"><Instagram size={20}/></button>
              <button className="p-3 bg-slate-50 text-slate-400 rounded-full hover:bg-black hover:text-white transition-all shadow-sm"><Github size={20}/></button>
            </div>
          </div>
          
          <div className="space-y-8">
            <h4 className="text-[10px] font-black text-slate-900 uppercase tracking-[0.2em]">Giờ làm việc</h4>
            <div className="space-y-4">
              <div className="flex justify-between text-sm font-bold text-slate-500 border-b border-slate-50 pb-2">
                <span>Thứ 2 - Thứ 6</span> <span className="text-slate-900">9:00 - 21:00</span>
              </div>
              <div className="flex justify-between text-sm font-bold text-slate-500 border-b border-slate-50 pb-2">
                <span>Thứ 7</span> <span className="text-slate-900">10:00 - 18:00</span>
              </div>
              <div className="flex justify-between text-sm font-bold text-slate-500 pb-2">
                <span>Chủ nhật</span> <span className="text-slate-900">12:00 - 17:00</span>
              </div>
            </div>
          </div>

          <div className="space-y-8">
            <h4 className="text-[10px] font-black text-slate-900 uppercase tracking-[0.2em]">Liên hệ</h4>
            <div className="space-y-6">
              <div className="flex items-center gap-4 text-slate-500 font-bold text-sm"><MapPin size={18} className="text-blue-500" /> 123 Thư Viện, Hà Nội</div>
              <div className="flex items-center gap-4 text-slate-500 font-bold text-sm"><Phone size={18} className="text-blue-500" /> +84 (0) 123 456 789</div>
              <div className="flex items-center gap-4 text-slate-500 font-bold text-sm"><Mail size={18} className="text-blue-500" /> support@bibliolib.com</div>
            </div>
          </div>
        </div>
        <div className="text-center border-t border-slate-50 pt-12">
          <p className="text-[9px] font-black text-slate-300 uppercase tracking-[0.3em]">© 2026 BiblioLib Management. Chúc bạn một ngày đọc sách thú vị!</p>
        </div>
      </footer>
    </div>
  );
}

/* --- TÁCH CÁC COMPONENT CON ĐỂ CODE SẠCH --- */

const BookCard = ({ title, author, imageUrl }) => (
  <div className="min-w-[180px] group cursor-pointer animate-in fade-in zoom-in duration-500">
    <div className="h-[260px] bg-slate-200 rounded-[2.5rem] shadow-xl relative overflow-hidden group-hover:-translate-y-3 transition-all duration-700 shadow-slate-200">
      <img src={imageUrl || "https://images.unsplash.com/photo-1543005158-86b704259504?q=80&w=1000&auto=format&fit=crop"} alt={title} className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
    </div>
    <div className="mt-6 space-y-1 px-2">
      <p className="text-sm font-black text-slate-800 truncate leading-tight group-hover:text-blue-600 transition-colors uppercase tracking-tight">{title}</p>
      <p className="text-[10px] text-slate-400 font-bold italic tracking-wide">{author}</p>
    </div>
  </div>
);

// Sửa component con ở cuối file UserDashboard.jsx
const ReadingCard = ({ title, due, statusInfo }) => (
  <div className="bg-white p-7 rounded-[3rem] border border-slate-100 shadow-sm flex gap-8 group hover:shadow-2xl hover:shadow-slate-100 transition-all duration-700">
    <div className="w-24 h-32 bg-slate-50 rounded-2xl shadow-inner flex-shrink-0 flex items-center justify-center font-black text-blue-100 text-3xl uppercase border border-slate-100 group-hover:scale-105 transition-transform overflow-hidden">
        {title ? title.charAt(0) : "B"}
    </div>
    <div className="flex-1 space-y-4 flex flex-col justify-center">
      <div>
        <p className="text-lg font-black text-slate-800 leading-tight truncate" title={title}>{title}</p>
        <p className="text-[11px] text-slate-400 font-bold mt-2 uppercase tracking-wide">
           {due}
        </p>
      </div>
      
      {/* Hiển thị trạng thái màu sắc dựa trên số ngày */}
      <div className={`py-2 px-4 rounded-xl w-fit text-[10px] font-black uppercase tracking-widest border ${statusInfo.style}`}>
        {statusInfo.icon} {statusInfo.text}
      </div>
    </div>
  </div>
);

const ServiceBtn = ({ icon, label, sub }) => (
  <button className="bg-white p-8 rounded-[3rem] border border-slate-50 shadow-sm hover:shadow-2xl hover:border-blue-100 transition-all flex flex-col items-center text-center gap-5 group">
    <div className="p-5 bg-slate-50 rounded-[1.5rem] group-hover:scale-110 group-hover:bg-blue-600 group-hover:text-white transition-all duration-500 shadow-inner text-blue-600">{icon}</div>
    <div>
      <p className="text-sm font-black text-slate-800 leading-tight uppercase tracking-tight">{label}</p>
      <p className="text-[9px] text-slate-400 font-bold mt-1.5 tracking-wide leading-none">{sub}</p>
    </div>
  </button>
);

const StatRow = ({ icon, label, value, badge, color, isBlue }) => (
  <div className="flex items-center justify-between group cursor-default">
    <div className="flex items-center gap-5">
      <div className={`p-3 rounded-2xl ${color} shadow-sm transition-transform group-hover:rotate-12`}>{icon}</div>
      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none">{label}</span>
    </div>
    <div className="flex flex-col items-end">
      <span className={`text-2xl font-black tracking-tighter ${isBlue ? 'text-blue-600' : 'text-slate-800'}`}>{value}</span>
      {badge && <span className="text-[8px] font-black text-blue-600 px-2.5 py-1 border border-blue-100 rounded-full uppercase mt-2 tracking-tighter bg-blue-50">{badge}</span>}
    </div>
  </div>
);