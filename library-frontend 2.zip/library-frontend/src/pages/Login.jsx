import React, { useState } from 'react';
import api from '../api/axios';
import { LogIn, Lock, User as UserIcon, Loader2 } from 'lucide-react';

export default function Login() {
  const [loading, setLoading] = useState(false);
  const [credentials, setCredentials] = useState({ UserName: '', Password: '' });

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await api.post('/auth/login', {
        UserName: credentials.UserName.trim(),
        Password: credentials.Password.trim()
      });
      
      // --- PHẦN SỬA ĐỔI: Lấy thêm memberID ---
      const { token, userID, role, userName, memberID } = res.data;
      
      localStorage.setItem('token', token);
      localStorage.setItem('userID', userID);
      localStorage.setItem('role', role);
      localStorage.setItem('userName', userName);
      
      // --- QUAN TRỌNG: Lưu memberID (nếu không có thì lưu 0) ---
      localStorage.setItem('memberID', memberID || 0);

      window.location.href = "/"; 
      
    } catch (err) {
      console.error("Login Error:", err.response?.data);
      alert(err.response?.data || "Tài khoản hoặc mật khẩu không chính xác!");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] flex items-center justify-center p-4 font-sans text-slate-900">
      <div className="bg-white w-full max-w-md rounded-[3rem] shadow-2xl shadow-blue-100 p-10 animate-in fade-in zoom-in duration-500">
        <div className="text-center mb-10">
          <div className="w-16 h-16 bg-blue-600 text-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-xl shadow-blue-200">
            <LogIn size={32} />
          </div>
          <h1 className="text-3xl font-black text-slate-800 tracking-tight">Library Login</h1>
          <p className="text-slate-400 font-bold text-[10px] uppercase tracking-widest mt-2 text-center w-full">Access your account</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div className="space-y-2">
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Username</label>
            <div className="relative">
              <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={20} />
              <input 
                required 
                className="w-full bg-slate-50 border-none rounded-2xl p-4 pl-12 font-bold outline-none focus:ring-2 focus:ring-blue-500/20 transition-all" 
                placeholder="e.g. vinhuser" 
                value={credentials.UserName}
                onChange={e => setCredentials({...credentials, UserName: e.target.value})} 
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Password</label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={20} />
              <input 
                required 
                type="password" 
                className="w-full bg-slate-50 border-none rounded-2xl p-4 pl-12 font-bold outline-none focus:ring-2 focus:ring-blue-500/20 transition-all" 
                placeholder="••••••••" 
                value={credentials.Password}
                onChange={e => setCredentials({...credentials, Password: e.target.value})} 
              />
            </div>
          </div>

          <button 
            disabled={loading} 
            className="w-full bg-blue-600 text-white py-4 rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl shadow-blue-200 hover:bg-blue-700 transition-all flex items-center justify-center gap-2 mt-4 active:scale-95"
          >
            {loading ? <Loader2 className="animate-spin" /> : "Sign In Now"}
          </button>
        </form>
      </div>
    </div>
  );
}