import { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';

const StatsContext = createContext();

export const StatsProvider = ({ children }) => {
  const [stats, setStats] = useState(null);

  const refreshStats = async () => {
    const res = await axios.get('/api/dashboard/system-summary');
    setStats(res.data);
  };

  useEffect(() => { refreshStats(); }, []);

  return (
    <StatsContext.Provider value={{ stats, refreshStats }}>
      {children}
    </StatsContext.Provider>
  );
};

export const useStats = () => useContext(StatsContext);