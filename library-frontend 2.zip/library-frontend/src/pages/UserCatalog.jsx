import React, { useState, useEffect } from 'react';
import api from '../api/axios';
import { 
  Search, Bell, BookOpen, LayoutGrid, 
  LogOut, User, Settings, Bookmark, X, 
  Clock, RotateCcw, AlertCircle, CheckCircle2, 
  History, Sparkles, ArrowRightLeft, Calendar
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const UserCatalog = () => {
  // --- STATE QUẢN LÝ DỮ LIỆU ---
  const [activeTab, setActiveTab] = useState('All Books');
  const [books, setBooks] = useState([]); 
  const [myLoans, setMyLoans] = useState([]); 
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [viewingBook, setViewingBook] = useState(null);

  const userName = localStorage.getItem('userName') || "Guest";
  const memberID = localStorage.getItem('memberID');

  const [successTicket, setSuccessTicket] = useState(null); 

  // --- 1. FETCH DỮ LIỆU ---
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const booksRes = await api.get(`Book?search=${searchTerm}`);
        setBooks(booksRes.data.items || booksRes.data || []);

        if (memberID && memberID !== "0") {
          const loansRes = await api.get(`borrowdetails?memberID=${memberID}`);
          setMyLoans(loansRes.data || []);
        }
      } catch (err) {
        console.error("Lỗi tải dữ liệu:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [searchTerm, memberID]);

  // --- 2. LOGIC XỬ LÝ (MƯỢN - TRẢ - GIA HẠN) ---

  // A. Mượn sách
  const handleBorrowNow = async (book) => {
    if (!memberID || memberID === "0") return alert("Vui lòng đăng nhập để mượn sách!");
    if (book.stock <= 0) return alert("Sách này đã hết hàng!");
    
    // Tùy chọn: Bỏ confirm để trải nghiệm nhanh hơn
    // if (!window.confirm(`Mượn sách "${book.title}"?`)) return;

    try {
      // Gọi API tạo phiếu mượn
      const res = await api.post('borrow-slips', {
        memberID: parseInt(memberID),
        staffID: 1, // ID hệ thống/admin
        dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString(),
        bookIDs: [book.bookID],
        status: "Borrowing"
      });

      // Nếu thành công (status 200)
      if (res.status === 200) {
        // 1. Đóng modal chi tiết sách
        setViewingBook(null);
        
        // 2. Hiện vé mượn sách (Ticket Modal)
        setSuccessTicket({
            bSlipID: res.data.data.bSlipID,
            borrowDate: res.data.data.borrowDate,
            dueDate: res.data.data.dueDate,
            bookTitle: book.title
        });
      }
    } catch (err) {
      const errorMsg = err.response?.data?.message || err.response?.data?.detail || "Lỗi hệ thống";
      alert("LỖI: " + errorMsg);
    }
  };

  const handleReturnBook = async (loan) => {
    // 1. Log ra xem cấu trúc loan để chắc chắn lấy đúng ID (Debug)
    console.log("Dữ liệu sách trả:", loan);

    if (!window.confirm(`Xác nhận trả cuốn sách này?`)) return;

    try {
        // 2. Chuẩn bị dữ liệu đúng chuẩn DTO mà Backend yêu cầu
        // Lưu ý: Kiểm tra xem bSlipID nằm ở 'loan.bSlipID' hay 'loan.borrowSlip.bSlipID'
        // Dựa vào code cũ của bạn (loan.borrowSlip?.dueDate), có thể ID nằm trong object con.
        // Nhưng thường BorrowDetail sẽ có bSlipID ngay bên ngoài.
        
        const payload = {
            borrowSlipID: loan.bSlipID || loan.borrowSlip?.bSlipID, 
            bookIDs: [ loan.bookID ], // Backend yêu cầu 1 danh sách ID sách
            staffID: 1 // Gửi số 1 để Backend tự xử lý (hoặc lấy từ user đang login nếu là staff)
        };

        // 3. Gọi API mới "/process" mà chúng ta vừa viết
        const response = await api.post('return-slips/process', payload);

        // 4. Thông báo và reload
        alert("Trả sách thành công! " + (response.data.status === "Has Fine" ? "Bạn trả muộn và có phí phạt." : ""));
        window.location.reload();

    } catch (err) {
        console.error("Lỗi trả sách:", err);
        // Hiển thị lỗi chi tiết từ Backend trả về
        const message = err.response?.data?.message || "Có lỗi xảy ra, vui lòng thử lại.";
        alert("Lỗi: " + message);
    }
};
  // C. Gia hạn
  const handleRenew = (loanID) => {
    if(window.confirm("Gia hạn thêm 7 ngày cho cuốn sách này?")) {
        // Demo UI: Thực tế cần gọi API update hạn trả
        alert("Gia hạn thành công! Hạn trả mới đã được cập nhật.");
    }
  };

  const handleLogout = () => {
    localStorage.clear();
    window.location.href = "/login";
  };

  // --- 3. RENDER CONTENT ---
  const renderContent = () => {
    if (loading) return <div className="text-center py-20 text-slate-400 animate-pulse font-bold tracking-widest uppercase">Đang tải dữ liệu thư viện...</div>;

    switch (activeTab) {
      case 'All Books':
        return (
          <>
            <div className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm mb-10">
              <div className="flex gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300" size={20} />
                  <input type="text" placeholder="Tìm kiếm sách, tác giả..." className="w-full bg-slate-50 border-none rounded-2xl py-4 pl-14 pr-6 font-bold text-sm focus:ring-2 focus:ring-blue-500/20 outline-none" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
                </div>
                <button className="bg-blue-600 text-white px-8 rounded-2xl font-black uppercase text-xs tracking-widest hover:bg-blue-700 shadow-lg active:scale-95">Search</button>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-8 pb-20">
              {books.map(book => <BookCard key={book.bookID} book={book} onViewDetail={setViewingBook} />)}
            </div>
          </>
        );

      case 'My Books':
        return <MyBooksView loans={myLoans} onReturn={handleReturnBook} onRenew={handleRenew} />;

      case 'History':
        return <HistoryView loans={myLoans} />;

      case 'Notifications':
        return <NotificationsView loans={myLoans} />;

      case 'Recommendations':
        return <RecommendationsView books={books} myLoans={myLoans} onViewDetail={setViewingBook} />;

      default: return null;
    }
  };
   

  return (
    <div className="flex min-h-screen bg-[#F8FAFC] font-sans text-slate-700">
      {/* SIDEBAR */}
      <aside className="w-72 bg-white border-r border-slate-100 p-8 sticky top-0 h-screen hidden lg:flex flex-col z-20">
        <div className="flex items-center gap-3 text-blue-600 mb-10">
          <div className="bg-blue-600 p-2 rounded-xl text-white shadow-lg shadow-blue-100"><BookOpen size={24} /></div>
          <span className="text-xl font-black text-slate-900 tracking-tighter uppercase italic">Lumina</span>
        </div>

        <button onClick={() => setActiveTab('All Books')} className={`flex items-center gap-4 px-6 py-4 rounded-2xl font-black text-sm mb-8 transition-all shadow-lg ${activeTab === 'All Books' ? 'bg-blue-600 text-white shadow-blue-200' : 'bg-slate-50 text-slate-500 hover:bg-slate-100'}`}>
          <LayoutGrid size={20} /> ALL BOOKS
        </button>

        <nav className="space-y-3">
          <SidebarItem label="My Books" icon={<Bookmark size={18}/>} active={activeTab === 'My Books'} onClick={() => setActiveTab('My Books')} />
          <SidebarItem label="History" icon={<History size={18}/>} active={activeTab === 'History'} onClick={() => setActiveTab('History')} />
          <SidebarItem label="Notifications" icon={<Bell size={18}/>} active={activeTab === 'Notifications'} onClick={() => setActiveTab('Notifications')} />
          <SidebarItem label="For You" icon={<Sparkles size={18}/>} active={activeTab === 'Recommendations'} onClick={() => setActiveTab('Recommendations')} />
        </nav>
      </aside>

      {/* MAIN */}
      <main className="flex-1 p-10">
        <header className="flex justify-end items-center mb-10">
          <div className="relative">
            <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="flex items-center gap-3 pl-6 border-l border-slate-200 hover:opacity-80 transition-all">
              <div className="text-right hidden md:block">
                <p className="text-sm font-black text-slate-900 leading-none">{userName}</p>
                <p className="text-[10px] text-blue-600 font-bold uppercase mt-1 italic tracking-tighter">Member</p>
              </div>
              <div className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center font-black shadow-lg uppercase">{userName.charAt(0)}</div>
            </button>
            {isMenuOpen && (
              <div className="absolute top-14 right-0 w-56 bg-white rounded-[2rem] shadow-2xl border border-slate-100 p-3 z-20 animate-in slide-in-from-top-2">
                <button className="w-full flex items-center gap-3 p-3 text-slate-600 hover:bg-slate-50 rounded-2xl font-bold text-sm"><User size={16} /> Hồ sơ</button>
                <button className="w-full flex items-center gap-3 p-3 text-slate-600 hover:bg-slate-50 rounded-2xl font-bold text-sm"><Settings size={16} /> Cài đặt</button>
                <div className="h-px bg-slate-50 my-2"></div>
                <button onClick={handleLogout} className="w-full flex items-center gap-3 p-3 text-rose-500 hover:bg-rose-50 rounded-2xl font-black text-sm"><LogOut size={16} /> Đăng xuất</button>
              </div>
            )}
          </div>
        </header>

        <div className="mb-8">
            <h1 className="text-3xl font-black text-slate-900 tracking-tight uppercase italic">{activeTab}</h1>
            <p className="text-slate-400 text-xs font-bold uppercase tracking-[0.2em] mt-2">Manage your reading journey</p>
        </div>

        <motion.div key={activeTab} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
            {renderContent()}
        </motion.div>
      </main>

      <AnimatePresence>
        {viewingBook && <BookDetailModal book={viewingBook} onClose={() => setViewingBook(null)} onBorrow={handleBorrowNow} />}
      </AnimatePresence>
    </div>
  );
};

/// 1. MY BOOKS VIEW (Giao diện Quản lý sách cá nhân)
// Thay thế component MyBooksView trong UserCatalog.jsx

const MyBooksView = ({ loans, onReturn, onRenew }) => {
    const activeLoans = loans.filter(l => !l.returnDate);
    const returnedLoans = loans.filter(l => l.returnDate);

    const getDaysLeft = (dueDateStr) => {
        if (!dueDateStr) return 0;
        const diff = new Date(dueDateStr) - new Date();
        return Math.ceil(diff / (1000 * 60 * 60 * 24));
    };

    return (
        <div className="space-y-12">
            <section>
                <div className="flex items-center justify-between mb-6">
                    <h3 className="text-lg font-black text-blue-600 flex items-center gap-2 uppercase tracking-wide">
                        <BookOpen size={20}/> Đang mượn ({activeLoans.length})
                    </h3>
                </div>
                
                {activeLoans.length > 0 ? (
                    <div className="grid grid-cols-1 gap-6">
                        {activeLoans.map(loan => {
                            // Backend mới trả về dueDate và bookImage ở ngay cấp ngoài
                            const dueDate = loan.dueDate; 
                            const daysLeft = getDaysLeft(dueDate);
                            const isOverdue = daysLeft < 0;
                            const bookCover = loan.bookImage || "https://via.placeholder.com/300x400";

                            return (
                                <div key={loan.borrowDetailID} className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm flex flex-col md:flex-row md:items-center justify-between group hover:shadow-lg transition-all gap-6">
                                    <div className="flex gap-6 items-center flex-1">
                                        
                                        {/* HIỂN THỊ ẢNH */}
                                        <div className="w-20 h-28 shrink-0 rounded-2xl shadow-lg overflow-hidden bg-slate-100 border border-slate-200">
                                            <img 
                                                src={bookCover} 
                                                alt={loan.bookTitle}
                                                className="w-full h-full object-cover"
                                                onError={(e) => {
                                                    e.target.onerror = null; 
                                                    e.target.src = "https://via.placeholder.com/150?text=No+Image";
                                                }}
                                            />
                                        </div>

                                        <div className="space-y-2">
                                            <h4 className="font-black text-slate-800 text-lg leading-tight line-clamp-2">
                                                {loan.bookTitle}
                                            </h4>
                                            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">
                                                {loan.bookAuthor}
                                            </p>
                                            
                                            <div className="flex flex-wrap gap-2 mt-2">
                                                {/* HIỂN THỊ NGÀY CÒN LẠI */}
                                                <div className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5 ${isOverdue ? 'bg-rose-50 text-rose-600' : 'bg-emerald-50 text-emerald-600'}`}>
                                                    <Clock size={12}/> {isOverdue ? `Quá hạn ${Math.abs(daysLeft)} ngày` : `Còn lại ${daysLeft} ngày`}
                                                </div>
                                                
                                                {/* HIỂN THỊ HẠN TRẢ */}
                                                <div className="px-3 py-1 rounded-lg bg-slate-50 text-slate-500 text-[10px] font-bold uppercase tracking-widest flex items-center gap-1.5">
                                                    <Calendar size={12}/> Hạn trả: {dueDate ? new Date(dueDate).toLocaleDateString('vi-VN') : 'N/A'}
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Nút hành động */}
                                    <div className="flex items-center gap-3 border-t md:border-t-0 md:border-l border-slate-50 pt-4 md:pt-0 md:pl-6">
                                        <button onClick={() => onRenew(loan.borrowDetailID)} className="px-6 py-3 bg-slate-50 text-blue-600 rounded-2xl font-bold text-xs uppercase tracking-widest hover:bg-blue-50 transition-all flex items-center gap-2">
                                            <RotateCcw size={16}/> Gia hạn
                                        </button>
                                        <button onClick={() => onReturn(loan)} className="px-6 py-3 bg-slate-900 text-white rounded-2xl font-bold text-xs uppercase tracking-widest hover:bg-emerald-500 shadow-xl shadow-slate-200 hover:shadow-emerald-200 transition-all flex items-center gap-2 active:scale-95">
                                            <ArrowRightLeft size={16}/> Trả sách
                                        </button>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                ) : (
                    <div className="p-16 bg-white rounded-[2rem] border-2 border-dashed border-slate-200 text-center text-slate-300 font-bold uppercase text-xs tracking-[0.2em]">
                        Hiện không mượn cuốn sách nào.
                    </div>
                )}
            </section>
            
            {/* Giữ nguyên phần Lịch sử đã trả... */}
        </div>
    );
};

// 2. HISTORY VIEW
const HistoryView = ({ loans }) => (
    <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm">
        <h3 className="text-xl font-black text-slate-800 mb-10 uppercase tracking-tight flex items-center gap-3">
            <History className="text-slate-300"/> Nhật ký hoạt động
        </h3>
        <div className="relative border-l-2 border-slate-100 ml-3 space-y-10 pb-4">
            {loans.map((loan, idx) => (
                <div key={idx} className="relative pl-10">
                    <div className="absolute -left-[9px] top-1 w-4 h-4 bg-blue-600 rounded-full border-4 border-white shadow-sm"></div>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{new Date(loan.borrowDate).toLocaleDateString()}</p>
                    <p className="text-sm font-bold text-slate-700">
                        Bạn đã mượn cuốn <span className="text-blue-600 font-black">"{loan.book?.title}"</span>
                    </p>
                    {loan.returnDate && (
                        <p className="text-xs text-emerald-600 font-bold mt-2 flex items-center gap-2 bg-emerald-50 w-fit px-3 py-1 rounded-lg">
                            <CheckCircle2 size={12}/> Đã hoàn trả vào {new Date(loan.returnDate).toLocaleDateString()}
                        </p>
                    )}
                </div>
            ))}
        </div>
    </div>
);

// 3. NOTIFICATIONS VIEW - ĐÃ CẢI TIẾN
const NotificationsView = ({ loans }) => {
    
    // Hàm tạo danh sách thông báo từ dữ liệu Loans
    const generateNotifications = () => {
        let notifs = [];

        loans.forEach(l => {
            // 1. Kiểm tra Sách đang mượn (Chưa trả)
            if (!l.returnDate) {
                const dueDate = l.dueDate; // Lấy từ API mới (đã fix ở bước trước)
                
                if (dueDate) {
                    const diff = new Date(dueDate) - new Date();
                    const days = Math.ceil(diff / (1000 * 60 * 60 * 24));

                    // A. Quá hạn
                    if (days < 0) {
                        notifs.push({
                            id: `overdue_${l.borrowDetailID}`,
                            type: 'urgent',
                            title: 'QUÁ HẠN TRẢ SÁCH',
                            message: `Cuốn "${l.bookTitle}" đã quá hạn ${Math.abs(days)} ngày. Vui lòng trả gấp!`,
                            icon: <AlertCircle size={24} />,
                            date: new Date(dueDate).toLocaleDateString('vi-VN')
                        });
                    }
                    // B. Sắp đến hạn (còn 3 ngày trở xuống)
                    else if (days <= 3) {
                        notifs.push({
                            id: `warning_${l.borrowDetailID}`,
                            type: 'warning',
                            title: 'SẮP ĐẾN HẠN',
                            message: `Cuốn "${l.bookTitle}" cần trả trong vòng ${days} ngày tới.`,
                            icon: <Clock size={24} />,
                            date: new Date(dueDate).toLocaleDateString('vi-VN')
                        });
                    }
                }
            }

            // 2. Kiểm tra Tiền phạt (Dựa vào FineAmount từ API)
            // Lưu ý: Cần đảm bảo Backend trả về fineAmount
            if (l.fineAmount && l.fineAmount > 0) {
                notifs.push({
                    id: `fine_${l.borrowDetailID}`,
                    type: 'fine',
                    title: 'CHƯA ĐÓNG PHẠT',
                    message: `Bạn có khoản phạt ${l.fineAmount.toLocaleString()}đ cho cuốn "${l.bookTitle}".`,
                    icon: <CheckCircle2 size={24} className="rotate-180" />, // Dùng tạm icon khác hoặc import Wallet
                    date: 'Cần đóng ngay'
                });
            }
        });

        // Sắp xếp: Ưu tiên Urgent -> Fine -> Warning
        return notifs.sort((a, b) => {
            const priority = { 'urgent': 1, 'fine': 2, 'warning': 3 };
            return priority[a.type] - priority[b.type];
        });
    };

    const notifications = generateNotifications();

    // UI Styles
    const styles = {
        urgent: 'bg-red-50 border-red-100 text-red-800',
        warning: 'bg-orange-50 border-orange-100 text-orange-800',
        fine: 'bg-purple-50 border-purple-100 text-purple-800'
    };

    return (
        <div className="space-y-6 animate-in slide-in-from-bottom-4 duration-500">
            <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight flex items-center gap-3">
                <Bell className="text-blue-600"/> Thông báo của bạn ({notifications.length})
            </h3>

            {notifications.length > 0 ? (
                <div className="grid gap-4">
                    {notifications.map((notif) => (
                        <div key={notif.id} className={`p-6 rounded-[2rem] border-2 flex items-start gap-5 transition-all hover:shadow-lg ${styles[notif.type]}`}>
                            <div className="p-3 bg-white rounded-2xl shadow-sm shrink-0">
                                {notif.icon}
                            </div>
                            <div className="flex-1">
                                <div className="flex justify-between items-start">
                                    <h4 className="font-black uppercase tracking-widest text-xs mb-1 opacity-80">
                                        {notif.title}
                                    </h4>
                                    <span className="text-[10px] font-bold bg-white px-3 py-1 rounded-full shadow-sm">
                                        {notif.date}
                                    </span>
                                </div>
                                <p className="text-sm font-bold leading-relaxed mt-1">
                                    {notif.message}
                                </p>
                            </div>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="flex flex-col items-center justify-center py-24 bg-white rounded-[3rem] border-2 border-dashed border-slate-100 text-center">
                    <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mb-6">
                        <Sparkles className="text-slate-300" size={40} />
                    </div>
                    <h4 className="text-lg font-black text-slate-700">Tuyệt vời!</h4>
                    <p className="text-slate-400 font-bold uppercase text-xs tracking-widest mt-2">
                        Bạn không có thông báo hay cảnh báo nào.
                    </p>
                </div>
            )}
        </div>
    );
};
// 4. RECOMMENDATIONS VIEW
const RecommendationsView = ({ books, myLoans, onViewDetail }) => {
    const borrowedIds = myLoans.map(l => l.bookID);
    const suggestions = books.filter(b => !borrowedIds.includes(b.bookID)).slice(0, 4);

    return (
        <div>
            <div className="flex items-center gap-3 mb-8 p-4 bg-indigo-50 text-indigo-600 w-fit rounded-2xl">
                <Sparkles size={20}/> 
                <span className="text-xs font-black uppercase tracking-widest">Gợi ý dành riêng cho bạn</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-8">
                {suggestions.map(book => (
                    <BookCard key={book.bookID} book={book} onViewDetail={onViewDetail} />
                ))}
            </div>
        </div>
    );
};

// --- HELPER COMPONENTS ---
const SidebarItem = ({ label, icon, active, onClick }) => (
  <button onClick={onClick} className={`w-full flex items-center gap-4 px-6 py-4 rounded-2xl cursor-pointer font-bold text-sm transition-all ${active ? 'bg-slate-100 text-blue-600 shadow-inner' : 'text-slate-400 hover:bg-slate-50 hover:text-slate-600'}`}>
    {icon} {label}
  </button>
);

const BookCard = ({ book, onViewDetail }) => {
  const isAvailable = book.stock > 0;
  return (
    <motion.div whileHover={{ y: -8 }} className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden group hover:shadow-2xl transition-all duration-500 flex flex-col h-full">
      <div className="relative aspect-[3/4] overflow-hidden bg-slate-100">
        <img src={book.imageUrl || 'https://via.placeholder.com/300x400'} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt={book.title}/>
        <div className={`absolute top-6 left-6 px-4 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg ${isAvailable ? 'bg-emerald-400/90 text-white' : 'bg-orange-400/90 text-white'} backdrop-blur-md`}>
          {isAvailable ? 'AVAILABLE' : 'BORROWED'}
        </div>
      </div>
      <div className="p-8 flex-1 flex flex-col">
        <h4 className="text-lg font-black text-slate-900 leading-tight mb-2 line-clamp-2 group-hover:text-blue-600 transition-colors cursor-pointer uppercase tracking-tighter italic">{book.title}</h4>
        <p className="text-xs font-bold text-slate-400 mb-6 uppercase tracking-widest italic">{book.author}</p>
        <div className="mt-auto flex items-center justify-between pt-6 border-t border-slate-50">
          <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest italic">In Stock: {book.stock}</span>
          <button onClick={() => onViewDetail(book)} className="text-blue-600 text-[11px] font-black uppercase tracking-widest hover:underline decoration-2 underline-offset-4 transition-all">View Details</button>
        </div>
      </div>
    </motion.div>
  );
};

const BookDetailModal = ({ book, onClose, onBorrow }) => (
  <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
    <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onClick={onClose} className="absolute inset-0 bg-slate-950/60 backdrop-blur-md" />
    <motion.div initial={{scale: 0.9, opacity: 0, y: 40}} animate={{scale: 1, opacity: 1, y: 0}} exit={{scale: 0.9, opacity: 0, y: 40}} className="bg-white rounded-[3rem] w-full max-w-4xl overflow-hidden relative z-10 flex flex-col md:flex-row shadow-2xl border border-slate-100">
        <button onClick={onClose} className="absolute top-6 right-6 p-2 hover:bg-slate-100 rounded-full z-20 text-slate-400"><X size={24}/></button>
        <div className="md:w-2/5 bg-slate-50 p-10 flex items-center justify-center border-r border-slate-100">
            <img src={book.imageUrl || 'https://via.placeholder.com/300x400'} className="w-full h-auto rounded-2xl shadow-2xl transform -rotate-2 hover:rotate-0 transition-transform duration-500 object-cover" alt="" />
        </div>
        <div className="md:w-3/5 p-12 space-y-6 bg-white text-left">
            <div>
                <span className="bg-blue-50 text-blue-600 text-[10px] font-black px-3 py-1 rounded-lg uppercase tracking-widest">{book.category || 'General'}</span>
                <h2 className="text-3xl font-black text-slate-900 mt-4 leading-tight italic uppercase tracking-tight">{book.title}</h2>
                <p className="text-slate-400 font-bold uppercase text-xs mt-1 italic tracking-widest">By {book.author}</p>
            </div>
            <div className="py-6 border-y border-slate-100 space-y-4">
                <p className="text-slate-500 text-sm leading-relaxed font-medium text-justify">
                    Mô tả: Cuốn sách này là một trong những tác phẩm nổi bật. Hãy mượn ngay để khám phá thế giới tri thức.
                </p>
                <div className="grid grid-cols-2 gap-4">
                    <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 text-center">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Publish Year</p>
                        <p className="font-black text-slate-700">{book.publishYear || 'N/A'}</p>
                    </div>
                    <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 text-center">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Stock Status</p>
                        <p className={`font-black ${book.stock > 0 ? 'text-emerald-600' : 'text-orange-500'}`}>
                            {book.stock > 0 ? `${book.stock} Available` : 'Out of Stock'}
                        </p>
                    </div>
                </div>
            </div>
            <div className="flex gap-4">
                <button onClick={() => onBorrow(book)} disabled={book.stock <= 0} className={`flex-1 py-4 rounded-2xl font-black uppercase text-xs tracking-[0.2em] shadow-xl transition-all active:scale-95 ${book.stock > 0 ? 'bg-blue-600 text-white shadow-blue-200 hover:bg-blue-700' : 'bg-slate-200 text-slate-400 cursor-not-allowed'}`}>
                    {book.stock > 0 ? "Borrow Now" : "Out of Stock"}
                </button>
                <button className="p-4 bg-slate-50 text-slate-400 rounded-2xl hover:text-rose-500 hover:bg-rose-50 transition-all border border-slate-100 group"><Bookmark size={24} className="group-hover:fill-current" /></button>
            </div>
        </div>
    </motion.div>
  </div>
);
/* --- MODAL VÉ MƯỢN SÁCH (TICKET) --- */
const TicketModal = ({ ticketData, onClose }) => {
  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-6 font-sans">
      <motion.div 
        initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} 
        className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm"
        onClick={onClose}
      />
      
      <motion.div 
        initial={{scale: 0.8, opacity: 0, y: 50}} 
        animate={{scale: 1, opacity: 1, y: 0}} 
        exit={{scale: 0.8, opacity: 0, y: 50}} 
        className="relative z-20 w-full max-w-sm bg-white rounded-3xl overflow-hidden shadow-2xl"
      >
        {/* Header Màu Xanh */}
        <div className="bg-blue-600 p-6 text-center relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-20"></div>
            <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-3 shadow-lg text-blue-600">
                <CheckCircle2 size={32} />
            </div>
            <h3 className="text-white font-black text-xl uppercase tracking-widest">Mượn Thành Công</h3>
            <p className="text-blue-100 text-xs font-bold uppercase mt-1">Lumina Library System</p>
        </div>

        {/* Nội dung phiếu */}
        <div className="p-8 bg-white relative">
            {/* Răng cưa giả lập vé */}
            <div className="absolute -top-3 left-0 w-full h-6 bg-white rounded-[50%]"></div>

            <div className="text-center space-y-2 mb-8">
                <p className="text-[10px] text-slate-400 font-black uppercase tracking-[0.3em]">MÃ PHIẾU CỦA BẠN</p>
                <p className="text-5xl font-black text-slate-800 tracking-tighter">#{ticketData.bSlipID}</p>
            </div>

            <div className="space-y-4 border-t border-dashed border-slate-200 pt-6">
                <div className="flex justify-between text-sm">
                    <span className="text-slate-400 font-bold">Sách:</span>
                    <span className="font-black text-slate-800 text-right w-2/3 truncate">{ticketData.bookTitle}</span>
                </div>
                <div className="flex justify-between text-sm">
                    <span className="text-slate-400 font-bold">Ngày mượn:</span>
                    <span className="font-black text-slate-800">{new Date(ticketData.borrowDate).toLocaleDateString('vi-VN')}</span>
                </div>
                <div className="flex justify-between text-sm">
                    <span className="text-slate-400 font-bold">Hạn trả:</span>
                    <span className="font-black text-orange-500">{new Date(ticketData.dueDate).toLocaleDateString('vi-VN')}</span>
                </div>
            </div>

            {/* Mã vạch giả lập */}
            <div className="mt-8 pt-6 border-t border-slate-100 text-center">
                <div className="h-12 bg-slate-800 w-3/4 mx-auto rounded-md mb-2 flex items-center justify-center text-white text-[10px] tracking-[0.5em] font-mono">
                    ||| || ||| || ||||
                </div>
                <p className="text-[10px] text-slate-400 font-bold italic">
                    Vui lòng đưa mã này cho thủ thư để nhận sách
                </p>
            </div>
        </div>

        {/* Footer button */}
        <div className="p-4 bg-slate-50 border-t border-slate-100">
            <button onClick={onClose} className="w-full bg-slate-900 text-white py-4 rounded-xl font-black uppercase text-xs tracking-widest hover:bg-blue-600 transition-all">
                Đã Lưu Mã
            </button>
        </div>
      </motion.div>
    </div>
  );
};

export default UserCatalog;