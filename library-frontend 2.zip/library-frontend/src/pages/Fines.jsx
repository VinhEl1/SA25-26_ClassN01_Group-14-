import React, { useState, useEffect } from 'react';
import api from '../api/axios';
import { 
  Wallet, Search, Plus, CheckCircle, 
  Filter, DollarSign, ArrowRight 
} from 'lucide-react';
import AddFineModal from '../components/AddFineModal';

export default function Fines() {
  const [fines, setFines] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  const fetchFines = async () => {
    setLoading(true);
    try {
      const res = await api.get('/fines');
      setFines(res.data);
    } catch (err) {
      console.error("Lỗi tải danh sách phạt", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchFines(); }, []);

  const handlePayment = async (fine) => {
    if (fine.status === 'Paid') return;
    if (window.confirm("Xác nhận độc giả đã đóng khoản phạt này?")) {
      try {
        await api.put('/fines', { 
          ...fine, 
          status: 'Paid', 
          paidDate: new Date().toISOString() 
        });
        alert("Đã cập nhật trạng thái thanh toán!");
        fetchFines();
      } catch (err) { 
        console.error(err);
        alert("Lỗi xử lý!"); 
      }
    }
  };

 // --- LOGIC TÍNH TOÁN MỚI ---

  // 1. Tính tổng tiền CHƯA thu (Pending)
  const totalPending = fines.reduce((sum, f) => {
    const status = f.status?.toLowerCase();
    if (status === 'pending' || status === 'chưa giải quyết') return sum + f.amount;
    return sum;
  }, 0);

  // 2. Tính tổng tiền ĐÃ THU HÔM NAY (Theo ngày hiện tại của máy tính)
  const collectedToday = fines.reduce((sum, f) => {
    const status = f.status?.toLowerCase();
    if ((status === 'paid' || status === 'trả' || status === 'đã trả') && f.paidDate) {
      const pDate = new Date(f.paidDate).toDateString();
      const today = new Date().toDateString();
      if (pDate === today) return sum + f.amount;
    }
    return sum;
  }, 0);

  // 3. Tính TỔNG DOANH THU (Tất cả các phiếu đã trả từ trước tới nay)
  const totalRevenue = fines.reduce((sum, f) => {
    const status = f.status?.toLowerCase();
    if (status === 'paid' || status === 'trả' || status === 'đã trả') return sum + f.amount;
    return sum;
  }, 0);

  // Debug: Mở Console (F12) để xem dữ liệu có paidDate chưa
  console.log("Danh sách phiếu phạt hiện tại:", fines);

  // Lọc theo tìm kiếm
  const filteredFines = fines.filter(f => 
    f.reason?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    f.fineID?.toString().includes(searchTerm)
  );

  return (
    <div className="max-w-7xl mx-auto animate-in fade-in duration-700">
      {/* Header */}
      <div className="flex justify-between items-center mb-10">
        <div>
          <h1 className="text-4xl font-black text-slate-800 tracking-tight flex items-center gap-3">
            <Wallet className="text-red-500" size={36} />
            Fine Management
          </h1>
          <p className="text-slate-400 font-bold mt-1 uppercase text-[10px] tracking-[0.2em]">
            Monitor penalties and payment status
          </p>
        </div>
        <button onClick={() => setIsModalOpen(true)} className="flex items-center gap-2 px-8 py-4 bg-red-600 text-white rounded-2xl hover:bg-red-700 shadow-2xl shadow-red-200 transition-all font-black text-xs uppercase tracking-widest">
          <Plus size={20} /> Create Fine
        </button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
        <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm relative overflow-hidden group">
          <div className="relative z-10">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Total Unpaid Amount</p>
            <p className="text-4xl font-black text-red-600">${totalPending.toLocaleString()}</p>
          </div>
          <DollarSign className="absolute -right-8 -bottom-8 text-red-50 opacity-50 group-hover:scale-110 transition-transform" size={160} />
        </div>

        <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Pending Fines</p>
            <p className="text-4xl font-black text-slate-800">
                {fines.filter(f => f.status?.toLowerCase() === 'pending').length}
            </p>
            <p className="text-xs font-bold text-slate-400 mt-2 italic">Requires immediate collection</p>
        </div>

        {/* Ô ĐÃ THU THẬP HÔM NAY - HIỂN THỊ BIẾN ĐÃ TÍNH TOÁN */}
        <div className="bg-slate-900 p-8 rounded-[2.5rem] text-white shadow-2xl relative overflow-hidden group">
            <div className="relative z-10">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Collected Today</p>
                <p className="text-4xl font-black text-green-400 transition-all group-hover:scale-105 origin-left duration-500">
                    ${collectedToday.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
                <div className="mt-4 flex items-center gap-2 text-xs font-bold text-slate-400 cursor-pointer hover:text-white transition-colors">
                    <ArrowRight size={14} /> View revenue reports
                </div>
            </div>
            <CheckCircle className="absolute -right-6 -bottom-6 text-white/5" size={120} />
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden flex flex-col">
        <div className="p-6 border-b border-slate-50 flex items-center gap-4 bg-white">
            <div className="relative flex-1">
                <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                <input type="text" placeholder="Search fines by reason or ID..." className="w-full pl-12 pr-6 py-3 bg-slate-50 border-none rounded-2xl text-sm font-bold focus:ring-2 focus:ring-red-500/10 outline-none"
                    value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
            </div>
            <button className="p-3 bg-slate-50 text-slate-400 rounded-xl hover:bg-slate-100 transition-all"><Filter size={20}/></button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="text-slate-400 text-[10px] font-black uppercase tracking-[0.2em] bg-slate-50/50">
                <th className="px-8 py-5 text-center">ID</th>
                <th className="px-8 py-5">Reason</th>
                <th className="px-8 py-5">Issued Date</th>
                <th className="px-8 py-5">Amount</th>
                <th className="px-8 py-5 text-center">Status</th>
                <th className="px-8 py-5 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {loading ? (
                <tr><td colSpan="6" className="py-20 text-center font-black text-slate-300 uppercase text-xs tracking-widest animate-pulse">Scanning penalties...</td></tr>
              ) : filteredFines.length > 0 ? (
                filteredFines.map((fine) => (
                  <tr key={fine.fineID} className="hover:bg-gray-50 transition-colors group">
                    <td className="px-8 py-6 text-center font-black text-slate-300 text-xs">#{fine.fineID}</td>
                    <td className="px-8 py-6 font-bold text-slate-700 text-sm group-hover:text-blue-600 transition-colors">{fine.reason}</td>
                    <td className="px-8 py-6 text-sm font-bold text-slate-500 italic">
                      {new Date(fine.issuedDate).toLocaleDateString()}
                    </td>
                    <td className="px-8 py-6 font-black text-slate-800 text-lg">
                      ${fine.amount.toLocaleString()}
                    </td>
                    <td className="px-8 py-6 text-center">
                      <span className={`px-4 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-tighter border-2 ${
                        fine.status?.toLowerCase() === 'paid' 
                        ? 'bg-green-50 text-green-600 border-green-100' 
                        : 'bg-red-50 text-red-600 border-red-100'
                      }`}>
                        {fine.status}
                      </span>
                    </td>
                    <td className="px-8 py-6 text-right">
                      <button 
                        onClick={() => handlePayment(fine)}
                        disabled={fine.status?.toLowerCase() === 'paid'}
                        className={`p-3 rounded-2xl transition-all ${
                          fine.status?.toLowerCase() === 'paid'
                          ? 'text-slate-200 bg-slate-50 cursor-not-allowed border-transparent'
                          : 'text-slate-400 hover:text-green-600 hover:bg-green-50 active:scale-90 shadow-sm border border-slate-100'
                        }`}
                      >
                        <CheckCircle size={20} />
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr><td colSpan="6" className="py-24 text-center text-slate-300 font-bold italic tracking-widest uppercase text-xs">No fine records found.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <AddFineModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onRefresh={fetchFines} />
    </div>
  );
}