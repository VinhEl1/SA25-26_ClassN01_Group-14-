import React, { useState, useEffect } from 'react';
import api from '../api/axios';
import { 
  BarChart3, TrendingUp, Download, Calendar, Zap, 
  Loader2, Trophy, Activity, Target, BookOpen, Users 
} from 'lucide-react';

export default function Reports() {
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalBooks: 0,
    totalMembers: 0,
    totalLoans: 0,
    totalRevenue: 0,
    monthlyData: [],
    avgPerMonth: 0,
    peakMonth: 'N/A'
  });

  const fetchReportData = async () => {
    setLoading(true);
    try {
      const [books, members, loans, fines] = await Promise.all([
        api.get('/Book'),
        api.get('/members'),
        api.get('/borrow-slips'),
        api.get('/fines')
      ]);

      // Đảm bảo dữ liệu là mảng để không bị lỗi .reduce hoặc .filter
      const booksData = books?.data || [];
      const membersData = members?.data || [];
      const loansData = loans?.data || [];
      const finesData = fines?.data || [];

      // Tính doanh thu
      const revenue = finesData.reduce((sum, f) => 
        (f.status?.toLowerCase() === 'paid' || f.status === 'TRẢ') ? sum + (f.amount || 0) : sum, 0);

      // Xử lý 12 tháng
      const monthsFull = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
      const rawChartData = monthsFull.map((m, index) => {
        const count = loansData.filter(l => {
            if (!l.borrowDate) return false;
            return new Date(l.borrowDate).getMonth() === index;
        }).length;
        return { month: m, count: count };
      });

      const maxCount = Math.max(...rawChartData.map(d => d.count), 1);
      const totalLoansCount = rawChartData.reduce((sum, d) => sum + d.count, 0);
      const peakData = [...rawChartData].sort((a, b) => b.count - a.count)[0];

      const chartDataWithHeight = rawChartData.map(d => ({
        ...d,
        displayHeight: d.count === 0 ? 5 : (d.count / maxCount) * 85 + 5 
      }));

      setStats({
        totalBooks: booksData.length,
        totalMembers: membersData.length,
        totalLoans: loansData.length,
        totalRevenue: revenue,
        monthlyData: chartDataWithHeight,
        avgPerMonth: (totalLoansCount / 12).toFixed(1),
        peakMonth: peakData?.count > 0 ? peakData.month : 'N/A'
      });
    } catch (err) {
      console.error("Lỗi lấy dữ liệu báo cáo:", err);
      // Nếu lỗi API, vẫn giữ giá trị mặc định để không trắng trang
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReportData();
  }, []);

  if (loading) return (
    <div className="flex flex-col items-center justify-center h-[70vh] text-slate-400 font-black uppercase tracking-[0.3em] text-[10px]">
      <div className="relative mb-6">
        <Loader2 className="animate-spin text-blue-600" size={48} />
        <Activity className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-blue-400" size={20} />
      </div>
      Generating Intelligence Report...
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto animate-in fade-in slide-in-from-bottom-8 duration-1000 p-4">
      {/* Header */}
      <div className="flex justify-between items-center mb-12">
        <div>
          <h1 className="text-4xl md:text-5xl font-black text-slate-800 tracking-tighter flex items-center gap-4">
            <div className="p-3 bg-indigo-600 text-white rounded-[1.5rem] shadow-xl shadow-indigo-200">
               <BarChart3 size={32} />
            </div>
            Analytics
          </h1>
          <p className="text-slate-400 font-bold mt-2 uppercase text-[10px] tracking-[0.3em] ml-1">
            Real-time library insights
          </p>
        </div>
        <button onClick={() => window.print()} className="hidden md:flex items-center gap-3 px-8 py-4 bg-slate-900 text-white rounded-[1.5rem] hover:bg-black shadow-2xl transition-all font-black text-xs uppercase tracking-widest active:scale-95">
            <Download size={20} /> Export
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        <KPICard label="Borrow Rate" value={`${stats.totalBooks > 0 ? ((stats.totalLoans/stats.totalBooks)*100).toFixed(1) : 0}%`} trend="+12%" icon={Target} color="text-blue-600" bg="bg-blue-50" />
        <KPICard label="Members" value={stats.totalMembers} trend="+4" icon={Users} color="text-purple-600" bg="bg-purple-50" />
        <KPICard label="Inventory" value={stats.totalBooks} trend="Stable" icon={BookOpen} color="text-orange-600" bg="bg-orange-50" />
        <KPICard label="Revenue" value={`$${stats.totalRevenue}`} trend="Live" icon={Zap} color="text-emerald-600" bg="bg-emerald-50" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white p-6 md:p-10 rounded-[3.5rem] border border-slate-100 shadow-sm relative overflow-hidden group">
            <h2 className="text-2xl font-black text-slate-800 tracking-tight mb-16">Monthly Activity</h2>
            
            <div className="flex items-end justify-between h-80 px-2 gap-2 md:gap-4 relative z-10">
              {stats.monthlyData.map((d, i) => (
                <div key={i} className="flex-1 flex flex-col items-center group h-full justify-end">
                  <div 
                    style={{ height: `${d.displayHeight}%` }} 
                    className="w-full bg-gradient-to-t from-blue-600 to-blue-400 rounded-t-xl group-hover:to-indigo-400 transition-all duration-700 relative flex justify-center border-b-4 border-blue-800/20"
                  >
                      <div className="absolute -top-14 bg-slate-900 text-white text-[10px] font-black px-3 py-2 rounded-2xl opacity-0 group-hover:opacity-100 transition-all shadow-2xl z-20 whitespace-nowrap">
                          {d.count} loans
                      </div>
                  </div>
                  <p className="mt-6 text-[8px] md:text-[10px] font-black text-slate-400 uppercase tracking-tighter">
                    {d.month}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
             <div className="bg-blue-600 p-8 rounded-[2.5rem] text-white flex items-center justify-between shadow-xl shadow-blue-200">
                <div>
                   <p className="text-[10px] font-black uppercase tracking-widest opacity-60">Peak Month</p>
                   <p className="text-3xl font-black mt-1">{stats.peakMonth}</p>
                </div>
                <Trophy size={40} className="opacity-30" />
             </div>
             <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm flex items-center justify-between">
                <div>
                   <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Monthly Avg</p>
                   <p className="text-3xl font-black text-slate-800">{stats.avgPerMonth}</p>
                </div>
                <Activity size={40} className="text-slate-100" />
             </div>
          </div>
        </div>

        <div className="bg-slate-900 p-10 rounded-[3.5rem] text-white relative overflow-hidden shadow-2xl">
            <Zap className="text-yellow-400 mb-4 animate-pulse" size={32} />
            <h3 className="text-xl font-black mb-4 tracking-tight">System Insight</h3>
            <p className="text-slate-400 text-sm font-medium leading-relaxed italic">
                "Activity is trending upwards. Peak performance detected in {stats.peakMonth}. Ensure book maintenance is scheduled."
            </p>
            <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-blue-600/10 rounded-full blur-3xl"></div>
        </div>
      </div>
    </div>
  );
}

function KPICard({ label, value, trend, icon: Icon, color, bg }) {
  return (
    <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-xl transition-all duration-500 group">
      <div className="flex justify-between items-center mb-8">
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{label}</p>
        <div className={`p-3 rounded-2xl ${bg} ${color} group-hover:scale-110 transition-transform`}>
            <Icon size={20} />
        </div>
      </div>
      <div className="flex items-end gap-3">
        <h3 className="text-3xl font-black text-slate-800 tracking-tighter">{value}</h3>
        <span className="text-[10px] font-black mb-2 text-emerald-500 bg-emerald-50 px-2 py-0.5 rounded-lg">{trend}</span>
      </div>
    </div>
  );
}