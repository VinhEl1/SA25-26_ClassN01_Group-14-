import React, { useState, useEffect } from 'react';
import api from '../api/axios';
import { 
  ClipboardList, Search, Plus, CheckCircle2, 
  Clock, AlertCircle, Calendar, Loader2, RotateCw
} from 'lucide-react';
import NewLoanModal from '../components/NewLoanModal';

export default function Loans() {
  const [loans, setLoans] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [returningId, setReturningId] = useState(null); // Trạng thái đang xử lý trả sách

  // 1. Lấy danh sách phiếu mượn từ Backend
  const fetchLoans = async () => {
    setLoading(true);
    try {
      const res = await api.get('/borrow-slips');
      // Backend trả về danh sách BorrowSlip
      setLoans(res.data);
    } catch (err) {
      console.error("Lỗi tải danh sách phiếu mượn", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchLoans(); }, []);

  // 2. Xử lý Trả sách (Đã tối ưu để bắt lỗi chi tiết)
  const handleReturn = async (loan) => {
    if (loan.status === 'Returned' || returningId) return;

    if (window.confirm(`Xác nhận trả sách cho phiếu mượn #${loan.bSlipID}?`)) {
      setReturningId(loan.bSlipID); // Hiện icon xoay cho dòng này
      try {
        // A. Tạo phiếu trả (Khớp với ReturnSlipController.cs)
        const returnSlipData = {
          dueDate: loan.dueDate,
          returnDate: new Date().toISOString(),
          staffID: 1, // Mặc định ID 1 là Admin bạn đã tạo trong Docker
          status: "Returned"
        };
        
        await api.post('return-slips', returnSlipData);

        // B. Cập nhật trạng thái phiếu mượn gốc thành 'Returned'
        const updatedBorrowSlip = { 
          ...loan, 
          status: "Returned" 
        };
        await api.put('borrow-slips', updatedBorrowSlip);

        alert("Xác nhận trả sách thành công!");
        fetchLoans(); // Tải lại danh sách
      } catch (err) {
        console.error("Chi tiết lỗi:", err.response?.data);
        
        // Lấy thông báo lỗi cụ thể (ví dụ: lỗi Foreign Key ở Backend)
        const errorDetail = err.response?.data?.detail || err.response?.data?.message || err.message;
        
        alert("KHÔNG THỂ THỰC HIỆN TRẢ SÁCH:\n" + errorDetail);
      } finally {
        setReturningId(null);
      }
    }
  };

  // 3. Logic hiển thị trạng thái
  const getStatusInfo = (status, dueDate) => {
    if (status === 'Returned') {
      return { label: 'Returned', style: 'bg-green-100 text-green-600 border-green-200' };
    }
    
    // Nếu quá ngày trả mà status vẫn là Borrowing -> Hiện Overdue
    const isOverdue = new Date(dueDate) < new Date();
    if (isOverdue) {
      return { label: 'Overdue', style: 'bg-red-100 text-red-600 border-red-200 animate-pulse' };
    }
    
    return { label: 'Borrowing', style: 'bg-blue-100 text-blue-600 border-blue-200' };
  };

  // 4. Lọc danh sách theo ô tìm kiếm
  const filteredLoans = loans.filter(l => 
    l.bSlipID.toString().includes(searchTerm) || 
    l.memberID.toString().includes(searchTerm)
  );

  return (
    <div className="max-w-7xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Header */}
      <div className="flex justify-between items-center mb-10">
        <div>
          <h1 className="text-4xl font-black text-slate-800 tracking-tight flex items-center gap-3">
            <ClipboardList className="text-blue-600" size={36} />
            Loan Management
          </h1>
          <p className="text-slate-400 font-bold mt-1 uppercase text-[10px] tracking-[0.2em]">
            Monitor and process book circulation
          </p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 px-8 py-4 bg-blue-600 text-white rounded-2xl hover:bg-blue-700 shadow-2xl shadow-blue-200 transition-all font-black text-xs uppercase tracking-widest active:scale-95"
        >
          <Plus size={20} /> Create New Loan
        </button>
      </div>

      {/* Stats Mini Cards - Nhảy số theo dữ liệu thật */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
        <div className="bg-white p-7 rounded-[2rem] border border-slate-100 shadow-sm flex items-center gap-5">
            <div className="p-4 bg-blue-50 text-blue-600 rounded-2xl"><Clock size={28}/></div>
            <div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Active Loans</p>
                <p className="text-3xl font-black text-slate-800">
                   {loans.filter(l => l.status === 'Borrowing').length}
                </p>
            </div>
        </div>
        <div className="bg-white p-7 rounded-[2rem] border border-slate-100 shadow-sm flex items-center gap-5">
            <div className="p-4 bg-green-50 text-green-600 rounded-2xl"><CheckCircle2 size={28}/></div>
            <div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Total Returned</p>
                <p className="text-3xl font-black text-slate-800">
                   {loans.filter(l => l.status === 'Returned').length}
                </p>
            </div>
        </div>
        <div className="bg-white p-7 rounded-[2rem] border border-slate-100 shadow-sm flex items-center gap-5">
            <div className="p-4 bg-red-50 text-red-600 rounded-2xl"><AlertCircle size={28}/></div>
            <div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Overdue</p>
                <p className="text-3xl font-black text-slate-800">
                   {loans.filter(l => l.status === 'Borrowing' && new Date(l.dueDate) < new Date()).length}
                </p>
            </div>
        </div>
      </div>

      {/* Table Section */}
      <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden">
        <div className="p-8 border-b border-slate-50 flex items-center justify-between bg-white/50">
            <div className="relative w-full max-w-md">
                <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                <input 
                    type="text" 
                    placeholder="Search by ID or Member ID..."
                    className="w-full pl-14 pr-6 py-4 bg-slate-50 border-none rounded-2xl text-sm font-bold focus:ring-2 focus:ring-blue-500/10 outline-none"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
            <button onClick={fetchLoans} className="p-3 text-slate-400 hover:text-blue-600 transition-colors">
              <RotateCw className={loading ? "animate-spin" : ""} size={20} />
            </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="text-slate-400 text-[10px] font-black uppercase tracking-[0.2em] bg-slate-50/30">
                <th className="px-10 py-5">Loan ID</th>
                <th className="px-10 py-5">Member</th>
                <th className="px-10 py-5">Timeline</th>
                <th className="px-10 py-5 text-center">Status</th>
                <th className="px-10 py-5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {loading && loans.length === 0 ? (
                <tr><td colSpan="5" className="py-20 text-center font-bold text-slate-300 uppercase text-xs tracking-widest animate-pulse italic">Syncing transactions...</td></tr>
              ) : filteredLoans.length > 0 ? (
                filteredLoans.map((loan) => {
                  const statusInfo = getStatusInfo(loan.status, loan.dueDate);
                  const isProcessing = returningId === loan.bSlipID;

                  return (
                    <tr key={loan.bSlipID} className="hover:bg-slate-50/50 transition-colors group">
                      <td className="px-10 py-7 font-black text-blue-600 text-sm italic">#{loan.bSlipID}</td>
                      <td className="px-10 py-7">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 bg-slate-100 rounded-xl flex items-center justify-center font-black text-[10px] text-slate-400">ID</div>
                          <span className="font-bold text-sm text-slate-700">{loan.memberID}</span>
                        </div>
                      </td>
                      <td className="px-10 py-7">
                        <div className="flex flex-col gap-1.5">
                          <div className="flex items-center gap-2 text-[10px] font-bold text-slate-400 uppercase tracking-tighter">
                            <Calendar size={12} /> {new Date(loan.borrowDate).toLocaleDateString()}
                          </div>
                          <div className="flex items-center gap-2 text-xs font-black text-slate-700">
                            <Clock size={14} className="text-orange-400" /> Due: {new Date(loan.dueDate).toLocaleDateString()}
                          </div>
                        </div>
                      </td>
                      <td className="px-10 py-7 text-center">
                        <span className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase border-2 transition-all shadow-sm ${statusInfo.style}`}>
                          {statusInfo.label}
                        </span>
                      </td>
                      <td className="px-10 py-7 text-right">
                        <button 
                          onClick={() => handleReturn(loan)}
                          disabled={loan.status === 'Returned' || isProcessing}
                          className={`p-3.5 rounded-2xl transition-all active:scale-90 ${
                            loan.status === 'Returned'
                            ? 'bg-slate-50 text-slate-200 cursor-not-allowed'
                            : 'bg-white border border-slate-100 text-slate-300 hover:text-green-600 hover:border-green-200 hover:shadow-xl hover:shadow-green-50 shadow-sm'
                          }`}
                        >
                          {isProcessing ? (
                            <Loader2 className="animate-spin" size={20} />
                          ) : (
                            <CheckCircle2 size={20} />
                          )}
                        </button>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr><td colSpan="5" className="py-24 text-center text-slate-300 font-bold italic tracking-wider">No matching transactions found.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <NewLoanModal 
        isOpen={isModalOpen} 
        onClose={() => { setIsModalOpen(false); fetchLoans(); }} 
      />
    </div>
  );
}