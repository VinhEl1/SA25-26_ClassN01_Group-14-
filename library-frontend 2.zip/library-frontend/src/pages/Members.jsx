import React, { useState, useEffect } from 'react';
import api from '../api/axios';
import { Search, Plus, Trash2, Edit3, Users, CreditCard, Mail, Phone, Calendar } from 'lucide-react';
import AddMemberModal from '../components/AddMemberModal';
import EditMemberModal from '../components/EditMemberModal'; // Thêm dòng này

export default function Members() {
  const [members, setMembers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  // State cho Modal Thêm mới
  const [isModalOpen, setIsModalOpen] = useState(false);

  // State cho Modal Chỉnh sửa
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedMember, setSelectedMember] = useState(null);

  const fetchMembers = async () => {
    setLoading(true);
    try {
      const res = await api.get('members');
      setMembers(res.data);
    } catch (err) {
      console.error("Lỗi tải độc giả", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchMembers(); }, []);

  // Hàm khi bấm nút Sửa
  const handleEditClick = (member) => {
    setSelectedMember(member);
    setIsEditModalOpen(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm("Xóa độc giả này? Dữ liệu mượn sách liên quan sẽ bị ảnh hưởng.")) {
      try {
        await api.delete(`/members/${id}`);
        fetchMembers();
      } catch (err) {
        alert("Lỗi: Không thể xóa độc giả này!");
      }
    }
  };

  const filtered = members.filter(m => 
    m.memberName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    m.cardNumber?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex justify-between items-center mb-10">
        <div>
          <h1 className="text-4xl font-black text-slate-800 tracking-tight flex items-center gap-3">
            <Users className="text-blue-600" size={36} />
            Library Members
          </h1>
          <p className="text-slate-400 font-bold mt-1 uppercase text-[10px] tracking-[0.2em]">
            Total Registered: {members.length} members
          </p>
        </div>
        <button onClick={() => setIsModalOpen(true)} className="flex items-center gap-2 px-8 py-4 bg-blue-600 text-white rounded-2xl hover:bg-blue-700 shadow-2xl shadow-blue-200 transition-all font-black text-xs uppercase tracking-widest active:scale-95">
          <Plus size={20} /> Register Member
        </button>
      </div>

      <div className="bg-white p-4 rounded-[2rem] border border-slate-100 shadow-sm mb-10">
        <div className="relative">
          <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300" size={20} />
          <input type="text" placeholder="Search by name or card ID..." className="w-full pl-14 pr-6 py-4 bg-slate-50 border-none rounded-2xl text-sm font-bold focus:ring-2 focus:ring-blue-500/20 outline-none transition-all"
            value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
        </div>
      </div>

      {loading ? (
        <div className="text-center py-20 text-slate-400 font-black text-xs uppercase animate-pulse tracking-[0.2em]">Syncing database...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {filtered.map((m) => (
            <div key={m.memberID} className="group bg-white rounded-[2.5rem] border border-slate-100 p-6 hover:shadow-2xl hover:shadow-slate-200 transition-all duration-500 relative flex flex-col">
              
              <div className="flex items-start gap-5 mb-6">
                <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-3xl flex items-center justify-center text-2xl font-black text-white shadow-lg shadow-blue-200 shrink-0 uppercase">
                  {m.memberName?.charAt(0)}
                </div>
                <div className="flex-1 overflow-hidden">
                  <h3 className="font-black text-slate-800 text-lg truncate mb-1">{m.memberName}</h3>
                  <div className="flex items-center gap-1.5 text-blue-600 font-black text-[10px] uppercase tracking-widest bg-blue-50 px-3 py-1 rounded-full w-fit">
                    <CreditCard size={12} /> {m.cardNumber || `ID: ${m.memberID}`}
                  </div>
                </div>
                <div className="flex flex-col gap-2">
                    {/* SỬA NÚT CHỈNH SỬA Ở ĐÂY */}
                    <button 
                      onClick={() => handleEditClick(m)}
                      className="p-2.5 bg-slate-50 text-slate-400 rounded-xl hover:bg-blue-600 hover:text-white transition-all shadow-sm"
                    >
                      <Edit3 size={16}/>
                    </button>
                    <button onClick={() => handleDelete(m.memberID)} className="p-2.5 bg-slate-50 text-slate-400 rounded-xl hover:bg-red-500 hover:text-white transition-all shadow-sm"><Trash2 size={16}/></button>
                </div>
              </div>

              <div className="space-y-3 bg-slate-50/50 p-5 rounded-3xl border border-slate-50">
                <div className="flex items-center gap-3 text-slate-500 text-sm font-bold">
                  <Phone size={14} className="text-slate-300" /> {m.memberPhone}
                </div>
                <div className="flex items-center gap-3 text-slate-500 text-sm font-bold truncate">
                  <Mail size={14} className="text-slate-300" /> {m.email}
                </div>
                <div className="flex items-center gap-3 text-slate-400 text-[10px] font-black uppercase tracking-tighter pt-2 border-t border-slate-100">
                  <Calendar size={12} /> Joined: {m.joinDate ? new Date(m.joinDate).toLocaleDateString() : 'N/A'}
                  <span className={`ml-auto px-2 py-0.5 rounded-md ${m.status === 'Active' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`}>
                    {m.status || 'Active'}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* MODALS */}
      <AddMemberModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onRefresh={fetchMembers} />
      
      <EditMemberModal 
        isOpen={isEditModalOpen} 
        onClose={() => setIsEditModalOpen(false)} 
        onRefresh={fetchMembers} 
        memberData={selectedMember} 
      />
    </div>
  );
}