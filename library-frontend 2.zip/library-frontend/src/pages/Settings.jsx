import React, { useState } from 'react';
import { 
  Settings as SettingsIcon, User, Shield, Bell, 
  Globe, Moon, Save, Camera, Mail, Lock 
} from 'lucide-react';

export default function Settings() {
  const [activeTab, setActiveTab] = useState('profile');

  return (
    <div className="max-w-5xl mx-auto animate-in fade-in slide-in-from-bottom-8 duration-700">
      {/* Header */}
      <div className="mb-10">
        <h1 className="text-4xl font-black text-slate-800 tracking-tight flex items-center gap-3">
          <SettingsIcon className="text-blue-600" size={36} />
          System Settings
        </h1>
        <p className="text-slate-400 font-bold mt-2 uppercase text-[10px] tracking-[0.3em] ml-1">
          Manage your library configuration & security
        </p>
      </div>

      <div className="flex flex-col md:flex-row gap-8">
        {/* Sidebar Tabs */}
        <aside className="w-full md:w-64 space-y-2">
          <TabButton 
            active={activeTab === 'profile'} 
            onClick={() => setActiveTab('profile')} 
            icon={User} label="Profile Info" 
          />
          <TabButton 
            active={activeTab === 'library'} 
            onClick={() => setActiveTab('library')} 
            icon={Globe} label="Library Details" 
          />
          <TabButton 
            active={activeTab === 'security'} 
            onClick={() => setActiveTab('security')} 
            icon={Shield} label="Security" 
          />
          <TabButton 
            active={activeTab === 'notifications'} 
            onClick={() => setActiveTab('notifications')} 
            icon={Bell} label="Notifications" 
          />
        </aside>

        {/* Content Area */}
        <div className="flex-1 bg-white rounded-[3rem] border border-slate-100 shadow-sm p-10">
          {activeTab === 'profile' && <ProfileSettings />}
          {activeTab === 'library' && <LibrarySettings />}
          {activeTab === 'security' && <SecuritySettings />}
          {activeTab !== 'profile' && activeTab !== 'library' && activeTab !== 'security' && (
             <div className="text-center py-20 text-slate-300 font-bold italic">Feature coming soon...</div>
          )}
        </div>
      </div>
    </div>
  );
}

// --- SUB COMPONENTS ---

function ProfileSettings() {
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex items-center gap-6 pb-8 border-b border-slate-50">
        <div className="relative group">
          <div className="w-24 h-24 bg-blue-600 rounded-[2rem] flex items-center justify-center text-3xl font-black text-white shadow-xl shadow-blue-200">AD</div>
          <button className="absolute -bottom-2 -right-2 p-2 bg-white rounded-xl shadow-lg border border-slate-100 text-slate-500 hover:text-blue-600 transition-all">
            <Camera size={18} />
          </button>
        </div>
        <div>
          <h3 className="text-xl font-black text-slate-800">Administrator</h3>
          <p className="text-sm font-bold text-slate-400 uppercase tracking-widest mt-1">Super Admin Account</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <InputGroup label="Full Name" value="Library Admin" icon={User} />
        <InputGroup label="Email Address" value="admin@library.com" icon={Mail} />
      </div>

      <button className="flex items-center justify-center gap-2 px-8 py-4 bg-blue-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-100 hover:bg-blue-700 transition-all w-fit">
        <Save size={18} /> Save Profile Changes
      </button>
    </div>
  );
}

function LibrarySettings() {
    return (
      <div className="space-y-8 animate-in fade-in duration-500">
        <h3 className="text-2xl font-black text-slate-800 tracking-tight">Public Information</h3>
        <div className="space-y-6">
            <InputGroup label="Library Name" value="Central City Library" />
            <InputGroup label="Official Address" value="123 Education Ave, Knowledge City" />
            <InputGroup label="Contact Phone" value="+1 (234) 567-890" />
        </div>
        <button className="px-8 py-4 bg-slate-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl transition-all">Update Library Data</button>
      </div>
    );
}

function SecuritySettings() {
    return (
      <div className="space-y-8 animate-in fade-in duration-500">
        <h3 className="text-2xl font-black text-slate-800 tracking-tight">Change Password</h3>
        <div className="space-y-6 max-w-md">
            <InputGroup label="Current Password" type="password" icon={Lock} />
            <InputGroup label="New Password" type="password" icon={Lock} />
            <button className="w-full py-4 bg-red-500 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-red-100 hover:bg-red-600 transition-all">Update Password</button>
        </div>
      </div>
    );
}

// --- UI HELPERS ---

function TabButton({ icon: Icon, label, active, onClick }) {
  return (
    <button 
      onClick={onClick}
      className={`w-full flex items-center gap-4 px-6 py-4 rounded-2xl font-bold text-sm transition-all ${
        active 
        ? 'bg-blue-600 text-white shadow-xl shadow-blue-100 scale-105' 
        : 'text-slate-400 hover:bg-slate-50'
      }`}
    >
      <Icon size={20} />
      {label}
    </button>
  );
}

function InputGroup({ label, value, type = "text", icon: Icon }) {
  return (
    <div className="space-y-2">
      <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{label}</label>
      <div className="relative">
        {Icon && <Icon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />}
        <input 
          type={type} 
          defaultValue={value}
          className={`w-full bg-slate-50 border-none rounded-2xl p-4 text-sm font-bold focus:ring-2 focus:ring-blue-500/10 outline-none transition-all ${Icon ? 'pl-12' : ''}`} 
        />
      </div>
    </div>
  );
}