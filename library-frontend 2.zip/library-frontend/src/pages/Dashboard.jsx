import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { 
  BookOpen, Users, ArrowUpRight, BarChart3, AlertTriangle, ChevronDown, 
  Wifi, Scan, Mail, TrendingUp, MoreHorizontal, Moon, Sun, X, Search, 
  CheckCircle2, LogOut, Settings, User, ShieldCheck
} from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';

const Dashboard = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeModal, setActiveModal] = useState(null);
  const [showProfile, setShowProfile] = useState(false);
  const [period, setPeriod] = useState('month');

  // --- LOGIC THEME ---
  const [theme, setTheme] = useState(localStorage.getItem('theme') || 'light');
  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') root.classList.add('dark');
    else root.classList.remove('dark');
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => setTheme(prev => prev === 'light' ? 'dark' : 'light');

  // --- LOGIC ĐĂNG XUẤT (MỚI) ---
  const handleLogout = () => {
    // 1. Xóa token và các dữ liệu liên quan
    localStorage.removeItem('token');
    localStorage.removeItem('user'); 
    
    // 2. Chuyển hướng về trang đăng nhập
    // Bạn có thể dùng useNavigate() nếu dùng react-router-dom
    window.location.href = '/login'; 
  };

  // --- FETCH DATA ---
  const fetchStats = async (currentPeriod) => {
    try {
      const res = await axios.get(`http://localhost:5268/api/Dashboard/stats?period=${currentPeriod}`);
      setData(res.data);
    } catch (err) { console.error("API Error:", err); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchStats(period); }, [period]);

  const handleApprove = async (id) => {
    try {
      await axios.post(`http://localhost:5268/api/members/${id}/approve`);
      fetchStats(period);
    } catch (err) { alert("Lỗi khi duyệt!"); }
  };

  if (loading) return (
    <div className="flex items-center justify-center min-h-screen dark:bg-slate-950 transition-colors">
      <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#F8FAFC] dark:bg-slate-950 transition-colors duration-500 font-sans text-slate-700 dark:text-slate-300">
      
      <div className="p-8 space-y-8 max-w-[1600px] mx-auto">
        
        {/* --- HEADER SECTION --- */}
        <div className="flex justify-between items-center">
            <div>
                <h1 className="text-3xl font-black text-slate-900 dark:text-white tracking-tight">Dashboard Overview</h1>
                <div className="flex items-center gap-4 mt-1">
                    <p className="text-slate-400 dark:text-slate-500 font-bold uppercase text-[10px] tracking-widest">Library Intelligence System</p>
                    <div className="flex items-center gap-1 bg-white dark:bg-slate-900 p-1 rounded-lg border dark:border-slate-800 shadow-sm">
                        <button onClick={() => setPeriod('day')} className={`px-3 py-1 rounded-md text-[9px] font-black uppercase transition-all ${period === 'day' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}>Ngày</button>
                        <button onClick={() => setPeriod('month')} className={`px-3 py-1 rounded-md text-[9px] font-black uppercase transition-all ${period === 'month' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}>Tháng</button>
                    </div>
                </div>
            </div>
            
            <div className="flex items-center gap-6 relative">
                {/* Theme Toggle */}
                <button onClick={toggleTheme} className="p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm hover:shadow-md transition-all text-blue-600">
                    {theme === 'light' ? <Moon size={20} /> : <Sun size={20} className="text-yellow-400" />}
                </button>

                {/* Profile Dropdown */}
                <div className="flex items-center gap-4 pl-6 border-l dark:border-slate-800 relative">
                    <div className="text-right hidden md:block">
                        <p className="text-sm font-black text-slate-900 dark:text-white">Admin Vinh</p>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter">Senior Librarian</p>
                    </div>
                    
                    {/* Bấm vào Avatar để mở menu */}
                    <button 
                        onClick={() => setShowProfile(!showProfile)} 
                        className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center font-black text-lg shadow-xl shadow-blue-500/20 ring-4 ring-white dark:ring-slate-900 transition-transform active:scale-95 z-50"
                    >
                        V
                    </button>

                    {/* Lớp Overlay để bấm ra ngoài thì đóng menu */}
                    {showProfile && (
                        <div className="fixed inset-0 z-40" onClick={() => setShowProfile(false)} />
                    )}

                    <AnimatePresence>
                        {showProfile && (
                            <motion.div 
                                initial={{ opacity: 0, y: 10 }} 
                                animate={{ opacity: 1, y: 0 }} 
                                exit={{ opacity: 0, y: 10 }}
                                className="absolute top-16 right-0 w-64 bg-white dark:bg-slate-900 rounded-[2rem] shadow-[0_20px_50px_rgba(0,0,0,0.2)] border border-slate-100 dark:border-slate-800 p-4 z-50"
                            >
                                <div className="p-3 border-b dark:border-slate-800 mb-2 font-black text-[10px] uppercase text-slate-400 tracking-widest">Quản trị viên</div>
                                
                                <button className="w-full flex items-center gap-3 p-3 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-xl transition-all font-bold text-sm">
                                    <User size={16}/> Hồ sơ cá nhân
                                </button>
                                
                                <button className="w-full flex items-center gap-3 p-3 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-xl transition-all font-bold text-sm">
                                    <Settings size={16}/> Cài đặt
                                </button>

                                {/* NÚT ĐĂNG XUẤT ĐÃ ĐƯỢC GẮN HÀM */}
                                <button 
                                    onClick={handleLogout} 
                                    className="w-full flex items-center gap-3 p-4 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-2xl transition-all font-black text-sm mt-3 border border-transparent hover:border-rose-100 dark:hover:border-rose-900/50"
                                >
                                    <LogOut size={18} strokeWidth={3}/> Đăng xuất
                                </button>
                            </motion.div>
                        )}
                    </AnimatePresence>
                </div>
            </div>
        </div>

        {/* ... PHẦN CÒN LẠI CỦA CODE (Metrics, Chart, Approvals, Widgets) GIỮ NGUYÊN ... */}
        {/* Để tiết kiệm không gian tôi chỉ tập trung vào phần Header đã fix */}
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <MetricCard label="Total Inventory" value={data?.cards?.totalInventory} sub={`+${data?.cards?.totalBooksCount} Titles`} color="blue" />
            <MetricCard label="Active Loans" value={data?.cards?.activeLoans} sub="85% Capacity" color="purple" />
            <MetricCard label="Monthly Members" value={data?.cards?.newMembersCount} sub="Trending Up" color="orange" />
            <MetricCard label="Pending Fines" value={`$${data?.cards?.pendingFines}`} sub="Requires Action" color="rose" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
                <div className="bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm">
                    <div className="flex justify-between items-start mb-8">
                        <h3 className="text-xl font-black dark:text-white tracking-tight">Member Activity</h3>
                        <div className="flex items-center gap-2 text-[10px] font-black uppercase text-blue-600"><div className="w-2 h-2 rounded-full bg-blue-600 animate-pulse"></div> Live Checkouts</div>
                    </div>
                    <div className="h-72">
                        <ResponsiveContainer width="100%" height="100%">
                            <AreaChart data={data?.chartData || []}>
                                <defs>
                                    <linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="#2563EB" stopOpacity={0.2}/>
                                        <stop offset="95%" stopColor="#2563EB" stopOpacity={0}/>
                                    </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={theme === 'dark' ? '#1e293b' : '#f1f5f9'} />
                                <XAxis dataKey="label" axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#94a3b8'}} />
                                <Tooltip contentStyle={{backgroundColor: theme === 'dark' ? '#0f172a' : '#fff', borderRadius: '16px', border: 'none'}} />
                                <Area type="monotone" dataKey="value" stroke="#2563EB" strokeWidth={4} fill="url(#chartGradient)" />
                            </AreaChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                <div className="bg-white dark:bg-slate-900 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden transition-colors">
                    <div className="p-8 border-b dark:border-slate-800 flex justify-between items-center">
                        <h3 className="text-lg font-black dark:text-white">Pending Member Approvals</h3>
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">New Requests: {data?.pendingApprovals?.length}</span>
                    </div>
                    <div className="divide-y dark:divide-slate-800">
                        {data?.pendingApprovals?.map((member, i) => (
                            <ApprovalRow key={i} {...member} onApprove={() => handleApprove(member.id)} />
                        ))}
                    </div>
                </div>
            </div>

            <div className="space-y-8">
                <div className="bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm">
                    <h3 className="font-black text-slate-900 dark:text-white mb-8 text-center uppercase text-xs tracking-widest">System Vitality</h3>
                    <StatusProgress label="Connectivity" value={98} color="bg-emerald-500" />
                    <div className="mt-8 pt-6 border-t dark:border-slate-800 flex items-center justify-center gap-3">
                        <div className="p-2 bg-emerald-50 dark:bg-emerald-500/10 rounded-xl text-emerald-500 shadow-inner"><Wifi size={20}/></div>
                        <span className="text-[10px] font-black uppercase text-emerald-500 tracking-widest">Active Database</span>
                    </div>
                </div>

                <div className="bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm">
                    <h3 className="font-black text-slate-900 dark:text-white mb-6 tracking-tight">Đội ngũ quản lý</h3>
                    <div className="space-y-5">
                        {data?.activeUsers?.map((u, i) => (
                            <div key={i} className="flex items-center gap-4 group">
                                <div className="w-10 h-10 rounded-2xl bg-slate-50 dark:bg-slate-800 flex items-center justify-center font-black text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-all shadow-sm">{u.initial}</div>
                                <div className="flex-1">
                                    <p className="text-sm font-bold dark:text-white leading-tight">{u.fullName}</p>
                                    <p className="text-[10px] text-slate-400 font-bold uppercase">{u.role}</p>
                                </div>
                                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.5)]"></div>
                            </div>
                        ))}
                    </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                    <button onClick={() => setActiveModal('scan')} className="bg-white dark:bg-slate-900 border-2 border-slate-100 dark:border-slate-800 p-8 rounded-[2.5rem] flex flex-col items-center gap-5 group hover:border-blue-600 transition-all shadow-sm active:scale-95">
                        <div className="p-4 bg-blue-50 dark:bg-blue-900/30 rounded-2xl group-hover:scale-110 transition-transform"><Scan size={28} className="text-blue-600" /></div>
                        <span className="text-[11px] font-black uppercase tracking-widest text-slate-900 dark:text-white">Scan ISBN</span>
                    </button>
                    <button onClick={() => setActiveModal('notify')} className="bg-white dark:bg-slate-900 border-2 border-slate-100 dark:border-slate-800 p-8 rounded-[2.5rem] flex flex-col items-center gap-5 group hover:border-blue-600 transition-all shadow-sm active:scale-95">
                        <div className="p-4 bg-blue-50 dark:bg-blue-900/30 rounded-2xl group-hover:scale-110 transition-transform"><Mail size={28} className="text-blue-600" /></div>
                        <span className="text-[11px] font-black uppercase tracking-widest text-slate-900 dark:text-white">Notify</span>
                    </button>
                </div>
            </div>
        </div>
      </div>

      <AnimatePresence>
        {activeModal && (
          <Modal title={activeModal === 'scan' ? "Máy Quét ISBN" : "Thông báo trễ hạn"} onClose={() => setActiveModal(null)}>
            {activeModal === 'scan' ? (
                <div className="space-y-6 text-center">
                    <div className="w-24 h-24 bg-blue-50 dark:bg-blue-900/20 rounded-full flex items-center justify-center mx-auto mb-4 relative overflow-hidden border-4 border-blue-100 dark:border-blue-800"><Scan size={40} className="text-blue-600 animate-pulse" /></div>
                    <p className="text-sm text-slate-500 dark:text-slate-400">Vui lòng quét mã vạch hoặc nhập mã 13 chữ số.</p>
                    <input autoFocus type="text" placeholder="Nhập mã ISBN..." className="w-full bg-slate-100 dark:bg-slate-800 border-none rounded-2xl py-4 px-6 font-bold text-center focus:ring-2 focus:ring-blue-500 dark:text-white" />
                    <button className="w-full bg-blue-600 text-white py-4 rounded-xl font-black uppercase tracking-widest shadow-lg shadow-blue-500/20">Kiểm tra thông tin</button>
                </div>
            ) : (
                <div className="space-y-6">
                    <div className="p-4 bg-rose-50 dark:bg-rose-900/10 rounded-2xl border border-rose-100 dark:border-rose-900/30 flex items-center gap-3 text-rose-600"><AlertTriangle size={20} /><span className="font-bold text-xs uppercase">Phát hiện 12 độc giả quá hạn</span></div>
                    <button onClick={() => { alert("Đã gửi thông báo!"); setActiveModal(null); }} className="w-full bg-slate-900 dark:bg-white text-white dark:text-slate-950 py-4 rounded-xl font-black uppercase tracking-widest flex items-center justify-center gap-2">Gửi mail đồng loạt</button>
                </div>
            )}
          </Modal>
        )}
      </AnimatePresence>
    </div>
  );
};

// ... CÁC COMPONENT MINI (MetricCard, ApprovalRow, Modal, StatusProgress) GIỮ NGUYÊN NHƯ CODE TRƯỚC ...

const Modal = ({ title, children, onClose }) => (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
        <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onClick={onClose} className="absolute inset-0 bg-slate-950/60 backdrop-blur-md" />
        <motion.div initial={{scale: 0.9, opacity: 0, y: 40}} animate={{scale: 1, opacity: 1, y: 0}} exit={{scale: 0.9, opacity: 0, y: 40}}
            className="bg-white dark:bg-slate-900 w-full max-w-md rounded-[3.5rem] p-10 relative z-10 shadow-2xl border dark:border-slate-800">
            <div className="flex justify-between items-center mb-10"><h3 className="text-xl font-black dark:text-white uppercase tracking-widest">{title}</h3><button onClick={onClose} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full text-slate-400 transition-colors"><X size={24}/></button></div>
            {children}
        </motion.div>
    </div>
);

const MetricCard = ({ label, value, sub, color }) => (
    <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm transition-all hover:shadow-lg">
        <p className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] mb-3">{label}</p>
        <p className="text-4xl font-black text-slate-900 dark:text-white tracking-tighter mb-2">{value || 0}</p>
        <span className="text-[10px] font-black text-emerald-500 bg-emerald-50 dark:bg-emerald-500/10 px-2 py-0.5 rounded-md uppercase">{sub}</span>
    </div>
);

const ApprovalRow = ({ name, plan, initial, onApprove }) => (
    <div className="p-6 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
        <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-2xl flex items-center justify-center font-bold text-blue-600 dark:text-blue-400 text-lg shadow-sm">{initial}</div>
            <div><p className="text-base font-bold text-slate-900 dark:text-slate-100 leading-tight">{name}</p><p className="text-xs text-slate-400 font-bold uppercase tracking-widest">{plan}</p></div>
        </div>
        <button onClick={onApprove} className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-xl text-xs font-black uppercase shadow-lg shadow-blue-500/20 transition-all active:scale-95">Approve</button>
    </div>
);

const StatusProgress = ({ label, value, color }) => (
    <div className="text-center">
        <div className="flex justify-between text-[11px] font-black mb-3 uppercase tracking-widest dark:text-slate-400"><span>{label}</span><span>{value}%</span></div>
        <div className="h-2.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden shadow-inner">
            <motion.div initial={{width:0}} animate={{width: `${value}%`}} transition={{duration: 1.5}} className={`h-full ${color} rounded-full`} />
        </div>
    </div>
);

export default Dashboard;