import React, { useState, useEffect } from 'react';
import api from '../api/axios';
import { Search, Plus, Trash2, Edit3, BookOpen, AlertCircle } from 'lucide-react';
import AddBookModal from '../components/AddBookModal';
import EditBookModal from '../components/EditBookModal'; 

export default function Books() {
  const [books, setBooks] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  // State cho Modal Thêm mới
  const [isModalOpen, setIsModalOpen] = useState(false);

  // State cho Modal Chỉnh sửa
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedBook, setSelectedBook] = useState(null);

  // Lấy dữ liệu từ API
  const fetchBooks = async () => {
    setLoading(true);
    try {
      // Gọi API lấy danh sách sách (Cổng 5268)
      const res = await api.get('Book');
      // Xử lý nếu res trả về PageResult hoặc mảng
      const data = res.data.items || res.data;
      setBooks(Array.isArray(data) ? data : []); 
    } catch (err) {
      console.error("Không thể tải danh sách sách", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchBooks(); }, []);

  // Hàm xử lý khi bấm vào nút Sửa (Hình cái bút)
  const handleEditClick = (book) => {
    setSelectedBook(book);    // 1. Lưu thông tin cuốn sách này vào state
    setIsEditModalOpen(true); // 2. Mở Modal sửa lên
  };

  // Xoá sách
  const handleDelete = async (id) => {
    if (window.confirm("Bạn có chắc chắn muốn xoá cuốn sách này?")) {
      try {
        await api.delete(`/Book/${id}`);
        fetchBooks();
      } catch (err) {
        alert("Lỗi khi xoá sách!");
      }
    }
  };

  // Lọc sách theo ô tìm kiếm
  const filteredBooks = books.filter(b => 
    b.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    b.author.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Header Section */}
      <div className="flex justify-between items-center mb-10">
        <div>
          <h1 className="text-4xl font-black text-slate-800 tracking-tight flex items-center gap-3 italic uppercase">
            <BookOpen className="text-blue-600" size={36} />
            Library Collection
          </h1>
          <p className="text-slate-400 font-bold mt-1 uppercase text-[10px] tracking-[0.2em]">
            Managing {books.length} unique titles in database
          </p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 px-8 py-4 bg-blue-600 text-white rounded-2xl hover:bg-blue-700 shadow-2xl shadow-blue-200 transition-all font-black text-xs uppercase tracking-widest active:scale-95"
        >
          <Plus size={20} /> Add New Title
        </button>
      </div>

      {/* Search Bar */}
      <div className="bg-white p-4 rounded-[2rem] border border-slate-100 shadow-sm mb-10 flex gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300" size={20} />
          <input 
            type="text" 
            placeholder="Search by title or author..." 
            className="w-full pl-14 pr-6 py-4 bg-slate-50 border-none rounded-2xl text-sm font-bold focus:ring-2 focus:ring-blue-500/20 outline-none transition-all"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {/* Book Grid */}
      {loading ? (
        <div className="flex flex-col items-center justify-center py-20">
          <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mb-4"></div>
          <p className="text-slate-400 font-black text-[10px] uppercase tracking-widest">Synchronizing Library...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {filteredBooks.map((book) => (
            <div key={book.bookID} className="group bg-white rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-2xl hover:shadow-slate-200 transition-all duration-500 flex flex-col overflow-hidden relative">
              
              {book.stock <= 5 && (
                <div className="absolute top-4 left-4 z-10 flex items-center gap-1 bg-red-500 text-white px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-tighter animate-pulse">
                  <AlertCircle size={12} /> Low Stock
                </div>
              )}

              <div className="h-64 overflow-hidden bg-slate-100 relative">
                <img 
                  src={book.imageUrl || "https://via.placeholder.com/300x400"} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  alt={book.title}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-center p-6">
                   <div className="flex gap-2">
                      <button 
                        onClick={() => handleEditClick(book)}
                        className="p-3 bg-white text-blue-600 rounded-xl hover:bg-blue-600 hover:text-white transition-all shadow-xl active:scale-90"
                      >
                        <Edit3 size={18} />
                      </button>
                      <button 
                        onClick={() => handleDelete(book.bookID)}
                        className="p-3 bg-white text-red-500 rounded-xl hover:bg-red-500 hover:text-white transition-all shadow-xl active:scale-90"
                      >
                        <Trash2 size={18} />
                      </button>
                   </div>
                </div>
              </div>

              <div className="p-6 flex-1 flex flex-col">
                <div className="mb-4">
                  <h3 className="font-black text-slate-800 line-clamp-1 group-hover:text-blue-600 transition-colors uppercase tracking-tight italic">{book.title}</h3>
                  <p className="text-slate-400 text-[11px] font-bold mt-1">{book.author}</p>
                </div>
                
                <div className="mt-auto pt-4 border-t border-slate-50 flex justify-between items-center">
                  <div>
                    <p className="text-[10px] font-black text-slate-300 uppercase tracking-widest leading-none mb-1">Price</p>
                    <span className="text-lg font-black text-slate-800">${book.price}</span>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] font-black text-slate-300 uppercase tracking-widest leading-none mb-1">Units</p>
                    <span className={`text-sm font-black ${book.stock <= 5 ? 'text-red-500' : 'text-slate-700'}`}>
                      {book.stock} cuốn
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal Thêm Sách */}
      <AddBookModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        onRefresh={fetchBooks} 
      />

      {/* Modal Sửa Sách */}
      <EditBookModal 
        isOpen={isEditModalOpen} 
        onClose={() => setIsEditModalOpen(false)} 
        onRefresh={fetchBooks} 
        book={selectedBook} // Truyền dữ liệu cuốn sách đã chọn vào Modal
      />
    </div>
  );
}