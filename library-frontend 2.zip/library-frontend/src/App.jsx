// src/App.jsx
import { Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Books from './pages/Books'; 
import Members from './pages/Members'; 
import Loans from './pages/Loans'; 
import Fines from './pages/Fines';
import Reports from './pages/Reports';
import Settings from './pages/Settings';
import Login from './pages/Login';
import UserDashboard from './pages/UserDashboard'; // Trang cá nhân/Stats của User
import UserCatalog from './pages/UserCatalog';     // Trang Catalog Lumina Library

function App() {
  const token = localStorage.getItem('token');
  const role = localStorage.getItem('role');

  // 1. Nếu không có Token -> Bắt buộc về trang Login
  if (!token) {
    return (
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    );
  }

  // 2. Luồng ADMIN (Giữ nguyên code của bạn)
  if (role === 'Admin') {
    return (
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/books" element={<Books />} />
          <Route path="/members" element={<Members />} />
          <Route path="/loans" element={<Loans />} />
          <Route path="/fines" element={<Fines />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Layout>
    );
  }

  // 3. Luồng USER (Bổ sung hoàn chỉnh chức năng Động cho Độc giả)
  // Luồng này không bọc Layout Admin để hiển thị giao diện Lumina Library toàn màn hình
  return (
    <Routes>
      {/* Trang chủ của User là trang Khám phá danh mục (Lumina UI) */}
      <Route path="/" element={<UserCatalog />} />
      
      {/* Trang thông tin cá nhân, sách đang mượn (BiblioLib UI) */}
      <Route path="/my-profile" element={<UserDashboard />} />
      
      {/* Các chức năng khác cho User nếu cần triển khai thêm */}
      <Route path="/my-books" element={<UserCatalog />} /> 
      
      {/* Nếu gõ sai đường dẫn thì về trang chủ User */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default App;