import React, { useState, useRef } from 'react';
import api from '../api/axios';
import { X, Upload, Loader2, ChevronDown } from 'lucide-react'; // Thêm ChevronDown

export default function AddBookModal({ isOpen, onClose, onRefresh }) {
  const [loading, setLoading] = useState(false);
  const [preview, setPreview] = useState(null);
  const fileInputRef = useRef();

  const [formData, setFormData] = useState({
    title: '',
    author: '',
    category: '', // Thêm category vào state
    price: 0,
    stock: 0,
    publishYear: new Date().getFullYear().toString(),
    imageUrl: ''
  });

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setPreview(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      let finalImageUrl = formData.imageUrl;

      // 1. Upload ảnh lên Cloudinary nếu có chọn file
      const file = fileInputRef.current.files[0];
      if (file) {
        const data = new FormData();
        data.append('file', file);
        const uploadRes = await api.post('Photo/upload', data);
        finalImageUrl = uploadRes.data.url;
      }

      // 2. Gửi dữ liệu sách kèm URL ảnh và Thể loại
      await api.post('Book', { ...formData, imageUrl: finalImageUrl });

      alert("Thêm sách thành công!");
      setPreview(null);
      // Reset form bao gồm cả category
      setFormData({ 
        title: '', 
        author: '', 
        category: '', 
        price: 0, 
        stock: 0, 
        publishYear: new Date().getFullYear().toString(), 
        imageUrl: '' 
      });
      onRefresh();
      onClose();
    } catch (error) {
      console.error("Full Error:", error);
      let message = "Không thể lưu sách.";
      const serverData = error.response?.data;
      if (typeof serverData === 'string') {
        message = serverData;
      } else if (serverData?.message) {
        message = serverData.message;
      } else if (serverData?.errors) {
        message = Object.values(serverData.errors).flat().join('\n');
      } else if (serverData?.detail) {
        message = serverData.detail;
      }
      alert("HỆ THỐNG BÁO LỖI:\n" + message);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-[2.5rem] w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col md:flex-row animate-in zoom-in duration-200">
        
        {/* CỘT TRÁI: UP ẢNH */}
        <div className="md:w-1/2 bg-slate-50 p-8 flex flex-col items-center justify-center border-r border-slate-100">
          <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Book Cover Image</label>
          
          <div 
            onClick={() => fileInputRef.current.click()}
            className="relative w-full aspect-[3/4] rounded-[2rem] border-4 border-dashed border-slate-200 bg-white flex flex-col items-center justify-center cursor-pointer hover:border-blue-400 hover:bg-blue-50 transition-all overflow-hidden group"
          >
            {preview ? (
              <img src={preview} alt="Preview" className="w-full h-full object-cover" />
            ) : (
              <div className="text-center p-6">
                <div className="bg-slate-100 p-4 rounded-2xl inline-block mb-3 text-slate-400 group-hover:text-blue-500 group-hover:bg-white transition-all">
                  <Upload size={32} />
                </div>
                <p className="text-xs font-bold text-slate-400 group-hover:text-blue-500">Click to upload</p>
              </div>
            )}
            <input type="file" hidden ref={fileInputRef} onChange={handleFileChange} accept="image/*" />
          </div>
        </div>

        {/* CỘT PHẢI: FORM */}
        <div className="md:w-1/2 p-8 bg-white">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl font-black text-slate-800 tracking-tight">Book Details</h2>
            <button onClick={onClose} className="p-2 hover:bg-slate-50 rounded-full text-slate-300 transition-colors"><X size={20}/></button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Title</label>
              <input required value={formData.title} className="w-full bg-slate-50 border-none rounded-2xl p-4 text-sm font-bold outline-none focus:ring-2 focus:ring-blue-500/20 transition-all" 
                onChange={e => setFormData({...formData, title: e.target.value})} />
            </div>

            {/* PHẦN MỚI: CATEGORY */}
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Category</label>
              <div className="relative">
                <select 
                  required 
                  value={formData.category} 
                  className="w-full bg-slate-50 border-none rounded-2xl p-4 text-sm font-bold outline-none focus:ring-2 focus:ring-blue-500/20 appearance-none cursor-pointer"
                  onChange={e => setFormData({...formData, category: e.target.value})}
                >
                  <option value="" disabled>Chọn thể loại...</option>
                  <option value="Viễn tưởng">Viễn tưởng</option>
                  <option value="Khoa học">Khoa học</option>
                  <option value="Lịch sử">Lịch sử</option>
                  <option value="Văn học">Văn học</option>
                </select>
                <ChevronDown size={16} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Author</label>
                <input required value={formData.author} className="w-full bg-slate-50 border-none rounded-2xl p-4 text-sm font-bold outline-none" 
                  onChange={e => setFormData({...formData, author: e.target.value})} />
              </div>
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Year</label>
                <input value={formData.publishYear} className="w-full bg-slate-50 border-none rounded-2xl p-4 text-sm font-bold outline-none" 
                  onChange={e => setFormData({...formData, publishYear: e.target.value})} />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Price ($)</label>
                <input required type="number" value={formData.price} className="w-full bg-slate-50 border-none rounded-2xl p-4 text-sm font-bold outline-none" 
                  onChange={e => setFormData({...formData, price: parseFloat(e.target.value) || 0})} />
              </div>
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Stock</label>
                <input required type="number" value={formData.stock} className="w-full bg-slate-50 border-none rounded-2xl p-4 text-sm font-bold outline-none" 
                  onChange={e => setFormData({...formData, stock: parseInt(e.target.value) || 0})} />
              </div>
            </div>

            <button disabled={loading} type="submit" className="w-full bg-blue-600 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-100 hover:bg-blue-700 transition-all flex items-center justify-center gap-2 mt-2">
              {loading ? <Loader2 className="animate-spin" size={18} /> : "Save to Collection"}
            </button>
          </form>
        </div>

      </div>
    </div>
  );
}