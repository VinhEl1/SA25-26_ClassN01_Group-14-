import React, { useState, useEffect } from 'react';
import api from '../api/axios';
import { X, User, Phone, Mail, MapPin, Calendar, Loader2 } from 'lucide-react';

export default function EditMemberModal({ isOpen, onClose, onRefresh, memberData }) {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    memberName: '',
    memberPhone: '',
    memberAddress: '',
    email: '',
    dob: '',
    status: ''
  });

  // Khi mở modal, điền dữ liệu cũ vào form
  useEffect(() => {
    if (memberData && isOpen) {
      setFormData({
        memberName: memberData.memberName || '',
        memberPhone: memberData.memberPhone || '',
        memberAddress: memberData.memberAddress || '',
        email: memberData.email || '',
        // Định dạng lại ngày để ô input date hiểu được (YYYY-MM-DD)
        dob: memberData.dob ? memberData.dob.split('T')[0] : '',
        status: memberData.status || 'Active'
      });
    }
  }, [memberData, isOpen]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      // Gọi API PUT /api/members/{id}
      await api.put(`/members/${memberData.memberID}`, formData);
      alert("Cập nhật độc giả thành công!");
      onRefresh();
      onClose();
    } catch (error) {
      alert("Lỗi cập nhật: " + (error.response?.data?.message || error.message));
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-[2.5rem] w-full max-w-lg shadow-2xl overflow-hidden animate-in zoom-in duration-200">
        <div className="p-8 border-b border-slate-50 flex justify-between items-center bg-slate-50/50">
          <h2 className="text-2xl font-black text-slate-800 tracking-tight">Edit Member Profile</h2>
          <button onClick={onClose} className="p-2 hover:bg-white rounded-full text-slate-400 shadow-sm transition-all"><X size={20}/></button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-8 space-y-5">
          <div className="space-y-4">
            <div className="relative">
              <User className="absolute left-4 top-4 text-slate-300" size={18} />
              <input required value={formData.memberName} placeholder="Full Name" className="w-full bg-slate-50 border-none rounded-2xl p-4 pl-12 text-sm font-bold outline-none focus:ring-2 focus:ring-blue-500/20" 
                onChange={e => setFormData({...formData, memberName: e.target.value})} />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="relative">
                <Phone className="absolute left-4 top-4 text-slate-300" size={18} />
                <input required value={formData.memberPhone} placeholder="Phone Number" className="w-full bg-slate-50 border-none rounded-2xl p-4 pl-12 text-sm font-bold" 
                  onChange={e => setFormData({...formData, memberPhone: e.target.value})} />
              </div>
              <div className="relative">
                <Calendar className="absolute left-4 top-4 text-slate-300" size={18} />
                <input required type="date" value={formData.dob} className="w-full bg-slate-50 border-none rounded-2xl p-4 pl-12 text-sm font-bold" 
                  onChange={e => setFormData({...formData, dob: e.target.value})} />
              </div>
            </div>

            <div className="relative">
              <Mail className="absolute left-4 top-4 text-slate-300" size={18} />
              <input required type="email" value={formData.email} placeholder="Email Address" className="w-full bg-slate-50 border-none rounded-2xl p-4 pl-12 text-sm font-bold" 
                onChange={e => setFormData({...formData, email: e.target.value})} />
            </div>

            <div className="relative">
              <MapPin className="absolute left-4 top-4 text-slate-300" size={18} />
              <textarea required value={formData.memberAddress} placeholder="Home Address" className="w-full bg-slate-50 border-none rounded-2xl p-4 pl-12 text-sm font-bold h-24 resize-none" 
                onChange={e => setFormData({...formData, memberAddress: e.target.value})} />
            </div>

            <select value={formData.status} className="w-full bg-slate-50 border-none rounded-2xl p-4 text-sm font-bold outline-none"
              onChange={e => setFormData({...formData, status: e.target.value})}>
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
              <option value="Banned">Banned</option>
            </select>
          </div>

          <button disabled={loading} type="submit" className="w-full bg-blue-600 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-100 hover:bg-blue-700 transition-all flex items-center justify-center gap-2 mt-4">
            {loading ? <Loader2 className="animate-spin" size={18} /> : "Update Profile"}
          </button>
        </form>
      </div>
    </div>
  );
}