import React, { useState, useEffect } from 'react';
import api from '../api/axios';
import { X, Check, Loader2 } from 'lucide-react';

export default function NewLoanModal({ isOpen, onClose }) {
  const [members, setMembers] = useState([]);
  const [books, setBooks] = useState([]);
  const [selectedMember, setSelectedMember] = useState('');
  const [selectedBooks, setSelectedBooks] = useState([]);
  
  // TỰ ĐỘNG ĐẶT NGÀY HẸN TRẢ LÀ 7 NGÀY SAU KỂ TỪ HÔM NAY
  const getDefaultDueDate = () => {
    const date = new Date();
    date.setDate(date.getDate() + 7); // Mặc định mượn 7 ngày
    return date.toISOString().split('T')[0];
  };

  const [dueDate, setDueDate] = useState(getDefaultDueDate());
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setLoading(true);
      // Reset lại các lựa chọn cũ khi mở modal mới
      setSelectedBooks([]);
      setSelectedMember('');
      setDueDate(getDefaultDueDate());

      Promise.all([
        api.get('/members'),
        api.get('/Book')
      ]).then(([membersRes, booksRes]) => {
        setMembers(membersRes.data || []);
        setBooks(booksRes.data || []);
        setLoading(false);
      }).catch(err => {
        console.error("Lỗi lấy dữ liệu:", err);
        setLoading(false);
      });
    }
  }, [isOpen]);

  const toggleBook = (id) => {
    setSelectedBooks(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const handleCreate = async () => {
    // KIỂM TRA DỮ LIỆU TRƯỚC KHI GỬI
    console.log("Dữ liệu chuẩn bị gửi:", { selectedMember, selectedBooks, dueDate });

    if (!selectedMember || selectedBooks.length === 0 || !dueDate) {
      alert(`Vui lòng điền đủ: 
        - Độc giả: ${selectedMember ? '✅' : '❌'}
        - Sách: ${selectedBooks.length > 0 ? '✅' : '❌'}
        - Ngày trả: ${dueDate ? '✅' : '❌'}`);
      return;
    }

    const borrowDto = {
      memberID: parseInt(selectedMember),
      staffID: 1, // ID Admin mặc định
      dueDate: dueDate,
      bookIDs: selectedBooks,
      status: "Borrowing"
    };

    try {
      await api.post('/borrow-slips', borrowDto);
      alert("Tạo phiếu mượn thành công!");
      onClose();
    } catch (error) {
      console.error("Lỗi API:", error.response?.data);
      const errorDetail = error.response?.data?.detail || error.response?.data?.message || "Lỗi hệ thống";
      alert("Không thể tạo phiếu: " + errorDetail);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 font-sans">
      <div className="bg-white rounded-[2.5rem] w-full max-w-2xl shadow-2xl flex flex-col max-h-[90vh] animate-in zoom-in duration-200">
        
        {/* Header */}
        <div className="p-8 border-b border-slate-50 flex justify-between items-center bg-white rounded-t-[2.5rem]">
          <h2 className="text-2xl font-black text-slate-800 tracking-tight text-center w-full ml-6">Issue New Loan</h2>
          <button onClick={onClose} className="text-slate-400 hover:bg-slate-50 p-2 rounded-full transition-all">
            <X size={24}/>
          </button>
        </div>

        {/* Body */}
        <div className="p-8 overflow-y-auto space-y-8 bg-white">
          {/* 1. Chọn độc giả */}
          <div>
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-3 ml-1">1. Select Member</label>
            <select 
              className="w-full bg-slate-50 border-none rounded-2xl p-4 text-sm font-bold outline-none focus:ring-2 focus:ring-blue-500/20 transition-all appearance-none"
              value={selectedMember}
              onChange={e => setSelectedMember(e.target.value)}
            >
              <option value="">-- Click to select member --</option>
              {members.map(m => (
                <option key={m.memberID} value={m.memberID}>{m.memberName} (ID: {m.memberID})</option>
              ))}
            </select>
          </div>

          {/* 2. Chọn sách */}
          <div>
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-3 ml-1">
              2. Select Books ({selectedBooks.length} selected)
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-60 overflow-y-auto p-1">
              {loading ? (
                <div className="col-span-2 py-10 text-center text-slate-300 font-bold uppercase text-[10px] tracking-widest">Loading Library...</div>
              ) : books.length > 0 ? (
                books.map(b => (
                  <button 
                    key={b.bookID} 
                    onClick={() => toggleBook(b.bookID)}
                    className={`group flex items-center justify-between p-4 rounded-2xl text-left transition-all border-2 ${
                      selectedBooks.includes(b.bookID) 
                      ? 'bg-blue-600 border-blue-600 text-white shadow-xl shadow-blue-200' 
                      : 'bg-slate-50 border-transparent text-slate-600 hover:bg-slate-100 hover:border-slate-200'
                    }`}
                  >
                    <div className="flex flex-col overflow-hidden">
                      <span className="text-xs font-black truncate">{b.title}</span>
                      <span className={`text-[10px] font-bold ${selectedBooks.includes(b.bookID) ? 'text-blue-100' : 'text-slate-400'}`}>
                        {b.author}
                      </span>
                    </div>
                    {selectedBooks.includes(b.bookID) && <Check size={16} strokeWidth={4} />}
                  </button>
                ))
              ) : (
                <div className="col-span-2 py-10 text-center bg-slate-50 rounded-2xl text-slate-400 text-xs font-bold border-2 border-dashed uppercase tracking-widest">No books in database.</div>
              )}
            </div>
          </div>

          {/* 3. Ngày hẹn trả */}
          <div>
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-3 ml-1">3. Due Date</label>
            <input 
              type="date" 
              className="w-full bg-slate-50 border-none rounded-2xl p-4 text-sm font-bold outline-none focus:ring-2 focus:ring-blue-500/20"
              value={dueDate}
              onChange={e => setDueDate(e.target.value)} 
            />
          </div>
        </div>

        {/* Footer */}
        <div className="p-8 bg-slate-50/50 border-t border-slate-50 rounded-b-[2.5rem] flex gap-4">
          <button onClick={onClose} className="flex-1 py-4 font-black text-[10px] uppercase tracking-[0.2em] text-slate-400 hover:text-slate-600 transition-colors">
            Cancel
          </button>
          <button 
            onClick={handleCreate}
            className="flex-[2] bg-blue-600 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-2xl shadow-blue-200 hover:bg-blue-700 hover:scale-[1.02] transition-all active:scale-95 flex items-center justify-center gap-2"
          >
            Issue Slip
          </button>
        </div>
      </div>
    </div>
  );
}