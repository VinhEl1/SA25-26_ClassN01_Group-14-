import React, { useState } from 'react';
import api from '../api/axios';
import { X, DollarSign, FileText, Loader2 } from 'lucide-react';

export default function AddFineModal({ isOpen, onClose, onRefresh }) {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    reason: '',
    amount: 0,
    status: 'Pending',
    issuedDate: new Date().toISOString()
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await api.post('/fines', formData);
      alert("Tạo phiếu phạt thành công!");
      onRefresh();
      onClose();
    } catch (error) {
      alert("Lỗi: " + (error.response?.data?.message || "Không thể tạo phiếu phạt"));
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-[2.5rem] w-full max-w-md shadow-2xl overflow-hidden animate-in zoom-in duration-200">
        <div className="p-8 border-b border-slate-50 flex justify-between items-center bg-red-50/30">
          <h2 className="text-2xl font-black text-slate-800 tracking-tight">New Fine</h2>
          <button onClick={onClose} className="p-2 hover:bg-white rounded-full text-slate-400 shadow-sm"><X size={20}/></button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-8 space-y-5">
          <div>
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Fine Reason</label>
            <div className="relative">
              <FileText className="absolute left-4 top-4 text-slate-300" size={18} />
              <textarea required placeholder="e.g. Damaged book cover" className="w-full bg-slate-50 border-none rounded-2xl p-4 pl-12 text-sm font-bold h-24 resize-none outline-none focus:ring-2 focus:ring-red-500/20" 
                onChange={e => setFormData({...formData, reason: e.target.value})} />
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Penalty Amount ($)</label>
            <div className="relative">
              <DollarSign className="absolute left-4 top-4 text-slate-300" size={18} />
              <input required type="number" placeholder="0.00" className="w-full bg-slate-50 border-none rounded-2xl p-4 pl-12 text-sm font-bold outline-none focus:ring-2 focus:ring-red-500/20" 
                onChange={e => setFormData({...formData, amount: parseFloat(e.target.value)})} />
            </div>
          </div>

          <button disabled={loading} type="submit" className="w-full bg-red-600 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-red-100 hover:bg-red-700 transition-all flex items-center justify-center gap-2 mt-4">
            {loading ? <Loader2 className="animate-spin" size={18} /> : "Issue Fine"}
          </button>
        </form>
      </div>
    </div>
  );
}