import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, Book, Users, ClipboardList, 
  Wallet, BarChart3, Settings, Bell, Search, 
  Moon, LogOut 
} from 'lucide-react';

// Component con cho từng mục Menu
const SidebarItem = ({ icon: Icon, label, path }) => {
  const location = useLocation();
  const active = location.pathname === path;

  return (
    <Link 
      to={path} 
      className={`flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all duration-300 ${
        active 
        ? 'bg-blue-600 text-white shadow-lg shadow-blue-200' 
        : 'text-gray-500 hover:bg-gray-100 hover:text-blue-600'
      }`}
    >
      <Icon size={20} />
      <span className="font-bold text-sm">{label}</span>
    </Link>
  );
};

export default function Layout({ children }) {
  const location = useLocation();
  
  // 1. LẤY ROLE VÀ NAME CHUẨN: Không dùng || 'Admin' ở đây để tránh lỗi kẹt giao diện
  const role = localStorage.getItem('role'); 
  const fullName = localStorage.getItem('userName') || 'Người dùng';

  // 2. LOGIC ĐĂNG XUẤT TRIỆT ĐỂ
  const handleLogout = () => {
    localStorage.clear(); // Xóa sạch Token, Role, Name
    window.location.href = "/login"; // Ép tải lại trang để xóa sạch bộ nhớ đệm React
  };

  return (
    <div className="flex min-h-screen bg-white font-sans antialiased text-slate-900">
      
      {/* SIDEBAR - THANH BÊN TRÁI */}
      <aside className="w-72 border-r border-slate-100 flex flex-col bg-[#fcfdfe] sticky top-0 h-screen shadow-sm">
        <div className="p-8 flex items-center gap-3 text-blue-600 font-black text-2xl tracking-tighter">
          <div className="bg-blue-600 text-white p-1.5 rounded-xl shadow-inner"> <Book size={24}/> </div>
          LibraryAdmin
        </div>
        
        <nav className="flex-1 px-6 space-y-2 overflow-y-auto">
          <div className="text-[10px] font-black text-slate-400 mb-4 mt-4 px-4 tracking-[0.2em]">MAIN</div>
          <SidebarItem icon={LayoutDashboard} label="Dashboard" path="/" />
          <SidebarItem icon={Book} label="Books" path="/books" />
          
          {/* PHÂN QUYỀN GIAO DIỆN SIDEBAR */}
          {role === 'Admin' ? (
            <>
              <div className="text-[10px] font-black text-slate-400 mb-4 mt-10 px-4 tracking-[0.2em]">MANAGEMENT</div>
              <SidebarItem icon={Users} label="Members" path="/members" />
              <SidebarItem icon={ClipboardList} label="Loans & Borrows" path="/loans" />
              <SidebarItem icon={Wallet} label="Fines" path="/fines" />
              
              <div className="text-[10px] font-black text-slate-400 mb-4 mt-10 px-4 tracking-[0.2em]">SYSTEM</div>
              <SidebarItem icon={BarChart3} label="Reports" path="/reports" />
              <SidebarItem icon={Settings} label="Settings" path="/settings" />
            </>
          ) : (
            <>
              {/* Menu cho User thường */}
              <div className="text-[10px] font-black text-slate-400 mb-4 mt-10 px-4 tracking-[0.2em]">PERSONAL</div>
              <SidebarItem icon={ClipboardList} label="My Loans" path="/loans" />
              <SidebarItem icon={Wallet} label="My Fines" path="/fines" />
            </>
          )}
        </nav>

        {/* NÚT ĐĂNG XUẤT */}
        <div className="p-6 border-t border-slate-50">
          <button 
            onClick={handleLogout}
            className="flex items-center justify-center gap-3 px-4 py-3 w-full text-red-500 hover:bg-red-50 rounded-2xl transition-all font-bold text-sm cursor-pointer shadow-sm border border-transparent hover:border-red-100"
          >
            <LogOut size={18} />
            <span>Đăng xuất</span>
          </button>
        </div>
      </aside>

      {/* MAIN CONTENT - NỘI DUNG BÊN PHẢI */}
      <main className="flex-1 flex flex-col bg-white">
        
        {/* HEADER */}
        <header className="h-20 flex items-center justify-between px-10 bg-white/80 backdrop-blur-md sticky top-0 z-10 border-b border-slate-50">
          <div className="relative w-full max-w-md">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Tìm kiếm sách, thành viên..." 
              className="w-full pl-12 pr-4 py-3 bg-slate-50 border-none rounded-2xl text-sm focus:ring-2 focus:ring-blue-500/20 transition-all outline-none font-bold" 
            />
          </div>
          
          <div className="flex items-center gap-8">
            <div className="relative p-2.5 text-slate-400 hover:bg-slate-50 rounded-2xl cursor-pointer transition-all">
              <Bell size={20} />
              <span className="absolute top-2.5 right-2.5 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
            </div>

            <div className="flex items-center gap-4 pl-8 border-l border-slate-100">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-black text-slate-800 leading-none">{fullName}</p>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">
                  {role === 'Admin' ? 'Thủ thư cấp cao' : 'Thành viên'}
                </p>
              </div>
              
              <div className="relative">
                <div className="w-11 h-11 bg-blue-600 text-white rounded-2xl flex items-center justify-center font-black text-lg shadow-xl shadow-blue-200">
                  {fullName.charAt(0).toUpperCase()}
                </div>
                <span className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-4 border-white rounded-full"></span>
              </div>
            </div>
          </div>
        </header>

        {/* NỘI DUNG TRANG (Children) */}
        <div className="p-10 bg-white min-h-full">
          {children}
        </div>

      </main>
    </div>
  );
}