import React, { useState, useEffect, useRef } from 'react';
import api from '../api/axios';
import { X, Upload, Loader2, ChevronDown } from 'lucide-react';

export default function EditBookModal({ isOpen, onClose, onRefresh, book }) {
  const [loading, setLoading] = useState(false);
  const [preview, setPreview] = useState(null);
  const fileInputRef = useRef();

  const [formData, setFormData] = useState({
    title: '',
    author: '',
    category: '',
    price: 0,
    stock: 0,
    publishYear: '',
    imageUrl: ''
  });

  // --- BƯỚC QUAN TRỌNG: ĐỔ DỮ LIỆU CŨ VÀO FORM KHI MỞ MODAL ---
  useEffect(() => {
    if (book && isOpen) {
      setFormData({
        title: book.title || '',
        author: book.author || '',
        category: book.category || '', // Giữ nguyên thể loại cũ
        price: book.price || 0,
        stock: book.stock || 0,
        publishYear: book.publishYear || '',
        imageUrl: book.imageUrl || ''
      });
      setPreview(book.imageUrl); // Hiện ảnh cũ làm preview
    }
  }, [book, isOpen]);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setPreview(URL.createObjectURL(file));
    }
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      let finalImageUrl = formData.imageUrl; // Mặc định dùng lại link ảnh cũ

      // Nếu bạn có chọn file ảnh mới thì mới upload lên Cloudinary
      const file = fileInputRef.current.files[0];
      if (file) {
        const data = new FormData();
        data.append('file', file);
        const uploadRes = await api.post('Photo/upload', data);
        finalImageUrl = uploadRes.data.url;
      }

      // Gửi toàn bộ dữ liệu đi (Cái nào bạn sửa thì nó lấy giá trị mới, cái nào không sửa nó giữ giá trị cũ từ formData)
      await api.put(`Book/${book.bookID}`, { ...formData, imageUrl: finalImageUrl });

      alert("Cập nhật thành công!");
      onRefresh();
      onClose();
    } catch (error) {
      console.error(error);
      alert("Lỗi cập nhật: " + (error.response?.data?.message || error.message));
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-[2.5rem] w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col md:flex-row animate-in zoom-in duration-200">
        
        {/* CỘT TRÁI: ẢNH BÌA */}
        <div className="md:w-1/2 bg-slate-50 p-8 flex flex-col items-center justify-center border-r border-slate-100">
          <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Book Cover</label>
          <div 
            onClick={() => fileInputRef.current.click()}
            className="relative w-full aspect-[3/4] rounded-[2rem] border-4 border-dashed border-slate-200 bg-white overflow-hidden cursor-pointer hover:border-blue-400 transition-all group"
          >
            {preview ? (
              <img src={preview} alt="Preview" className="w-full h-full object-cover shadow-inner" />
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-slate-400">
                <Upload size={32} />
                <p className="text-xs font-bold mt-2">Thay ảnh mới</p>
              </div>
            )}
            <input type="file" hidden ref={fileInputRef} onChange={handleFileChange} accept="image/*" />
          </div>
        </div>

        {/* CỘT PHẢI: FORM */}
        <div className="md:w-1/2 p-8 bg-white relative">
          <button onClick={onClose} className="absolute top-6 right-6 p-2 hover:bg-slate-50 rounded-full text-slate-300 transition-colors"><X size={20}/></button>
          
          <h2 className="text-2xl font-black text-slate-800 tracking-tight mb-8">Edit Details</h2>

          <form onSubmit={handleUpdate} className="space-y-4">
            {/* Mỗi ô input đều liên kết với value={formData...} */}
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Title</label>
              <input value={formData.title} className="w-full bg-slate-50 border-none rounded-2xl p-4 text-sm font-bold focus:ring-2 focus:ring-blue-500/20 outline-none" 
                onChange={e => setFormData({...formData, title: e.target.value})} />
            </div>

            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Category</label>
              <div className="relative">
                <select 
                  value={formData.category} 
                  className="w-full bg-slate-50 border-none rounded-2xl p-4 text-sm font-bold outline-none appearance-none cursor-pointer"
                  onChange={e => setFormData({...formData, category: e.target.value})}
                >
                  <option value="Viễn tưởng">Viễn tưởng</option>
                  <option value="Khoa học">Khoa học</option>
                  <option value="Lịch sử">Lịch sử</option>
                  <option value="Văn học">Văn học</option>
                </select>
                <ChevronDown size={16} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Author</label>
              <input value={formData.author} className="w-full bg-slate-50 border-none rounded-2xl p-4 text-sm font-bold outline-none" 
                onChange={e => setFormData({...formData, author: e.target.value})} />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Price ($)</label>
                <input type="number" value={formData.price} className="w-full bg-slate-50 border-none rounded-2xl p-4 text-sm font-bold outline-none" 
                  onChange={e => setFormData({...formData, price: parseFloat(e.target.value) || 0})} />
              </div>
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Stock</label>
                <input type="number" value={formData.stock} className="w-full bg-slate-50 border-none rounded-2xl p-4 text-sm font-bold outline-none" 
                  onChange={e => setFormData({...formData, stock: parseInt(e.target.value) || 0})} />
              </div>
            </div>

            <button disabled={loading} type="submit" className="w-full bg-blue-600 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-100 hover:bg-blue-700 transition-all flex items-center justify-center gap-2 mt-4 active:scale-95">
              {loading ? <Loader2 className="animate-spin" size={18} /> : "Update Book"}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}