import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:5268/api', // Đảm bảo đúng cổng Backend
});

// CƠ CHẾ TỰ ĐỘNG CẬP NHẬT TOKEN TRƯỚC MỖI REQUEST
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// TỰ ĐỘNG ĐẨY VỀ LOGIN NẾU TOKEN HẾT HẠN (LỖI 401)
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      localStorage.clear();
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export default api;