from flask import Flask, request, jsonify, make_response
import requests

app = Flask(__name__)

# Cổng Gateway chạy
GATEWAY_PORT = 5000
# Địa chỉ Backend (Product Service)
PRODUCT_SERVICE_URL = 'http://127.0.0.1:5001'

# --- 1. SECURITY STUB (Logic bảo mật) ---
def validate_token(auth_header):
    """Kiểm tra token trong header Authorization"""
    if not auth_header:
        return False, "Authorization header missing"
    
    # Kiểm tra format (Bearer <token>)
    if not auth_header.startswith("Bearer "):
        return False, "Invalid token format"

    token = auth_header.split("Bearer ")[-1]

    # Danh sách token hợp lệ (Whitelist)
    if token in ("valid-admin-token", "valid-user-token"):
        return True, None
    else:
        return False, "Invalid or expired token"

def is_admin_token(auth_header):
    """Kiểm tra quyền Admin"""
    if auth_header and "valid-admin-token" in auth_header:
        return True
    return False

# --- 2. ROUTING LOGIC (Định tuyến) ---
# Bắt tất cả các method và đường dẫn bắt đầu bằng /api/products
@app.route('/api/products', defaults={'path': ''}, methods=['GET', 'POST'])
@app.route('/api/products/<path:path>', methods=['GET', 'POST', 'PUT', 'DELETE'])
def proxy_request(path):
    # --- BƯỚC A: KIỂM TRA BẢO MẬT ---
    auth_header = request.headers.get('Authorization')
    is_valid, error_msg = validate_token(auth_header)
    
    if not is_valid:
        return jsonify({"error": "Unauthorized", "details": error_msg}), 401

    # Kiểm tra quyền Admin nếu là method sửa/xóa/thêm
    if request.method in ['POST', 'PUT', 'DELETE'] and not is_admin_token(auth_header):
        return jsonify({"error": "Forbidden", "details": "Admin access required"}), 403

    # --- BƯỚC B: CHUYỂN TIẾP REQUEST (ROUTING) ---
    # Xây dựng URL đích
    if path:
        target_url = f'{PRODUCT_SERVICE_URL}/api/products/{path}'
    else:
        target_url = f'{PRODUCT_SERVICE_URL}/api/products'

    try:
        # Gửi request sang Backend (Product Service)
        response = requests.request(
            method=request.method,
            url=target_url,
            headers={k: v for k, v in request.headers if k.lower() != 'host'}, # Copy headers
            data=request.get_data(), # Copy body
            params=request.args,     # Copy query params
            timeout=5
        )

        # --- BƯỚC C: TRẢ VỀ RESPONSE CHO CLIENT ---
        gateway_resp = make_response(response.content, response.status_code)
        for key, value in response.headers.items():
            gateway_resp.headers[key] = value
            
        return gateway_resp

    except requests.exceptions.RequestException as e:
        # Xử lý khi Backend bị sập (Test case 3)
        return jsonify({"error": "Service Unavailable", "details": str(e)}), 503

if __name__ == '__main__':
    print(f"API Gateway starting on port {GATEWAY_PORT}...")
    app.run(port=GATEWAY_PORT, debug=True)