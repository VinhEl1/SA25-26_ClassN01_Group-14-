from flask import Flask, jsonify, request

app = Flask(__name__)

# Dữ liệu giả lập
products = [
    {"id": 1, "name": "Laptop", "price": 1000},
    {"id": 2, "name": "Phone", "price": 500}
]

@app.route('/api/products', methods=['GET'])
def get_products():
    return jsonify(products), 200

@app.route('/api/products', methods=['POST'])
def add_product():
    data = request.json
    products.append(data)
    return jsonify({"message": "Added", "product": data}), 201

if __name__ == '__main__':
    # Backend chạy ở port 5001
    app.run(port=5001, debug=True)