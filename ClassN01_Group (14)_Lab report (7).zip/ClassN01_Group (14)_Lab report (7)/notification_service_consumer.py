import pika
import json
import time

# Cấu hình
RABBITMQ_HOST = 'localhost'
QUEUE_NAME = 'order_events'

def callback(ch, method, properties, body):
    """Hàm này chạy mỗi khi nhận được tin nhắn"""
    try:
        # Giải mã JSON
        order_data = json.loads(body)
        order_id = order_data.get('order_id')
        email = order_data.get('customer_email')

        print(f" [x] Received event for Order ID: {order_id}")

        # GIẢ LẬP ĐỘ TRỄ: Giả sử gửi email mất 3 giây
        # Đây là phần quan trọng nhất để chứng minh Decoupling
        time.sleep(3) 

        print(f" [✔] SENT CONFIRMATION: Order {order_id} confirmed for email: {email}")

        # Gửi xác nhận (ACK) đã xử lý xong để RabbitMQ xóa tin nhắn đi
        ch.basic_ack(delivery_tag=method.delivery_tag)

    except json.JSONDecodeError:
        print(f" [!] Error decoding JSON")
        # Từ chối tin nhắn lỗi
        ch.basic_reject(delivery_tag=method.delivery_tag, requeue=False)

if __name__ == '__main__':
    try:
        print("Notification Service is connecting...")
        connection = pika.BlockingConnection(pika.ConnectionParameters(host=RABBITMQ_HOST))
        channel = connection.channel()

        # Khai báo hàng đợi
        channel.queue_declare(queue=QUEUE_NAME)

        # QoS: Chỉ nhận 1 tin mỗi lần, xử lý xong mới nhận tiếp
        channel.basic_qos(prefetch_count=1)

        # Đăng ký hàm callback
        channel.basic_consume(queue=QUEUE_NAME, on_message_callback=callback)

        print(' [*] Waiting for OrderPlacedEvents. To exit press CTRL+C')
        channel.start_consuming()

    except Exception as e:
        print(f" [!] Connection Error: {e}")
    except KeyboardInterrupt:
        print('Consumer shutting down.')