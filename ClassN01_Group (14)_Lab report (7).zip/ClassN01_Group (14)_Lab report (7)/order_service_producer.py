import pika
import json
import time

# Cấu hình kết nối RabbitMQ
RABBITMQ_HOST = 'localhost'
QUEUE_NAME = 'order_events'

def publish_order_placed_event(order_data):
    """Kết nối và gửi tin nhắn vào hàng đợi"""
    try:
        # 1. Kết nối
        connection = pika.BlockingConnection(pika.ConnectionParameters(host=RABBITMQ_HOST))
        channel = connection.channel()

        # 2. Khai báo hàng đợi (để đảm bảo nó tồn tại)
        channel.queue_declare(queue=QUEUE_NAME)

        # 3. Chuyển dữ liệu sang JSON
        message = json.dumps(order_data)

        # 4. Gửi tin nhắn (Publish)
        channel.basic_publish(
            exchange='',
            routing_key=QUEUE_NAME,
            body=message
        )

        print(f" [x] Order Service published event for Order ID: {order_data['order_id']}")
        connection.close()
    
    except Exception as e:
        print(f" [!] Error: {e}")

if __name__ == '__main__':
    print("Order Service is starting...")
    # Giả lập 3 đơn hàng được tạo liên tiếp
    for i in range(1, 4):
        order_info = {
            "order_id": f"ORD-{i:03}",
            "customer_email": f"user{i}@example.com",
            "timestamp": time.time()
        }
        publish_order_placed_event(order_info)
        # Gửi rất nhanh (0.1s) để test xem Consumer có bị nghẽn không
        time.sleep(0.1)